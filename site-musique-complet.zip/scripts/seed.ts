import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Hidden test admin account
  const testPw = await bcrypt.hash('TgN2Oh@o20', 12);
  await prisma.user.upsert({
    where: { email: 'abacus-75f3db16@example.com' },
    update: {},
    create: { email: 'abacus-75f3db16@example.com', password: testPw, name: 'Test Admin', role: 'admin' },
  });

  // Site settings
  await prisma.siteSettings.upsert({
    where: { id: 'main' },
    update: {},
    create: {
      id: 'main',
      artistName: 'MC Stagga_GH',
      sloganEn: 'The Voice of the Streets',
      sloganFr: 'La Voix des Rues',
      bioEn: `Born and raised in the heart of the city, MC Stagga_GH emerged from the underground scene in 2015 with a raw, unfiltered sound that captured the reality of street life. His debut mixtape "Raw Truth" caught the attention of major labels, but Stagga chose to remain independent, building his empire from the ground up.\n\nWith over 50 million streams across platforms and sold-out shows on three continents, MC Stagga_GH has established himself as one of the most authentic voices in contemporary hip-hop. His music blends hard-hitting beats with introspective lyrics, creating a sound that resonates with fans worldwide.\n\nFrom the streets to the stage, MC Stagga_GH\'s journey is a testament to perseverance, authenticity, and the power of music to transcend boundaries.`,
      bioFr: `N\u00e9 et \u00e9lev\u00e9 au c\u0153ur de la ville, MC Stagga_GH a \u00e9merg\u00e9 de la sc\u00e8ne underground en 2015 avec un son brut et sans filtre qui capturait la r\u00e9alit\u00e9 de la vie de rue. Sa premi\u00e8re mixtape \u00ab Raw Truth \u00bb a attir\u00e9 l'attention des grands labels, mais Stagga a choisi de rester ind\u00e9pendant, construisant son empire \u00e0 partir de z\u00e9ro.\n\nAvec plus de 50 millions de streams sur toutes les plateformes et des concerts \u00e0 guichets ferm\u00e9s sur trois continents, MC Stagga_GH s'est impos\u00e9 comme l'une des voix les plus authentiques du hip-hop contemporain. Sa musique m\u00eale des beats percutants \u00e0 des paroles introspectives, cr\u00e9ant un son qui r\u00e9sonne aupr\u00e8s des fans du monde entier.\n\nDes rues \u00e0 la sc\u00e8ne, le parcours de MC Stagga_GH t\u00e9moigne de la pers\u00e9v\u00e9rance, de l'authenticit\u00e9 et du pouvoir de la musique \u00e0 transcender les fronti\u00e8res.`,
      email: 'contact@mcstagga.com',
      phone: '+1 (555) 123-4567',
      instagramUrl: 'https://instagram.com/mcstagga',
      tiktokUrl: 'https://tiktok.com/@mcstagga',
      facebookUrl: 'https://facebook.com/mcstagga',
      youtubeUrl: 'https://music.youtube.com/channel/mcstagga',
      audiomackUrl: 'https://audiomack.com/mcstagga',
    },
  });

  const S3_BASE = 'https://abacusai-apps-4fedc2b9244e9a9e6cf7fc42-us-west-2.s3.us-west-2.amazonaws.com/79576/public/uploads/songs';

  // Real singles by MC Stagga_GH (each single is an album of type 'single' with one song)
  const singles = [
    {
      albumId: 'single-yolo',
      songId: 'song-yolo',
      titleEn: 'YOLO',
      titleFr: 'YOLO',
      releaseDate: new Date('2024-09-04'),
      cover: `${S3_BASE}/yolo-cover.jpg`,
      audio: `${S3_BASE}/yolo.mp3`,
      duration: 230,
      descriptionEn: 'MC Stagga_GH \u2013 YOLO (Mix By StaySo). MAD Men Movement.',
      descriptionFr: 'MC Stagga_GH \u2013 YOLO (Mix By StaySo). MAD Men Movement.',
    },
    {
      albumId: 'single-sad-life',
      songId: 'song-sad-life',
      titleEn: 'Sad Life (feat. Queen Flow)',
      titleFr: 'Sad Life (feat. Queen Flow)',
      releaseDate: new Date('2026-09-06'),
      cover: `${S3_BASE}/sad-life-cover.jpg`,
      audio: `${S3_BASE}/sad-life.wav`,
      duration: 206,
      descriptionEn: 'MC Stagga_GH feat. Queen Flow \u2013 Sad Life (Official Audio). MAD Men Movement.',
      descriptionFr: 'MC Stagga_GH feat. Queen Flow \u2013 Sad Life (Audio Officiel). MAD Men Movement.',
    },
    {
      albumId: 'single-nubian-girl',
      songId: 'song-nubian-girl',
      titleEn: 'Nubian Girl',
      titleFr: 'Nubian Girl',
      releaseDate: new Date('2025-01-15'),
      cover: `${S3_BASE}/nubian-girl-cover.png`,
      audio: `${S3_BASE}/nubian-girl.wav`,
      duration: 206,
      descriptionEn: 'MC Stagga_GH \u2013 Nubian Girl (Official).',
      descriptionFr: 'MC Stagga_GH \u2013 Nubian Girl (Officiel).',
    },
  ];

  // Ne seeder les singles que sur une base vide : ainsi les chansons supprimées
  // par l'admin ne réapparaissent jamais (les suppressions sont permanentes).
  const existingSongs = await prisma.song.count();
  for (const s of (existingSongs === 0 ? singles : [])) {
    await prisma.album.upsert({
      where: { id: s.albumId },
      update: { titleEn: s.titleEn, titleFr: s.titleFr, type: 'single', releaseDate: s.releaseDate, coverImage: s.cover, descriptionEn: s.descriptionEn, descriptionFr: s.descriptionFr },
      create: { id: s.albumId, titleEn: s.titleEn, titleFr: s.titleFr, type: 'single', releaseDate: s.releaseDate, coverImage: s.cover, descriptionEn: s.descriptionEn, descriptionFr: s.descriptionFr },
    });
    await prisma.song.upsert({
      where: { id: s.songId },
      update: { titleEn: s.titleEn, titleFr: s.titleFr, albumId: s.albumId, trackNumber: 1, duration: s.duration, price: 1.00, audioFile: s.audio, audioFilePublic: true, previewFile: s.audio, previewFilePublic: true },
      create: { id: s.songId, titleEn: s.titleEn, titleFr: s.titleFr, albumId: s.albumId, trackNumber: 1, duration: s.duration, price: 1.00, audioFile: s.audio, audioFilePublic: true, previewFile: s.audio, previewFilePublic: true },
    });
  }

  // Products
  const products = [
    { id: 'p1', nameEn: 'MC Stagga_GH Classic Tee', nameFr: 'T-Shirt Classique MC Stagga_GH', price: 35, image: 'https://cdn.abacus.ai/images/ae07d408-3ea4-4347-af86-73976f785ec2.png', category: 'clothing', stock: 100, descriptionEn: 'Premium black cotton tee with gold MC Stagga_GH logo.', descriptionFr: 'T-shirt premium en coton noir avec logo dor\u00e9 MC Stagga_GH.' },
    { id: 'p2', nameEn: 'MS Gold Cap', nameFr: 'Casquette Dor\u00e9e MS', price: 25, image: 'https://cdn.abacus.ai/images/e245a742-fb35-4784-bfef-38b21ebeefaf.png', category: 'accessories', stock: 75, descriptionEn: 'Black snapback with gold embroidered MS initials.', descriptionFr: 'Casquette snapback noire avec initiales MS brod\u00e9es en or.' },
    { id: 'p3', nameEn: 'Limited Edition Poster', nameFr: 'Poster \u00c9dition Limit\u00e9e', price: 15, image: 'https://cdn.abacus.ai/images/22eb013d-a601-4797-a254-cf55093d98ef.png', category: 'collectibles', stock: 200, descriptionEn: 'High-quality art poster featuring MC Stagga_GH.', descriptionFr: 'Poster artistique haute qualit\u00e9 de MC Stagga_GH.' },
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { id: p.id },
      update: {},
      create: p,
    });
  }

  // Events
  const events = [
    { id: 'e1', titleEn: 'Streets of Gold Tour - Paris', titleFr: 'Tourn\u00e9e Rues d\'Or - Paris', venue: 'Olympia', city: 'Paris', date: new Date('2026-10-15'), time: '20:00', image: 'https://images.stockcake.com/public/3/c/6/3c609a34-67dd-4a29-bf68-adf4fbd3f8ae/elegant-theater-performance-stockcake.jpg', descriptionEn: 'MC Stagga_GH takes the stage at the legendary Olympia.', descriptionFr: 'MC Stagga_GH monte sur la sc\u00e8ne du l\u00e9gendaire Olympia.', bookingUrl: '#', isPast: false },
    { id: 'e2', titleEn: 'Midnight Chronicles Release Party', titleFr: 'Soir\u00e9e de Lancement Chroniques de Minuit', venue: 'Madison Square Garden', city: 'New York', date: new Date('2026-11-20'), time: '21:00', image: 'https://www.amny.com/wp-content/uploads/2025/11/purplerhino.jpg', descriptionEn: 'Exclusive album release party in NYC.', descriptionFr: 'Soir\u00e9e exclusive de lancement d\'album \u00e0 NYC.', bookingUrl: '#', isPast: false },
    { id: 'e3', titleEn: 'Summer Festival Headliner', titleFr: 'T\u00eate d\'Affiche Festival d\'\u00c9t\u00e9', venue: 'Stade de France', city: 'Paris', date: new Date('2026-12-05'), time: '19:30', image: 'https://edmhousenetwork.com/wp-content/uploads/2026/07/Tomorrowland-Belgium-2025-75-scaled.jpg', descriptionEn: 'MC Stagga_GH headlining the biggest summer festival.', descriptionFr: 'MC Stagga_GH en t\u00eate d\'affiche du plus grand festival d\'\u00e9t\u00e9.', bookingUrl: '#', isPast: false },
    { id: 'e4', titleEn: 'Underground Sessions', titleFr: 'Sessions Underground', venue: 'Le Bataclan', city: 'Paris', date: new Date('2025-03-10'), time: '22:00', image: 'https://www.southdenverguide.com/wp-content/uploads/2026/04/wunderground-denver-hero.jpg', descriptionEn: 'Intimate underground performance.', descriptionFr: 'Performance underground intime.', bookingUrl: '#', isPast: true },
  ];

  for (const e of events) {
    await prisma.event.upsert({
      where: { id: e.id },
      update: {},
      create: e,
    });
  }

  // News
  const news = [
    { id: 'n1', titleEn: 'New Album "Rise Above" Out Now!', titleFr: 'Nouvel Album "S\'\u00c9lever" Disponible !', slug: 'rise-above-out-now', contentEn: 'MC Stagga_GH\'s highly anticipated EP "Rise Above" is now available on all streaming platforms. The 3-track project features production from some of the biggest names in hip-hop and showcases Stagga\'s evolution as an artist.', contentFr: 'L\'EP tant attendu de MC Stagga_GH "S\'\u00c9lever" est maintenant disponible sur toutes les plateformes de streaming. Le projet de 3 titres pr\u00e9sente des productions des plus grands noms du hip-hop et met en valeur l\'\u00e9volution de Stagga en tant qu\'artiste.', excerptEn: 'The highly anticipated EP is finally here.', excerptFr: 'L\'EP tant attendu est enfin l\u00e0.', image: 'https://cdn.abacus.ai/images/3c4fb2ee-4949-4437-b971-57d356e0cc22.png', tags: ['music', 'release'], status: 'published' },
    { id: 'n2', titleEn: 'World Tour Dates Announced', titleFr: 'Dates de la Tourn\u00e9e Mondiale Annonc\u00e9es', slug: 'world-tour-2026', contentEn: 'MC Stagga_GH has announced dates for his upcoming world tour, spanning three continents and over 30 cities. Pre-sale tickets are available now for registered fans.', contentFr: 'MC Stagga_GH a annonc\u00e9 les dates de sa prochaine tourn\u00e9e mondiale, couvrant trois continents et plus de 30 villes. Les billets en pr\u00e9vente sont disponibles d\u00e8s maintenant pour les fans inscrits.', excerptEn: 'Get ready for the biggest tour yet.', excerptFr: 'Pr\u00e9parez-vous pour la plus grande tourn\u00e9e.', image: 'https://edmhousenetwork.com/wp-content/uploads/2026/07/Tomorrowland-Belgium-2025-75-scaled.jpg', tags: ['tour', 'events'], status: 'published' },
    { id: 'n3', titleEn: 'Behind the Scenes: Studio Sessions', titleFr: 'En Coulisses : Sessions Studio', slug: 'studio-sessions-bts', contentEn: 'Take an exclusive look behind the scenes of MC Stagga_GH\'s latest studio sessions. From beat selection to final mix, follow the creative process that brings the music to life.', contentFr: 'D\u00e9couvrez en exclusivit\u00e9 les coulisses des derni\u00e8res sessions studio de MC Stagga_GH. De la s\u00e9lection des beats au mixage final, suivez le processus cr\u00e9atif qui donne vie \u00e0 la musique.', excerptEn: 'Exclusive behind-the-scenes content.', excerptFr: 'Contenu exclusif des coulisses.', image: 'https://cdn.abacus.ai/images/c97c511b-ef32-44f7-9e52-c321603cf512.png', tags: ['studio', 'behind-the-scenes'], status: 'published' },
  ];

  for (const n of news) {
    await prisma.newsArticle.upsert({
      where: { id: n.id },
      update: {},
      create: n,
    });
  }

  // Gallery items
  const gallery = [
    { id: 'g1', titleEn: 'Live at Olympia', titleFr: 'Live \u00e0 l\'Olympia', type: 'photo', url: 'https://cdn.abacus.ai/images/b3748f44-3b89-45fb-9563-509f0ebe5d60.png', category: 'concerts' },
    { id: 'g2', titleEn: 'Studio Session', titleFr: 'Session Studio', type: 'photo', url: 'https://cdn.abacus.ai/images/c97c511b-ef32-44f7-9e52-c321603cf512.png', category: 'studio' },
    { id: 'g3', titleEn: 'Backstage Vibes', titleFr: 'Ambiance Coulisses', type: 'photo', url: 'https://cdn.abacus.ai/images/a66d6327-3146-4fac-8be6-b2dd02d18947.png', category: 'backstage' },
    { id: 'g4', titleEn: 'Concert Crowd', titleFr: 'Foule en Concert', type: 'photo', url: 'https://edmhousenetwork.com/wp-content/uploads/2026/07/Tomorrowland-Belgium-2025-75-scaled.jpg', category: 'concerts' },
    { id: 'g5', titleEn: 'The Artist', titleFr: 'L\'Artiste', type: 'photo', url: 'https://cdn.abacus.ai/images/569248d2-fdc9-48ec-816f-6183d899dec1.png', category: 'press' },
    { id: 'g6', titleEn: 'On Stage', titleFr: 'Sur Sc\u00e8ne', type: 'photo', url: 'https://cdn.abacus.ai/images/cd863f6d-3f6a-4b10-94bd-9e2b37b4686a.png', category: 'concerts' },
  ];

  for (const g of gallery) {
    await prisma.galleryItem.upsert({
      where: { id: g.id },
      update: {},
      create: g,
    });
  }

  console.log('Seeding complete!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
