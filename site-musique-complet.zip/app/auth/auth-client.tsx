'use client';

import React, { useState, useEffect } from 'react';
import { signIn, getSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { Music, Eye, EyeOff, Loader2, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export function AuthClient() {
  const { t } = useI18n();
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [loading, setLoading] = useState(false);
  const [signedUp, setSignedUp] = useState(false);

  const redirectByRole = async () => {
    const session = await getSession();
    const role = (session?.user as { role?: string } | undefined)?.role;
    window.location.href = role === 'admin' ? '/admin' : '/';
  };

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get('mode') === 'signup') {
      setMode('signup');
    }
  }, []);
  const [showPw, setShowPw] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === 'signup') {
        if (form.password !== form.confirmPassword) {
          toast.error('Passwords do not match');
          setLoading(false);
          return;
        }
        const res = await fetch('/api/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: form.email, password: form.password, name: form.name }),
        });
        if (!res.ok) {
          const data = await res.json();
          toast.error(data?.error || 'Signup failed');
          setLoading(false);
          return;
        }
        // Auto sign in after signup
        const result = await signIn('credentials', { email: form.email, password: form.password, redirect: false });
        if (result?.ok) {
          setSignedUp(true);
        } else {
          toast.error('Login failed after signup');
        }
      } else {
        const result = await signIn('credentials', { email: form.email, password: form.password, redirect: false });
        if (result?.ok) {
          await redirectByRole();
        } else {
          toast.error('Invalid credentials');
        }
      }
    } catch {
      toast.error('Something went wrong');
    }
    setLoading(false);
  };

  return (
    <>
      <Navbar />
      <section className="min-h-screen flex items-center justify-center px-4 pt-20 pb-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full max-w-md">
          <div className="glass-card rounded-2xl p-8">
            {signedUp ? (
              <div className="text-center py-6">
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-9 h-9 text-primary" />
                </div>
                <h1 className="font-display text-2xl font-bold text-foreground mb-3">{t('auth.congratsTitle')}</h1>
                <p className="text-sm text-muted-foreground mb-8">{t('auth.congratsMessage')}</p>
                <button onClick={redirectByRole} className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors">{t('auth.continue')}</button>
              </div>
            ) : (
            <>
            <div className="text-center mb-8">
              <Music className="w-10 h-10 text-primary mx-auto mb-3" />
              <h1 className="font-display text-2xl font-bold text-foreground">
                {mode === 'login' ? t('auth.welcomeBack') : t('auth.createAccount')}
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                {mode === 'signup' ? t('auth.joinFanbase') : ''}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">{t('auth.name')}</label>
                  <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
                </div>
              )}
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">{t('auth.email')}</label>
                <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">{t('auth.password')}</label>
                <div className="relative">
                  <input type={showPw ? 'text' : 'password'} required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary pr-12" />
                  <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    {showPw ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              {mode === 'signup' && (
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">{t('auth.confirmPassword')}</label>
                  <input type="password" required value={form.confirmPassword} onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
                </div>
              )}
              <button type="submit" disabled={loading} className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                {loading && <Loader2 className="w-5 h-5 animate-spin" />}
                {mode === 'login' ? t('auth.signIn') : t('auth.signUp')}
              </button>
            </form>

            <div className="mt-6 text-center">
              {mode === 'login' ? (
                <p className="text-sm text-muted-foreground">
                  {t('auth.noAccount')}{' '}
                  <button onClick={() => setMode('signup')} className="text-primary hover:underline font-medium">{t('auth.signUpHere')}</button>
                </p>
              ) : (
                <p className="text-sm text-muted-foreground">
                  {t('auth.hasAccount')}{' '}
                  <button onClick={() => setMode('login')} className="text-primary hover:underline font-medium">{t('auth.signInHere')}</button>
                </p>
              )}
            </div>
            </>
            )}
          </div>
        </motion.div>
      </section>
      <Footer />
    </>
  );
}
