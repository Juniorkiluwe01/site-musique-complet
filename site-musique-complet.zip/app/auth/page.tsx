export const metadata = { title: 'Sign In | MC STAGGA GH' };
import { AuthClient } from './auth-client';
export default function AuthPage() {
  return <AuthClient />;
}
