'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { X, ChevronLeft, ChevronRight, ZoomIn, Download } from 'lucide-react';

async function downloadPhoto(url: string, name: string) {
  try {
    const res = await fetch(url);
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  } catch {
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };
const categories = ['all', 'concerts', 'studio', 'backstage', 'press'];

export function GalleryClient({ items }: { items: any[] }) {
  const { t, locale } = useI18n();
  const [cat, setCat] = useState('all');
  const [lightbox, setLightbox] = useState<number | null>(null);

  const filtered = cat === 'all' ? (items ?? []) : (items ?? []).filter((i: any) => i?.category === cat);
  const catKeys: Record<string, string> = { all: 'gallery.all', concerts: 'gallery.concerts', studio: 'gallery.studio', backstage: 'gallery.backstage', press: 'gallery.press' };

  return (
    <>
      <Navbar />
      <section className="pt-28 pb-8 px-4">
        <div className="max-w-[1200px] mx-auto text-center">
          <motion.div {...fadeUp}>
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-3">{t('gallery.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('gallery.subtitle')}</p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 mb-8">
        <div className="max-w-[1200px] mx-auto flex justify-center gap-2 flex-wrap">
          {categories.map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`px-5 py-2 text-sm font-medium rounded-lg transition-colors ${cat === c ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}>
              {t(catKeys[c] ?? 'gallery.all')}
            </button>
          ))}
        </div>
      </section>

      <section className="px-4 pb-20">
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(filtered ?? []).map((item: any, i: number) => (
            <motion.div key={item?.id} {...fadeUp} transition={{ delay: i * 0.08 }} className="relative group">
              <button onClick={() => setLightbox(i)} className="relative w-full aspect-[4/3] rounded-xl overflow-hidden block">
                <Image src={item?.url} alt={locale === 'fr' ? (item?.titleFr ?? '') : (item?.titleEn ?? '')} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                  <ZoomIn className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); downloadPhoto(item?.url, `mc-stagga-${item?.id ?? i}.jpg`); }}
                className="absolute bottom-3 right-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold shadow-lg opacity-0 group-hover:opacity-100 transition-opacity hover:brightness-110"
              >
                <Download className="w-3.5 h-3.5" />
                {locale === 'fr' ? 'Télécharger' : 'Download'}
              </button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox !== null && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center" onClick={() => setLightbox(null)}>
            <button onClick={() => setLightbox(null)} className="absolute top-4 right-4 p-2 text-white hover:text-primary z-10"><X className="w-8 h-8" /></button>
            {lightbox > 0 && (
              <button onClick={(e) => { e.stopPropagation(); setLightbox(lightbox - 1); }} className="absolute left-4 p-2 text-white hover:text-primary z-10"><ChevronLeft className="w-8 h-8" /></button>
            )}
            {lightbox < filtered.length - 1 && (
              <button onClick={(e) => { e.stopPropagation(); setLightbox(lightbox + 1); }} className="absolute right-4 p-2 text-white hover:text-primary z-10"><ChevronRight className="w-8 h-8" /></button>
            )}
            <div className="relative w-full max-w-4xl aspect-video mx-4" onClick={(e) => e.stopPropagation()}>
              <Image src={filtered[lightbox]?.url ?? ''} alt={locale === 'fr' ? (filtered[lightbox]?.titleFr ?? '') : (filtered[lightbox]?.titleEn ?? '')} fill className="object-contain" />
              <button
                onClick={(e) => { e.stopPropagation(); downloadPhoto(filtered[lightbox]?.url ?? '', `mc-stagga-${filtered[lightbox]?.id ?? lightbox}.jpg`); }}
                className="absolute bottom-4 left-1/2 -translate-x-1/2 inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold shadow-lg hover:brightness-110"
              >
                <Download className="w-4 h-4" />
                {locale === 'fr' ? 'Télécharger' : 'Download'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </>
  );
}
