import { prisma } from '@/lib/db';
import { GalleryClient } from './gallery-client';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Gallery | MC STAGGA GH' };

export default async function GalleryPage() {
  const items = await prisma.galleryItem.findMany({ where: { published: true, type: 'photo' }, orderBy: { createdAt: 'desc' } });
  return <GalleryClient items={JSON.parse(JSON.stringify(items))} />;
}
