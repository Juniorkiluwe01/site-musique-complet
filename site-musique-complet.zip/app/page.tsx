import { prisma } from '@/lib/db';
import { HomeClient } from './_components/home-client';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const [albums, latestReleases, events, news, products, gallery] = await Promise.all([
    prisma.album.findMany({ where: { published: true, titleEn: 'YOLO' }, take: 1, include: { songs: { where: { published: true } } } }),
    prisma.latestRelease.findMany({ where: { published: true }, orderBy: [{ order: 'asc' }, { createdAt: 'desc' }] }),
    prisma.event.findMany({ where: { published: true, isPast: false }, orderBy: { date: 'asc' }, take: 3 }),
    prisma.newsArticle.findMany({ where: { status: 'published' }, orderBy: { createdAt: 'desc' }, take: 3 }),
    prisma.product.findMany({ where: { published: true }, take: 4 }),
    prisma.galleryItem.findMany({ where: { published: true, type: 'photo' }, orderBy: { createdAt: 'desc' }, take: 6 }),
  ]);

  return <HomeClient albums={JSON.parse(JSON.stringify(albums))} latestReleases={JSON.parse(JSON.stringify(latestReleases))} events={JSON.parse(JSON.stringify(events))} news={JSON.parse(JSON.stringify(news))} products={JSON.parse(JSON.stringify(products))} gallery={JSON.parse(JSON.stringify(gallery))} />;
}
