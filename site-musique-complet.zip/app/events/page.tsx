import { prisma } from '@/lib/db';
import { EventsClient } from './events-client';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Events | MC STAGGA GH' };

export default async function EventsPage() {
  const upcoming = await prisma.event.findMany({ where: { published: true, isPast: false }, orderBy: { date: 'asc' } });
  const past = await prisma.event.findMany({ where: { published: true, isPast: true }, orderBy: { date: 'desc' }, take: 6 });
  return <EventsClient upcoming={JSON.parse(JSON.stringify(upcoming))} past={JSON.parse(JSON.stringify(past))} />;
}
