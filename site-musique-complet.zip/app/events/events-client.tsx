'use client';

import React from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { Calendar, MapPin, Clock } from 'lucide-react';
import { SafeDate } from '@/components/safe-format';

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

export function EventsClient({ upcoming, past }: { upcoming: any[]; past: any[] }) {
  const { t, locale } = useI18n();

  const EventCard = ({ event, isPast }: { event: any; isPast?: boolean }) => (
    <div className={`glass-card ${!isPast ? 'glass-card-hover' : ''} rounded-xl overflow-hidden`}>
      <div className="relative aspect-[3/1]">
        <Image src={event?.image || ''} alt={locale === 'fr' ? event?.titleFr : event?.titleEn} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
        {isPast && <div className="absolute top-3 right-3 px-2 py-1 bg-muted text-muted-foreground text-xs rounded">{locale === 'fr' ? 'Pass\u00e9' : 'Past'}</div>}
      </div>
      <div className="p-5">
        <h3 className="font-display text-xl font-bold text-foreground mb-3">{locale === 'fr' ? event?.titleFr : event?.titleEn}</h3>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p className="flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" /> <SafeDate date={event?.date} options={{ dateStyle: 'full' }} /></p>
          {event?.time && <p className="flex items-center gap-2"><Clock className="w-4 h-4 text-primary" /> {event.time}</p>}
          <p className="flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" /> {event?.venue}, {event?.city}</p>
        </div>
        <p className="text-sm text-muted-foreground mt-3">{locale === 'fr' ? event?.descriptionFr : event?.descriptionEn}</p>
      </div>
    </div>
  );

  return (
    <>
      <Navbar />
      <section className="pt-28 pb-8 px-4">
        <div className="max-w-[1200px] mx-auto text-center">
          <motion.div {...fadeUp}>
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-3">{t('events.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('events.subtitle')}</p>
          </motion.div>
        </div>
      </section>

      {/* Upcoming */}
      <section className="px-4 pb-12">
        <div className="max-w-[1200px] mx-auto">
          <h2 className="font-display text-2xl font-bold text-foreground mb-8">{t('events.upcoming')}</h2>
          {(upcoming?.length ?? 0) === 0 ? (
            <div className="glass-card rounded-xl p-8 text-center">
              <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">{t('events.noUpcoming')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {(upcoming ?? []).map((event: any, i: number) => (
                <motion.div key={event?.id} {...fadeUp} transition={{ delay: i * 0.1 }}>
                  <EventCard event={event} />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Past */}
      {(past?.length ?? 0) > 0 && (
        <section className="px-4 pb-20">
          <div className="max-w-[1200px] mx-auto">
            <h2 className="font-display text-2xl font-bold text-muted-foreground mb-8">{t('events.past')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {(past ?? []).map((event: any, i: number) => (
                <motion.div key={event?.id} {...fadeUp} transition={{ delay: i * 0.1 }}>
                  <EventCard event={event} isPast />
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </>
  );
}
