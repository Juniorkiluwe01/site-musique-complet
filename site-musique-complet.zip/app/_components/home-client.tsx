'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { IMAGES } from '@/lib/constants';
import { useSiteSettings } from '@/lib/settings';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { Play, Calendar, ArrowRight, ShoppingBag, Mail, Music, ChevronRight, MessageCircle } from 'lucide-react';
import { toast } from 'sonner';
import { SafeDate } from '@/components/safe-format';

interface Props {
  albums: any[];
  latestReleases: any[];
  events: any[];
  news: any[];
  products: any[];
  gallery: any[];
}

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-50px' },
  transition: { duration: 0.6 },
};

const isYouTubeUrl = (url: string) => /youtube\.com|youtu\.be/.test(url || '');
const getYouTubeVideoId = (url: string) => (url || '').match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{11})/)?.[1];

export function HomeClient({ albums, latestReleases, events, news, products, gallery }: Props) {
  const { t, locale } = useI18n();
  const s = useSiteSettings();
  const { addItem } = useCart();
  const [fanName, setFanName] = useState('');
  const [fanMessage, setFanMessage] = useState('');

  const buildMessage = () => {
    const intro = locale === 'fr' ? 'Bonjour MC STAGGA GH' : 'Hi MC STAGGA GH';
    const from = fanName ? (locale === 'fr' ? `, c'est ${fanName}` : `, this is ${fanName}`) : '';
    return `${intro}${from}. ${fanMessage}`.trim();
  };

  const sendWhatsApp = () => {
    if (!fanMessage.trim()) { toast.error(locale === 'fr' ? 'Veuillez \u00e9crire un message.' : 'Please write a message.'); return; }
    window.open(`https://wa.me/${s.whatsapp}?text=${encodeURIComponent(buildMessage())}`, '_blank');
  };

  const sendEmail = () => {
    if (!fanMessage.trim()) { toast.error(locale === 'fr' ? 'Veuillez \u00e9crire un message.' : 'Please write a message.'); return; }
    const subject = locale === 'fr' ? `Message d'un fan${fanName ? ' - ' + fanName : ''}` : `Message from a fan${fanName ? ' - ' + fanName : ''}`;
    window.location.href = `mailto:${s.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(buildMessage())}`;
  };

  return (
    <>
      <Navbar />
      {/* Hero */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <Image src={IMAGES.heroOld} alt="MC Stagga GH on stage" fill className="object-cover" priority />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-background" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-black/60" />
        </div>
        <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="font-display text-5xl sm:text-7xl md:text-8xl font-bold text-gold-gradient mb-4 tracking-tight">MC STAGGA GH</h1>
          </motion.div>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4, duration: 0.8 }} className="text-lg sm:text-xl text-white/80 mb-8 font-light">
            {t('hero.slogan')}
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7, duration: 0.6 }} className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/music" className="inline-flex items-center gap-2 px-8 py-3.5 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-all glow-gold">
              <Play className="w-5 h-5" />
              {t('hero.cta')}
            </Link>
            <Link href="/bio" className="inline-flex items-center gap-2 px-8 py-3.5 bg-white/10 text-white font-semibold rounded-lg hover:bg-white/20 transition-all backdrop-blur-sm border border-white/10">
              {t('hero.explore')}
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
        {/* Scroll indicator */}
        <motion.div animate={{ y: [0, 8, 0] }} transition={{ repeat: Infinity, duration: 2 }} className="absolute bottom-8 left-1/2 -translate-x-1/2">
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-1">
            <div className="w-1.5 h-3 rounded-full bg-primary" />
          </div>
        </motion.div>
      </section>

      {/* Latest Releases */}
      <section className="py-20 px-4">
        <div className="max-w-[1200px] mx-auto">
          <motion.div {...fadeUp} className="flex items-center justify-between mb-12">
            <div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-gold-gradient">{t('home.latestReleases')}</h2>
            </div>
            <Link href="/music" className="hidden sm:flex items-center gap-1 text-sm text-primary hover:text-primary/80 transition-colors">
              {t('home.viewAll')} <ChevronRight className="w-4 h-4" />
            </Link>
          </motion.div>
          <div className={`grid gap-6 justify-items-center ${(latestReleases ?? []).length > 1 ? 'sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'}`}>
            {(latestReleases ?? []).map((rel: any, i: number) => {
              const title = locale === 'fr' ? rel?.titleFr : rel?.titleEn;
              const info = locale === 'fr' ? rel?.infoFr : rel?.infoEn;
              const ytId = rel?.type === 'video' && isYouTubeUrl(rel?.videoUrl) ? getYouTubeVideoId(rel?.videoUrl) : null;

              // VIDEO
              if (rel?.type === 'video') {
                return (
                  <motion.div key={rel?.id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.1 }} className="w-full max-w-sm">
                    <div className="glass-card rounded-xl overflow-hidden">
                      <div className="relative aspect-video bg-black">
                        {ytId ? (
                          <iframe src={`https://www.youtube.com/embed/${ytId}`} title={title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen className="absolute inset-0 w-full h-full" />
                        ) : rel?.videoUrl ? (
                          <video controls poster={rel?.image || undefined} className="absolute inset-0 w-full h-full object-cover"><source src={rel.videoUrl} /></video>
                        ) : (
                          <Image src={rel?.image || IMAGES.albumStreetsOfGold} alt={title} fill className="object-cover" />
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="font-display text-lg font-bold text-foreground">{title}</h3>
                        {info && <p className="text-sm text-muted-foreground mt-1">{info}</p>}
                      </div>
                    </div>
                  </motion.div>
                );
              }

              // NEWS (text-focused, image optional)
              if (rel?.type === 'news') {
                return (
                  <motion.div key={rel?.id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.1 }} className="w-full max-w-sm">
                    <Link href={rel?.linkUrl || '/news'} className="group block glass-card glass-card-hover rounded-xl overflow-hidden h-full">
                      {rel?.image && (
                        <div className="relative aspect-video">
                          <Image src={rel.image} alt={title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                        </div>
                      )}
                      <div className="p-5">
                        <span className="inline-block text-[11px] uppercase tracking-wide text-primary font-semibold mb-1">{locale === 'fr' ? 'Actualité' : 'News'}</span>
                        <h3 className="font-display text-lg font-bold text-foreground">{title}</h3>
                        {info && <p className="text-sm text-muted-foreground mt-2 whitespace-pre-line">{info}</p>}
                      </div>
                    </Link>
                  </motion.div>
                );
              }

              // PHOTO / MUSIC (default) — square cover
              return (
                <motion.div key={rel?.id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.1 }} className="w-full max-w-sm">
                  <Link href={rel?.linkUrl || '/music'} className="group block glass-card glass-card-hover rounded-xl overflow-hidden">
                    <div className="relative aspect-square">
                      <Image src={rel?.image || IMAGES.albumStreetsOfGold} alt={title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                      {rel?.type !== 'photo' && (
                        <div className="absolute bottom-3 right-3 p-2.5 bg-primary rounded-full text-primary-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                          <Play className="w-5 h-5" />
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-display text-lg font-bold text-foreground">{title}</h3>
                      {info && <p className="text-sm text-muted-foreground mt-1">{info}</p>}
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      {(events ?? []).length > 0 && (
      <section className="py-20 px-4 bg-secondary/30">
        <div className="max-w-[1200px] mx-auto">
          <motion.div {...fadeUp} className="flex items-center justify-between mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-gold-gradient">{t('home.upcomingEvents')}</h2>
            <Link href="/events" className="hidden sm:flex items-center gap-1 text-sm text-primary hover:text-primary/80 transition-colors">
              {t('home.viewAll')} <ChevronRight className="w-4 h-4" />
            </Link>
          </motion.div>
          <div className="space-y-4">
            {(events ?? []).map((event: any, i: number) => (
              <motion.div key={event?.id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.1 }}>
                <div className="glass-card glass-card-hover rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-14 h-14 rounded-lg bg-primary/10 flex flex-col items-center justify-center text-primary flex-shrink-0">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-foreground">{locale === 'fr' ? event?.titleFr : event?.titleEn}</h3>
                      <p className="text-sm text-muted-foreground">{event?.venue}, {event?.city} • <SafeDate date={event?.date} options={{ dateStyle: 'medium' }} /></p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      )}

      {/* Latest News */}
      {(news ?? []).length > 0 && (
      <section className="py-20 px-4">
        <div className="max-w-[1200px] mx-auto">
          <motion.div {...fadeUp} className="flex items-center justify-between mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-gold-gradient">{t('home.latestNews')}</h2>
            <Link href="/news" className="hidden sm:flex items-center gap-1 text-sm text-primary hover:text-primary/80 transition-colors">
              {t('home.viewAll')} <ChevronRight className="w-4 h-4" />
            </Link>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(news ?? []).map((article: any, i: number) => (
              <motion.div key={article?.id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.15 }}>
                <Link href={`/news/${article?.slug}`} className="group block glass-card glass-card-hover rounded-xl overflow-hidden">
                  <div className="p-5">
                    <p className="text-xs text-primary mb-2">{(article?.tags ?? []).join(' • ')}</p>
                    <h3 className="font-display font-bold text-foreground group-hover:text-primary transition-colors">{locale === 'fr' ? article?.titleFr : article?.titleEn}</h3>
                    <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{locale === 'fr' ? article?.excerptFr : article?.excerptEn}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      )}

      {/* Gallery */}
      {(gallery ?? []).length > 0 && (
        <section className="py-20 px-4 bg-secondary/30">
          <div className="max-w-[1200px] mx-auto">
            <motion.div {...fadeUp} className="flex items-center justify-between mb-12">
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-gold-gradient">{locale === 'fr' ? 'Galerie' : 'Gallery'}</h2>
              <Link href="/gallery" className="hidden sm:flex items-center gap-1 text-sm text-primary hover:text-primary/80 transition-colors">
                {t('home.viewAll')} <ChevronRight className="w-4 h-4" />
              </Link>
            </motion.div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {(gallery ?? []).map((photo: any, i: number) => (
                <motion.div key={photo?.id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.1 }}>
                  <Link href="/gallery" className="group block relative aspect-square rounded-xl overflow-hidden glass-card">
                    <Image src={photo?.url} alt={locale === 'fr' ? (photo?.titleFr ?? 'Photo') : (photo?.titleEn ?? 'Photo')} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors" />
                  </Link>
                </motion.div>
              ))}
            </div>
            <div className="mt-8 text-center sm:hidden">
              <Link href="/gallery" className="inline-flex items-center gap-1 text-sm text-primary hover:text-primary/80 transition-colors">
                {t('home.viewAll')} <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Shop Preview */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="max-w-[1200px] mx-auto">
          <motion.div {...fadeUp} className="flex items-center justify-between mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-gold-gradient">{t('home.shopPreview')}</h2>
            <Link href="/shop" className="hidden sm:flex items-center gap-1 text-sm text-primary hover:text-primary/80 transition-colors">
              {t('home.viewAll')} <ChevronRight className="w-4 h-4" />
            </Link>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {(products ?? []).slice(0, 3).map((product: any, i: number) => (
              <motion.div key={product?.id} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.15 }}>
                <div className="glass-card glass-card-hover rounded-xl overflow-hidden group">
                  <div className="relative aspect-square">
                    <Image src={product?.image || IMAGES.merchTshirt} alt={locale === 'fr' ? product?.nameFr : product?.nameEn} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-4">
                    <h3 className="font-display font-bold text-foreground">{locale === 'fr' ? product?.nameFr : product?.nameEn}</h3>
                    <div className="flex items-center justify-between mt-3">
                      <span className="text-primary font-bold text-lg">${product?.price?.toFixed?.(2) ?? '0.00'}</span>
                      <button
                        onClick={() => addItem({ id: product.id, type: 'product', name: locale === 'fr' ? product?.nameFr : product?.nameEn, price: product?.price ?? 0, image: product?.image })}
                        className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 transition-colors"
                      >
                        <ShoppingBag className="w-4 h-4 inline mr-1" />
                        {t('shop.addToCart')}
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Fan message (WhatsApp / Email) */}
      <section className="py-20 px-4">
        <div className="max-w-[600px] mx-auto text-center">
          <motion.div {...fadeUp}>
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <MessageCircle className="w-7 h-7 text-primary" />
            </div>
            <h2 className="font-display text-3xl font-bold text-gold-gradient mb-3">
              {locale === 'fr' ? 'Laissez un message' : 'Leave a message'}
            </h2>
            <p className="text-muted-foreground mb-8">
              {locale === 'fr'
                ? 'Envoyez directement votre message à MC STAGGA GH via WhatsApp ou email.'
                : 'Send your message directly to MC STAGGA GH via WhatsApp or email.'}
            </p>
            <div className="glass-card rounded-2xl p-6 sm:p-8 space-y-4 text-left">
              <input
                type="text"
                value={fanName}
                onChange={(e) => setFanName(e.target.value)}
                placeholder={locale === 'fr' ? 'Votre nom (facultatif)' : 'Your name (optional)'}
                className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <textarea
                rows={4}
                value={fanMessage}
                onChange={(e) => setFanMessage(e.target.value)}
                placeholder={locale === 'fr' ? 'Votre message...' : 'Your message...'}
                className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              />
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={sendWhatsApp}
                  className="flex-1 py-3 bg-[#25D366] text-black font-semibold rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-5 h-5" />
                  WhatsApp
                </button>
                <button
                  type="button"
                  onClick={sendEmail}
                  className="flex-1 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
                >
                  <Mail className="w-5 h-5" />
                  Email
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </>
  );
}
