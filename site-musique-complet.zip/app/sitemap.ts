import { MetadataRoute } from 'next';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const host = process.env.NEXTAUTH_URL || 'http://localhost:3000';
  const articles = await prisma.newsArticle.findMany({ where: { status: 'published' }, select: { slug: true, updatedAt: true } });

  const staticPages = ['', '/bio', '/music', '/gallery', '/videos', '/events', '/news', '/shop', '/contact'].map((path) => ({
    url: `${host}${path}`,
    lastModified: new Date(),
  }));

  const newsPages = articles.map((a: any) => ({
    url: `${host}/news/${a.slug}`,
    lastModified: a.updatedAt,
  }));

  return [...staticPages, ...newsPages];
}
