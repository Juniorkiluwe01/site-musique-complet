'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { useSiteSettings } from '@/lib/settings';
import { Send, Mail, Phone, Instagram, Facebook, Youtube, Music, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

export function ContactClient() {
  const { t, locale } = useI18n();
  const s = useSiteSettings();
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      if (res.ok) {
        setSent(true);
        toast.success(t('contact.success'));
        setForm({ name: '', email: '', subject: '', message: '' });
      } else {
        toast.error(t('contact.error'));
      }
    } catch {
      toast.error(t('contact.error'));
    }
    setLoading(false);
  };

  return (
    <>
      <Navbar />
      <section className="pt-28 pb-20 px-4">
        <div className="max-w-[1200px] mx-auto">
          <motion.div {...fadeUp} className="text-center mb-12">
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-3">{t('contact.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('contact.subtitle')}</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            {/* Form */}
            <motion.div {...fadeUp} className="lg:col-span-3">
              {sent ? (
                <div className="glass-card rounded-2xl p-12 text-center">
                  <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <h3 className="font-display text-2xl font-bold text-foreground mb-2">{t('contact.success')}</h3>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-6 sm:p-8 space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">{t('contact.name')}</label>
                      <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">{t('contact.email')}</label>
                      <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">{t('contact.subject')}</label>
                    <input type="text" required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">{t('contact.message')}</label>
                    <textarea required rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="w-full px-4 py-3 rounded-lg bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none" />
                  </div>
                  <button type="submit" disabled={loading} className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                    <Send className="w-5 h-5" />
                    {loading ? '...' : t('contact.send')}
                  </button>
                </form>
              )}
            </motion.div>

            {/* Info */}
            <motion.div {...fadeUp} transition={{ delay: 0.2 }} className="lg:col-span-2 space-y-6">
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-display text-lg font-bold text-foreground mb-4">Info</h3>
                <div className="space-y-3">
                  <a href={`mailto:${s.email}`} className="flex items-center gap-3 text-sm text-muted-foreground hover:text-primary transition-colors">
                    <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                    <span suppressHydrationWarning>{s.email}</span>
                  </a>
                  {s.emailSecondary && (
                  <a href={`mailto:${s.emailSecondary}`} className="flex items-center gap-3 text-sm text-muted-foreground hover:text-primary transition-colors">
                    <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                    <span suppressHydrationWarning>{s.emailSecondary}</span>
                  </a>
                  )}
                  <a href={`tel:${s.phone.replace(/\s/g, '')}`} className="flex items-center gap-3 text-sm text-muted-foreground hover:text-primary transition-colors">
                    <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                    <span suppressHydrationWarning>{s.phone}</span>
                  </a>
                </div>
              </div>

              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-display text-lg font-bold text-foreground mb-4">{t('contact.followUs')}</h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { icon: Instagram, label: 'Instagram', url: s.instagramUrl },
                    { icon: Facebook, label: 'Facebook', url: s.facebookUrl },
                    { icon: Youtube, label: 'YouTube', url: s.youtubeUrl },
                    { icon: Music, label: 'TikTok', url: s.tiktokUrl },
                  ].map((social) => (
                    <a key={social.label} href={social.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-white/5 hover:bg-primary/20 hover:text-primary transition-colors text-muted-foreground text-sm">
                      <social.icon className="w-4 h-4" />
                      {social.label}
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
