export const metadata = { title: 'Contact | MC STAGGA GH' };
import { ContactClient } from './contact-client';
export default function ContactPage() {
  return <ContactClient />;
}
