import { prisma } from '@/lib/db';
import { ShopClient } from './shop-client';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Shop | MC STAGGA GH' };

export default async function ShopPage() {
  const products = await prisma.product.findMany({ where: { published: true }, orderBy: { createdAt: 'desc' } });
  return <ShopClient products={JSON.parse(JSON.stringify(products))} />;
}
