'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { ShoppingBag, ShoppingCart, Minus, Plus, Trash2, X, Smartphone } from 'lucide-react';
import { toast } from 'sonner';
import { useSession } from 'next-auth/react';

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

export function ShopClient({ products }: { products: any[] }) {
  const { t, locale } = useI18n();
  const { items, addItem, removeItem, updateQuantity, clearCart, total, itemCount } = useCart();
  const [cartOpen, setCartOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const { data: session } = useSession();

  // Handle return from the payment page.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('cancelled') === 'true') {
      toast.error(locale === 'fr' ? 'Paiement annulé' : 'Payment cancelled');
      window.history.replaceState({}, '', '/shop');
      return;
    }
    const orderId = params.get('order');
    if (params.get('success') === 'true' && orderId) {
      (async () => {
        try {
          const res = await fetch('/api/checkout/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId }),
          });
          const data = await res.json();
          if (data?.paid) {
            clearCart();
            toast.success(locale === 'fr' ? 'Paiement réussi ! Merci pour votre achat.' : 'Payment successful! Thank you for your purchase.');
          } else {
            toast(locale === 'fr' ? 'Paiement en cours de traitement...' : 'Payment is being processed...');
          }
        } catch {
          toast.error(locale === 'fr' ? 'Impossible de vérifier le paiement' : 'Could not verify payment');
        } finally {
          window.history.replaceState({}, '', '/shop');
        }
      })();
    }
  }, []);

  const handleCheckout = async () => {
    if (items.length === 0 || loading) return;
    setLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items, email: (session?.user as any)?.email, method: 'mobile' }),
      });
      const data = await res.json();
      if (data?.url) {
        // Empty the cart as soon as the order is placed so it stays empty after payment.
        clearCart();
        window.location.href = data.url;
      } else {
        toast.error(data?.error || (locale === 'fr' ? 'Échec du paiement' : 'Checkout failed'));
        setLoading(false);
      }
    } catch {
      toast.error(locale === 'fr' ? 'Échec du paiement' : 'Checkout failed');
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <section className="pt-28 pb-8 px-4">
        <div className="max-w-[1200px] mx-auto text-center">
          <motion.div {...fadeUp}>
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-3">{t('shop.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('shop.subtitle')}</p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-20">
        <div className="max-w-[1200px] mx-auto">
          {/* Cart toggle */}
          <div className="flex justify-end mb-6">
            <button onClick={() => setCartOpen(true)} className="relative inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors">
              <ShoppingCart className="w-5 h-5" />
              {t('shop.cart')} ({itemCount})
            </button>
          </div>

          {/* Products grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {(products ?? []).map((product: any, i: number) => (
              <motion.div key={product?.id} {...fadeUp} transition={{ delay: i * 0.1 }}>
                <div className="glass-card glass-card-hover rounded-xl overflow-hidden group">
                  <div className="relative aspect-square bg-black/40 p-4">
                    {product?.video ? (
                      <video src={product.video} controls playsInline className="absolute inset-0 w-full h-full object-contain bg-black" poster={product?.image || undefined} />
                    ) : (
                      <Image src={product?.image || ''} alt={locale === 'fr' ? product?.nameFr : product?.nameEn} fill className="object-contain group-hover:scale-105 transition-transform duration-500" />
                    )}
                    {(product?.stock ?? 0) <= 0 && !product?.video && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                        <span className="text-white font-bold text-lg">{t('shop.outOfStock')}</span>
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <h3 className="font-display text-lg font-bold text-foreground">{locale === 'fr' ? product?.nameFr : product?.nameEn}</h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{locale === 'fr' ? product?.descriptionFr : product?.descriptionEn}</p>
                    <div className="flex items-center justify-between mt-4">
                      <span className="text-primary font-bold text-xl">${product?.price?.toFixed?.(2) ?? '0.00'}</span>
                      <button
                        onClick={() => {
                          addItem({ id: product.id, type: 'product', name: locale === 'fr' ? product?.nameFr : product?.nameEn, price: product?.price ?? 0, image: product?.image });
                          toast.success(locale === 'fr' ? 'Ajout\u00e9 !' : 'Added!');
                        }}
                        disabled={(product?.stock ?? 0) <= 0}
                        className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ShoppingBag className="w-4 h-4 inline mr-1" />
                        {t('shop.addToCart')}
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Cart Drawer */}
      <AnimatePresence>
        {cartOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 z-[90]" onClick={() => setCartOpen(false)} />
            <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 25 }} className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-card border-l border-border z-[95] flex flex-col">
              <div className="p-5 border-b border-border flex items-center justify-between">
                <h2 className="font-display text-xl font-bold">{t('shop.cart')} ({itemCount})</h2>
                <button onClick={() => setCartOpen(false)} className="p-1 hover:text-primary transition-colors"><X className="w-6 h-6" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                {items.length === 0 ? (
                  <div className="text-center py-12">
                    <ShoppingCart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">{t('shop.emptyCart')}</p>
                  </div>
                ) : (
                  items.map((item) => (
                    <div key={item.id} className="flex gap-4 glass-card rounded-lg p-3">
                      {item.image && (
                        <div className="relative w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                          <Image src={item.image} alt={item.name} fill className="object-cover" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{item.name}</p>
                        <p className="text-sm text-primary font-bold">${item.price.toFixed(2)}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="p-0.5 hover:text-primary"><Minus className="w-4 h-4" /></button>
                          <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="p-0.5 hover:text-primary"><Plus className="w-4 h-4" /></button>
                        </div>
                      </div>
                      <button onClick={() => removeItem(item.id)} className="p-1 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))
                )}
              </div>
              {items.length > 0 && (
                <div className="p-5 border-t border-border space-y-4">
                  <div className="flex justify-between text-lg font-bold">
                    <span>{t('shop.total')}</span>
                    <span className="text-primary">${total.toFixed(2)}</span>
                  </div>
                  <button onClick={handleCheckout} disabled={loading} className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                    <Smartphone className="w-5 h-5" />
                    {loading ? (locale === 'fr' ? 'Chargement...' : 'Loading...') : (locale === 'fr' ? 'Payer par Mobile Money' : 'Pay with Mobile Money')}
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <Footer />
    </>
  );
}
