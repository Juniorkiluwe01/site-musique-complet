import { prisma } from '@/lib/db';
import { OrdersAdminClient } from './orders-admin-client';
export const dynamic = 'force-dynamic';
export default async function AdminOrdersPage() {
  const orders = await prisma.order.findMany({ orderBy: { createdAt: 'desc' }, include: { items: { include: { song: true, product: true } }, user: true } });
  return <OrdersAdminClient orders={JSON.parse(JSON.stringify(orders))} />;
}
