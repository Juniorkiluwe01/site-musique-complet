'use client';
import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Package } from 'lucide-react';
import { SafeDate } from '@/components/safe-format';

export function OrdersAdminClient({ orders }: { orders: any[] }) {
  const { locale } = useI18n();
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Package className="w-6 h-6 text-primary" />
        <h2 className="font-display text-xl font-bold">{locale === 'fr' ? 'Commandes' : 'Orders'}</h2>
      </div>
      <div className="glass-card rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-border"><th className="text-left p-3 text-muted-foreground font-medium">ID</th><th className="text-left p-3 text-muted-foreground font-medium">Email</th><th className="text-left p-3 text-muted-foreground font-medium">Type</th><th className="text-left p-3 text-muted-foreground font-medium">Items</th><th className="text-left p-3 text-muted-foreground font-medium">Total</th><th className="text-left p-3 text-muted-foreground font-medium">Status</th><th className="text-left p-3 text-muted-foreground font-medium">Date</th></tr></thead>
          <tbody>
            {(orders ?? []).map((order: any) => (
              <tr key={order?.id} className="border-b border-border/50">
                <td className="p-3 font-mono text-xs text-foreground">{order?.id?.slice(0, 8)}</td>
                <td className="p-3 text-foreground">{order?.email}</td>
                <td className="p-3"><span className="text-xs uppercase text-primary">{order?.type}</span></td>
                <td className="p-3 text-muted-foreground text-xs">{(order?.items ?? []).map((i: any) => i?.song?.titleEn || i?.product?.nameEn || 'Item').join(', ')}</td>
                <td className="p-3 text-primary font-bold">${order?.total?.toFixed?.(2) ?? '0.00'}</td>
                <td className="p-3"><span className={`px-2 py-0.5 rounded text-xs font-medium ${order?.status === 'paid' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>{order?.status}</span></td>
                <td className="p-3 text-muted-foreground"><SafeDate date={order?.createdAt} options={{ dateStyle: 'short' }} /></td>
              </tr>
            ))}
            {(orders?.length ?? 0) === 0 && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No orders</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
