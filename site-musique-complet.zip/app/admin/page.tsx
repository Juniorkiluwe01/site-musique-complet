import { prisma } from '@/lib/db';
import { AdminOverviewClient } from './overview-client';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const [userCount, orderCount, songCount, productCount, newsletterCount, revenue] = await Promise.all([
    prisma.user.count({ where: { role: { not: 'admin' }, email: { not: { endsWith: '@example.com' } } } }),
    prisma.order.count({ where: { status: 'paid' } }),
    prisma.song.count(),
    prisma.product.count(),
    prisma.newsletter.count(),
    prisma.order.aggregate({ where: { status: 'paid' }, _sum: { total: true } }),
  ]);

  const recentOrders = await prisma.order.findMany({ orderBy: { createdAt: 'desc' }, take: 5, include: { user: true } });

  // Ventes de musique payées (téléchargements) pour le graphique de suivi
  const musicSales = await prisma.order.findMany({
    where: { type: 'music', status: 'paid' },
    select: { createdAt: true, total: true },
    orderBy: { createdAt: 'asc' },
  });

  return (
    <AdminOverviewClient
      stats={{
        users: userCount,
        orders: orderCount,
        songs: songCount,
        products: productCount,
        newsletter: newsletterCount,
        revenue: revenue?._sum?.total ?? 0,
      }}
      recentOrders={JSON.parse(JSON.stringify(recentOrders))}
      musicSales={JSON.parse(JSON.stringify(musicSales))}
    />
  );
}
