import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { AdminLayoutClient } from './admin-layout-client';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user) redirect('/auth');
  if ((session.user as any)?.role !== 'admin') redirect('/');
  return <AdminLayoutClient>{children}</AdminLayoutClient>;
}
