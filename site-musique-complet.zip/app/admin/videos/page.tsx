import { prisma } from '@/lib/db';
import { VideosAdminClient } from './videos-admin-client';

export const dynamic = 'force-dynamic';

export default async function AdminVideosPage() {
  const items = await prisma.galleryItem.findMany({ where: { type: 'video' }, orderBy: { createdAt: 'desc' } });
  return <VideosAdminClient items={JSON.parse(JSON.stringify(items))} />;
}
