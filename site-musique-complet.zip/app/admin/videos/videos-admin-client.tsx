'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Plus, Trash2, Play, Youtube } from 'lucide-react';
import { toast } from 'sonner';
import { FileUpload } from '@/components/admin/file-upload';

const emptyForm = { titleEn: '', titleFr: '', type: 'video', url: '', thumbnail: '', category: 'clips' };

function isYoutube(url: string) {
  return /youtube\.com|youtu\.be/.test(url || '');
}
function ytId(url: string) {
  const m = (url || '').match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{11})/);
  return m ? m[1] : null;
}

export function VideosAdminClient({ items }: { items: any[] }) {
  const { locale } = useI18n();
  const fr = locale === 'fr';
  const router = useRouter();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<any>(emptyForm);
  const [loading, setLoading] = useState(false);

  const categories = [
    { value: 'clips', label: fr ? 'Clips' : 'Clips' },
    { value: 'live', label: fr ? 'Live / Concerts' : 'Live / Concerts' },
    { value: 'behind', label: fr ? 'Coulisses' : 'Behind the scenes' },
    { value: 'general', label: fr ? 'Général' : 'General' },
  ];

  const handleSave = async () => {
    if (!form.url) { toast.error(fr ? 'Ajoutez une vidéo ou un lien YouTube' : 'Add a video file or YouTube link'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/admin/gallery', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, type: 'video' }) });
      if (res.ok) { toast.success(fr ? 'Vidéo ajoutée !' : 'Video added!'); setShowForm(false); setForm(emptyForm); router.refresh(); }
      else toast.error(fr ? 'Échec' : 'Failed');
    } catch { toast.error(fr ? 'Erreur' : 'Error'); }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm(fr ? 'Supprimer cette vidéo ?' : 'Delete this video?')) return;
    const res = await fetch(`/api/admin/gallery?id=${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success(fr ? 'Supprimée' : 'Deleted'); router.refresh(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-bold">{fr ? 'Gérer les Vidéos' : 'Manage Videos'}</h2>
          <p className="text-sm text-muted-foreground">{fr ? 'Téléversez des clips depuis votre ordinateur ou collez un lien YouTube.' : 'Upload clips from your computer or paste a YouTube link.'}</p>
        </div>
        {!showForm && (
          <button onClick={() => { setForm(emptyForm); setShowForm(true); }} className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg flex items-center gap-2 shrink-0"><Plus className="w-4 h-4" />{fr ? 'Ajouter' : 'Add'}</button>
        )}
      </div>

      {showForm && (
        <div className="glass-card rounded-xl p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder={fr ? 'Titre (EN)' : 'Title (EN)'} value={form.titleEn} onChange={(e) => setForm({ ...form, titleEn: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder={fr ? 'Titre (FR)' : 'Title (FR)'} value={form.titleFr} onChange={(e) => setForm({ ...form, titleFr: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm md:col-span-2">
              {categories.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
            <div className="col-span-full space-y-2">
              <FileUpload label={fr ? 'Fichier vidéo (depuis votre PC)' : 'Video file (from your PC)'} kind="video" value={isYoutube(form.url) ? '' : form.url} onChange={(url) => setForm({ ...form, url })} />
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />{fr ? 'ou' : 'or'}<span className="h-px flex-1 bg-border" /></div>
              <div className="relative">
                <Youtube className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
                <input placeholder={fr ? 'Collez un lien YouTube' : 'Paste a YouTube link'} value={isYoutube(form.url) ? form.url : ''} onChange={(e) => setForm({ ...form, url: e.target.value })} className="w-full pl-9 pr-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
              </div>
            </div>
            <div className="col-span-full">
              <FileUpload label={fr ? 'Miniature (optionnel)' : 'Thumbnail (optional)'} kind="image" value={form.thumbnail} onChange={(thumbnail) => setForm({ ...form, thumbnail })} />
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={loading} className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg disabled:opacity-50">{loading ? '...' : (fr ? 'Enregistrer' : 'Save')}</button>
            <button onClick={() => { setShowForm(false); setForm(emptyForm); }} className="px-5 py-2 bg-secondary text-foreground text-sm rounded-lg">{fr ? 'Annuler' : 'Cancel'}</button>
          </div>
        </div>
      )}

      {(items ?? []).length === 0 ? (
        <div className="glass-card rounded-xl p-8 text-center text-muted-foreground">{fr ? 'Aucune vidéo pour le moment.' : 'No videos yet.'}</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {(items ?? []).map((item: any) => {
            const yt = ytId(item?.url);
            const thumb = item?.thumbnail || (yt ? `https://i.ytimg.com/vi/FHuEORAO9GY/maxresdefault.jpg` : '');
            return (
              <div key={item?.id} className="glass-card rounded-xl overflow-hidden group">
                <div className="relative aspect-video bg-black">
                  {yt || thumb ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={thumb} alt={item?.titleEn || 'video'} className="w-full h-full object-cover" />
                  ) : (
                    <video src={item?.url} className="w-full h-full object-cover" muted />
                  )}
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-primary/90 flex items-center justify-center"><Play className="w-5 h-5 text-primary-foreground ml-0.5" /></div>
                  </div>
                  {yt && <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-semibold flex items-center gap-1"><Youtube className="w-3 h-3" />YouTube</span>}
                  <button onClick={() => handleDelete(item.id)} className="absolute top-2 right-2 p-1.5 bg-black/60 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity text-white hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
                </div>
                <div className="p-3">
                  <p className="text-sm font-medium text-foreground truncate">{(fr ? item?.titleFr : item?.titleEn) || item?.titleEn || (fr ? 'Sans titre' : 'Untitled')}</p>
                  <p className="text-xs text-muted-foreground capitalize">{item?.category}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
