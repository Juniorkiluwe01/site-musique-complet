import { prisma } from '@/lib/db';
import { NewsletterAdminClient } from './newsletter-admin-client';
export const dynamic = 'force-dynamic';
export default async function AdminNewsletterPage() {
  const subscribers = await prisma.newsletter.findMany({ orderBy: { createdAt: 'desc' } });
  return <NewsletterAdminClient subscribers={JSON.parse(JSON.stringify(subscribers))} />;
}
