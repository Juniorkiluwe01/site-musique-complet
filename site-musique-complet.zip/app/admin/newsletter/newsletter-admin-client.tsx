'use client';
import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Mail, Users } from 'lucide-react';
import { SafeDate } from '@/components/safe-format';

export function NewsletterAdminClient({ subscribers }: { subscribers: any[] }) {
  const { locale } = useI18n();
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Mail className="w-6 h-6 text-primary" />
        <h2 className="font-display text-xl font-bold">{locale === 'fr' ? 'Abonn\u00e9s Newsletter' : 'Newsletter Subscribers'}</h2>
        <span className="px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-full font-bold">{subscribers?.length ?? 0}</span>
      </div>
      <div className="glass-card rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-border"><th className="text-left p-3 text-muted-foreground font-medium">Email</th><th className="text-left p-3 text-muted-foreground font-medium">Status</th><th className="text-left p-3 text-muted-foreground font-medium">Date</th></tr></thead>
          <tbody>
            {(subscribers ?? []).map((sub: any) => (
              <tr key={sub?.id} className="border-b border-border/50">
                <td className="p-3 text-foreground">{sub?.email}</td>
                <td className="p-3"><span className={`px-2 py-0.5 rounded text-xs font-medium ${sub?.active ? 'bg-green-500/20 text-green-400' : 'bg-muted text-muted-foreground'}`}>{sub?.active ? 'Active' : 'Inactive'}</span></td>
                <td className="p-3 text-muted-foreground"><SafeDate date={sub?.createdAt} options={{ dateStyle: 'medium' }} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
