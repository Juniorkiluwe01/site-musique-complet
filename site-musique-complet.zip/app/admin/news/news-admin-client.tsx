'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Plus, Edit, Trash2, Newspaper } from 'lucide-react';
import { toast } from 'sonner';
import { FileUpload } from '@/components/admin/file-upload';

export function NewsAdminClient({ articles }: { articles: any[] }) {
  const { locale } = useI18n();
  const router = useRouter();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ titleEn: '', titleFr: '', slug: '', contentEn: '', contentFr: '', excerptEn: '', excerptFr: '', image: '', tags: '', status: 'published' });
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const payload = { ...form, tags: form.tags.split(',').map((t: string) => t.trim()).filter(Boolean) };
      const res = await fetch('/api/admin/news', { method: editing ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editing ? { ...payload, id: editing.id } : payload) });
      if (res.ok) { toast.success('Saved!'); setShowForm(false); setEditing(null); router.refresh(); } else toast.error('Failed');
    } catch { toast.error('Error'); }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return;
    const res = await fetch(`/api/admin/news?id=${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success('Deleted'); router.refresh(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold">{locale === 'fr' ? 'G\u00e9rer les Actualit\u00e9s' : 'Manage News'}</h2>
        <button onClick={() => { setEditing(null); setForm({ titleEn: '', titleFr: '', slug: '', contentEn: '', contentFr: '', excerptEn: '', excerptFr: '', image: '', tags: '', status: 'published' }); setShowForm(true); }} className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg flex items-center gap-2"><Plus className="w-4 h-4" />Add</button>
      </div>
      {showForm && (
        <div className="glass-card rounded-xl p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder="Title (EN)" value={form.titleEn} onChange={(e) => setForm({ ...form, titleEn: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Titre (FR)" value={form.titleFr} onChange={(e) => setForm({ ...form, titleFr: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Slug (url-friendly)" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <div className="col-span-full"><FileUpload label={locale === 'fr' ? "Image de l'article" : 'Article image'} kind="image" value={form.image} onChange={(url) => setForm({ ...form, image: url })} /></div>
            <input placeholder="Tags (comma separated)" value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm">
              <option value="published">Published</option><option value="draft">Draft</option>
            </select>
            <textarea placeholder="Content (EN)" value={form.contentEn} onChange={(e) => setForm({ ...form, contentEn: e.target.value })} rows={4} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm col-span-full" />
            <textarea placeholder="Contenu (FR)" value={form.contentFr} onChange={(e) => setForm({ ...form, contentFr: e.target.value })} rows={4} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm col-span-full" />
          </div>
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={loading} className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg disabled:opacity-50">{loading ? '...' : 'Save'}</button>
            <button onClick={() => setShowForm(false)} className="px-5 py-2 bg-secondary text-foreground text-sm rounded-lg">Cancel</button>
          </div>
        </div>
      )}
      <div className="space-y-3">
        {(articles ?? []).map((a: any) => (
          <div key={a?.id} className="glass-card rounded-xl p-4 flex items-center gap-4">
            <Newspaper className="w-6 h-6 text-primary flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground text-sm">{a?.titleEn}</h3>
              <p className="text-xs text-muted-foreground">{a?.status} • {(a?.tags ?? []).join(', ')}</p>
            </div>
            <div className="flex gap-1">
              <button onClick={() => { setEditing(a); setForm({ titleEn: a.titleEn, titleFr: a.titleFr, slug: a.slug, contentEn: a.contentEn, contentFr: a.contentFr, excerptEn: a.excerptEn || '', excerptFr: a.excerptFr || '', image: a.image || '', tags: (a.tags || []).join(', '), status: a.status }); setShowForm(true); }} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary"><Edit className="w-4 h-4" /></button>
              <button onClick={() => handleDelete(a.id)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
