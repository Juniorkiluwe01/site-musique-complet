import { prisma } from '@/lib/db';
import { NewsAdminClient } from './news-admin-client';
export const dynamic = 'force-dynamic';
export default async function AdminNewsPage() {
  const articles = await prisma.newsArticle.findMany({ orderBy: { createdAt: 'desc' } });
  return <NewsAdminClient articles={JSON.parse(JSON.stringify(articles))} />;
}
