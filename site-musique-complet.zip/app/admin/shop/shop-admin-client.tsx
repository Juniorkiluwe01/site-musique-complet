'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { FileUpload } from '@/components/admin/file-upload';

export function ShopAdminClient({ products }: { products: any[] }) {
  const { locale } = useI18n();
  const router = useRouter();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ nameEn: '', nameFr: '', price: '', image: '', video: '', category: 'merch', stock: '0', descriptionEn: '', descriptionFr: '' });
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/products', {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...(editing ? { id: editing.id } : {}), ...form, price: parseFloat(form.price) || 0, stock: parseInt(form.stock) || 0 }),
      });
      if (res.ok) { toast.success('Saved!'); setShowForm(false); setEditing(null); router.refresh(); }
      else toast.error('Failed');
    } catch { toast.error('Error'); }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return;
    const res = await fetch(`/api/admin/products?id=${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success('Deleted'); router.refresh(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold">{locale === 'fr' ? 'G\u00e9rer la Boutique' : 'Manage Shop'}</h2>
        <button onClick={() => { setEditing(null); setForm({ nameEn: '', nameFr: '', price: '', image: '', video: '', category: 'merch', stock: '0', descriptionEn: '', descriptionFr: '' }); setShowForm(true); }} className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 flex items-center gap-2">
          <Plus className="w-4 h-4" />{locale === 'fr' ? 'Ajouter Produit' : 'Add Product'}
        </button>
      </div>

      {showForm && (
        <div className="glass-card rounded-xl p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder="Name (EN)" value={form.nameEn} onChange={(e) => setForm({ ...form, nameEn: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Nom (FR)" value={form.nameFr} onChange={(e) => setForm({ ...form, nameFr: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Price ($)" type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Stock" type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <div className="col-span-full"><FileUpload label={locale === 'fr' ? 'Image du produit' : 'Product image'} kind="image" value={form.image} onChange={(url) => setForm({ ...form, image: url })} /></div>
            <div className="col-span-full"><FileUpload label={locale === 'fr' ? 'Vidéo du produit (optionnel)' : 'Product video (optional)'} kind="video" value={form.video} onChange={(url) => setForm({ ...form, video: url })} /></div>
            <textarea placeholder="Description (EN)" value={form.descriptionEn} onChange={(e) => setForm({ ...form, descriptionEn: e.target.value })} rows={2} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <textarea placeholder="Description (FR)" value={form.descriptionFr} onChange={(e) => setForm({ ...form, descriptionFr: e.target.value })} rows={2} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
          </div>
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={loading} className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg disabled:opacity-50">{loading ? '...' : 'Save'}</button>
            <button onClick={() => setShowForm(false)} className="px-5 py-2 bg-secondary text-foreground text-sm rounded-lg">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(products ?? []).map((p: any) => (
          <div key={p?.id} className="glass-card rounded-xl p-4 flex items-center gap-4">
            <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-secondary">
              {p?.image && <Image src={p.image} alt="" fill className="object-cover" />}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground text-sm">{p?.nameEn}</h3>
              <p className="text-xs text-muted-foreground">${p?.price?.toFixed?.(2)} • Stock: {p?.stock}</p>
            </div>
            <div className="flex gap-1">
              <button onClick={() => { setEditing(p); setForm({ nameEn: p.nameEn, nameFr: p.nameFr, price: String(p.price), image: p.image || '', video: p.video || '', category: p.category, stock: String(p.stock), descriptionEn: p.descriptionEn || '', descriptionFr: p.descriptionFr || '' }); setShowForm(true); }} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary"><Edit className="w-4 h-4" /></button>
              <button onClick={() => handleDelete(p.id)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
