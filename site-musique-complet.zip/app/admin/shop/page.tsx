import { prisma } from '@/lib/db';
import { ShopAdminClient } from './shop-admin-client';

export const dynamic = 'force-dynamic';

export default async function AdminShopPage() {
  const products = await prisma.product.findMany({ orderBy: { createdAt: 'desc' } });
  return <ShopAdminClient products={JSON.parse(JSON.stringify(products))} />;
}
