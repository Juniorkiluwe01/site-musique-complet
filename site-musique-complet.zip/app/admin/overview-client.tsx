'use client';

import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Users, DollarSign, Music, ShoppingBag, Mail, Package, Download, TrendingUp } from 'lucide-react';
import { SafeDate } from '@/components/safe-format';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

interface MusicSale { createdAt: string; total: number }

interface Props {
  stats: { users: number; orders: number; songs: number; products: number; newsletter: number; revenue: number };
  recentOrders: any[];
  musicSales?: MusicSale[];
}

type Granularity = 'day' | 'week' | 'month';

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  const day = (x.getDay() + 6) % 7; // lundi = 0
  x.setDate(x.getDate() - day);
  x.setHours(0, 0, 0, 0);
  return x;
}

function buildSeries(sales: MusicSale[], granularity: Granularity, locale: string) {
  const periods = granularity === 'day' ? 14 : granularity === 'week' ? 12 : 12;
  const now = new Date();
  const buckets: { key: string; label: string; start: Date }[] = [];

  for (let i = periods - 1; i >= 0; i--) {
    let start: Date;
    let label: string;
    if (granularity === 'day') {
      start = new Date(now);
      start.setDate(now.getDate() - i);
      start.setHours(0, 0, 0, 0);
      label = start.toLocaleDateString(locale === 'fr' ? 'fr-FR' : 'en-US', { day: '2-digit', month: 'short' });
    } else if (granularity === 'week') {
      start = startOfWeek(now);
      start.setDate(start.getDate() - i * 7);
      label = (locale === 'fr' ? 'sem. ' : 'wk ') + start.toLocaleDateString(locale === 'fr' ? 'fr-FR' : 'en-US', { day: '2-digit', month: 'short' });
    } else {
      start = new Date(now.getFullYear(), now.getMonth() - i, 1);
      label = start.toLocaleDateString(locale === 'fr' ? 'fr-FR' : 'en-US', { month: 'short', year: '2-digit' });
    }
    buckets.push({ key: start.toISOString(), label, start });
  }

  const series = buckets.map((b) => ({ label: b.label, revenue: 0, downloads: 0, start: b.start }));

  for (const s of sales) {
    const d = new Date(s.createdAt);
    let idx = -1;
    for (let i = 0; i < series.length; i++) {
      const cur = series[i].start;
      const next = i + 1 < series.length ? series[i + 1].start : null;
      if (d >= cur && (next === null || d < next)) { idx = i; break; }
    }
    if (idx >= 0) {
      series[idx].revenue += Number(s.total) || 0;
      series[idx].downloads += 1;
    }
  }

  return series.map(({ label, revenue, downloads }) => ({ label, revenue: Math.round(revenue * 100) / 100, downloads }));
}

export function AdminOverviewClient({ stats, recentOrders, musicSales = [] }: Props) {
  const { locale } = useI18n();
  const [granularity, setGranularity] = React.useState<Granularity>('month');

  const series = React.useMemo(() => buildSeries(musicSales, granularity, locale), [musicSales, granularity, locale]);
  const totalDownloads = musicSales?.length ?? 0;
  const totalMusicRevenue = (musicSales ?? []).reduce((sum, s) => sum + (Number(s.total) || 0), 0);

  const cards = [
    { label: locale === 'fr' ? 'Revenus' : 'Revenue', value: `$${(stats?.revenue ?? 0).toFixed(2)}`, icon: DollarSign, color: 'text-green-400' },
    { label: locale === 'fr' ? 'Commandes' : 'Orders', value: stats?.orders ?? 0, icon: Package, color: 'text-blue-400' },
    { label: 'Fans', value: stats?.users ?? 0, icon: Users, color: 'text-purple-400' },
    { label: locale === 'fr' ? 'Chansons' : 'Songs', value: stats?.songs ?? 0, icon: Music, color: 'text-primary' },
    { label: locale === 'fr' ? 'Produits' : 'Products', value: stats?.products ?? 0, icon: ShoppingBag, color: 'text-orange-400' },
    { label: 'Newsletter', value: stats?.newsletter ?? 0, icon: Mail, color: 'text-pink-400' },
  ];

  const granLabels: Record<Granularity, string> = {
    day: locale === 'fr' ? 'Jour' : 'Day',
    week: locale === 'fr' ? 'Semaine' : 'Week',
    month: locale === 'fr' ? 'Mois' : 'Month',
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="glass-card rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-5 h-5 ${card.color}`} />
                <span className="text-xs text-muted-foreground">{card.label}</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{card.value}</p>
            </div>
          );
        })}
      </div>

      {/* Graphique de suivi des ventes de musique (téléchargements) */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h2 className="font-display text-lg font-bold text-foreground flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              {locale === 'fr' ? 'Suivi des ventes de musique' : 'Music Sales Tracking'}
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              {locale === 'fr'
                ? 'Revenus des téléchargements payés dans le temps'
                : 'Revenue from paid downloads over time'}
            </p>
          </div>
          <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
            {(['day', 'week', 'month'] as Granularity[]).map((g) => (
              <button
                key={g}
                onClick={() => setGranularity(g)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  granularity === g
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {granLabels[g]}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/15 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{locale === 'fr' ? 'Total musique payée' : 'Total music paid'}</p>
              <p className="text-xl font-bold text-foreground">${totalMusicRevenue.toFixed(2)}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center">
              <Download className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{locale === 'fr' ? 'Téléchargements payés' : 'Paid downloads'}</p>
              <p className="text-xl font-bold text-foreground">{totalDownloads}</p>
            </div>
          </div>
        </div>

        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <BarChart data={series} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 11 }} tickLine={false} axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} />
              <YAxis tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                contentStyle={{ background: '#18181b', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff', fontSize: 12 }}
                formatter={(value: any, name: any) => {
                  if (name === 'revenue') return [`$${Number(value).toFixed(2)}`, locale === 'fr' ? 'Revenus' : 'Revenue'];
                  return [value, locale === 'fr' ? 'Téléchargements' : 'Downloads'];
                }}
              />
              <Bar dataKey="revenue" fill="#d4af37" radius={[4, 4, 0, 0]} maxBarSize={48} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        {totalDownloads === 0 && (
          <p className="text-center text-sm text-muted-foreground mt-4">
            {locale === 'fr'
              ? 'Aucune vente de musique payée pour le moment — le graphique se remplira automatiquement.'
              : 'No paid music sales yet — the chart will fill in automatically.'}
          </p>
        )}
      </div>

      {/* Recent orders */}
      <div className="glass-card rounded-xl p-6">
        <h2 className="font-display text-lg font-bold text-foreground mb-4">{locale === 'fr' ? 'Commandes Récentes' : 'Recent Orders'}</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 text-muted-foreground font-medium">ID</th>
                <th className="text-left py-2 text-muted-foreground font-medium">Email</th>
                <th className="text-left py-2 text-muted-foreground font-medium">Total</th>
                <th className="text-left py-2 text-muted-foreground font-medium">Status</th>
                <th className="text-left py-2 text-muted-foreground font-medium">Date</th>
              </tr>
            </thead>
            <tbody>
              {(recentOrders ?? []).map((order: any) => (
                <tr key={order?.id} className="border-b border-border/50">
                  <td className="py-2.5 text-foreground font-mono text-xs">{order?.id?.slice(0, 8)}</td>
                  <td className="py-2.5 text-foreground">{order?.email}</td>
                  <td className="py-2.5 text-primary font-bold">${order?.total?.toFixed?.(2) ?? '0.00'}</td>
                  <td className="py-2.5"><span className={`px-2 py-0.5 rounded text-xs font-medium ${order?.status === 'paid' ? 'bg-green-500/20 text-green-400' : order?.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-muted text-muted-foreground'}`}>{order?.status}</span></td>
                  <td className="py-2.5 text-muted-foreground"><SafeDate date={order?.createdAt} options={{ dateStyle: 'short' }} /></td>
                </tr>
              ))}
              {(recentOrders?.length ?? 0) === 0 && (
                <tr><td colSpan={5} className="py-8 text-center text-muted-foreground">{locale === 'fr' ? 'Aucune commande' : 'No orders yet'}</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
