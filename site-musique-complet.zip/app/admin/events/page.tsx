import { prisma } from '@/lib/db';
import { EventsAdminClient } from './events-admin-client';
export const dynamic = 'force-dynamic';
export default async function AdminEventsPage() {
  const events = await prisma.event.findMany({ orderBy: { date: 'desc' } });
  return <EventsAdminClient events={JSON.parse(JSON.stringify(events))} />;
}
