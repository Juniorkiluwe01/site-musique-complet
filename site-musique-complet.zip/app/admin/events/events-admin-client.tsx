'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Plus, Edit, Trash2, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import { SafeDate } from '@/components/safe-format';
import { FileUpload } from '@/components/admin/file-upload';

export function EventsAdminClient({ events }: { events: any[] }) {
  const { locale } = useI18n();
  const router = useRouter();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ titleEn: '', titleFr: '', venue: '', city: '', date: '', time: '', descriptionEn: '', descriptionFr: '', bookingUrl: '', image: '', isPast: false });
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/events', { method: editing ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editing ? { ...form, id: editing.id } : form) });
      if (res.ok) { toast.success('Saved!'); setShowForm(false); setEditing(null); router.refresh(); } else toast.error('Failed');
    } catch { toast.error('Error'); }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete?')) return;
    const res = await fetch(`/api/admin/events?id=${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success('Deleted'); router.refresh(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold">{locale === 'fr' ? 'G\u00e9rer les Concerts' : 'Manage Events'}</h2>
        <button onClick={() => { setEditing(null); setForm({ titleEn: '', titleFr: '', venue: '', city: '', date: '', time: '', descriptionEn: '', descriptionFr: '', bookingUrl: '', image: '', isPast: false }); setShowForm(true); }} className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg flex items-center gap-2"><Plus className="w-4 h-4" />Add</button>
      </div>
      {showForm && (
        <div className="glass-card rounded-xl p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder="Title (EN)" value={form.titleEn} onChange={(e) => setForm({ ...form, titleEn: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Titre (FR)" value={form.titleFr} onChange={(e) => setForm({ ...form, titleFr: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Venue" value={form.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Time (e.g. 20:00)" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Booking URL" value={form.bookingUrl} onChange={(e) => setForm({ ...form, bookingUrl: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <div className="col-span-full"><FileUpload label={locale === 'fr' ? "Image de l'événement" : 'Event image'} kind="image" value={form.image} onChange={(url) => setForm({ ...form, image: url })} /></div>
            <label className="flex items-center gap-2 text-sm text-foreground"><input type="checkbox" checked={form.isPast} onChange={(e) => setForm({ ...form, isPast: e.target.checked })} />Past event</label>
          </div>
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={loading} className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg disabled:opacity-50">{loading ? '...' : 'Save'}</button>
            <button onClick={() => setShowForm(false)} className="px-5 py-2 bg-secondary text-foreground text-sm rounded-lg">Cancel</button>
          </div>
        </div>
      )}
      <div className="space-y-3">
        {(events ?? []).map((ev: any) => (
          <div key={ev?.id} className="glass-card rounded-xl p-4 flex items-center gap-4">
            <Calendar className="w-8 h-8 text-primary flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-foreground text-sm">{ev?.titleEn}</h3>
              <p className="text-xs text-muted-foreground">{ev?.venue}, {ev?.city} • <SafeDate date={ev?.date} options={{ dateStyle: 'medium' }} /> {ev?.isPast ? '(Past)' : ''}</p>
            </div>
            <div className="flex gap-1">
              <button onClick={() => { setEditing(ev); setForm({ titleEn: ev.titleEn, titleFr: ev.titleFr, venue: ev.venue, city: ev.city, date: ev.date ? new Date(ev.date).toISOString().split('T')[0] : '', time: ev.time || '', descriptionEn: ev.descriptionEn || '', descriptionFr: ev.descriptionFr || '', bookingUrl: ev.bookingUrl || '', image: ev.image || '', isPast: ev.isPast }); setShowForm(true); }} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary"><Edit className="w-4 h-4" /></button>
              <button onClick={() => handleDelete(ev.id)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
