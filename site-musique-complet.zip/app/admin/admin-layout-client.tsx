'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { signOut } from 'next-auth/react';
import { LayoutDashboard, Music, Video, Disc3, ShoppingBag, Calendar, Newspaper, Image as ImageIcon, Mail, Package, Users, Settings, LogOut, Menu, X, Home, Globe } from 'lucide-react';

const sidebarLinks = [
  { href: '/admin', icon: LayoutDashboard, key: 'Overview' },
  { href: '/admin/music', icon: Music, key: 'Music' },
  { href: '/admin/latest-releases', icon: Disc3, key: 'Latest Releases' },
  { href: '/admin/videos', icon: Video, key: 'Videos' },
  { href: '/admin/shop', icon: ShoppingBag, key: 'Shop' },
  { href: '/admin/events', icon: Calendar, key: 'Events' },
  { href: '/admin/news', icon: Newspaper, key: 'News' },
  { href: '/admin/gallery', icon: ImageIcon, key: 'Gallery' },
  { href: '/admin/newsletter', icon: Mail, key: 'Newsletter' },
  { href: '/admin/orders', icon: Package, key: 'Orders' },
  { href: '/admin/users', icon: Users, key: 'Users' },
  { href: '/admin/settings', icon: Settings, key: 'Settings' },
];

export function AdminLayoutClient({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { locale, setLocale } = useI18n();
  const [sideOpen, setSideOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-card border-r border-border flex flex-col transition-transform lg:translate-x-0 ${sideOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-4 border-b border-border flex items-center justify-between">
          <Link href="/admin" className="font-display text-lg font-bold text-gold-gradient">MC STAGGA GH</Link>
          <button onClick={() => setSideOpen(false)} className="lg:hidden text-muted-foreground"><X className="w-5 h-5" /></button>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {sidebarLinks.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href || (link.href !== '/admin' && pathname?.startsWith(link.href));
            return (
              <Link key={link.href} href={link.href} onClick={() => setSideOpen(false)} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${isActive ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-white/5'}`}>
                <Icon className="w-5 h-5" />
                {link.key}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border space-y-1">
          <Link href="/" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-white/5">
            <Home className="w-5 h-5" />View Site
          </Link>
          <button onClick={() => setLocale(locale === 'en' ? 'fr' : 'en')} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-white/5">
            <Globe className="w-5 h-5" />{locale === 'en' ? 'Français' : 'English'}
          </button>
          <button onClick={() => signOut({ redirectTo: '/' })} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-muted-foreground hover:text-destructive hover:bg-white/5">
            <LogOut className="w-5 h-5" />Sign Out
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sideOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSideOpen(false)} />}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 h-14 bg-card/80 backdrop-blur-xl border-b border-border flex items-center px-4 gap-4">
          <button onClick={() => setSideOpen(true)} className="lg:hidden text-muted-foreground"><Menu className="w-5 h-5" /></button>
          <h1 className="font-display text-lg font-bold text-foreground">
            {sidebarLinks.find((l) => l.href === pathname || (l.href !== '/admin' && pathname?.startsWith(l.href)))?.key || 'Dashboard'}
          </h1>
        </header>
        <main className="flex-1 p-4 sm:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
