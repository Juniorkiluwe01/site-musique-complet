'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Plus, Edit, Trash2, Music, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';
import { SafeDate } from '@/components/safe-format';
import { FileUpload } from '@/components/admin/file-upload';

const emptyAlbum = { titleEn: '', titleFr: '', type: 'album', releaseDate: '', coverImage: '', descriptionEn: '', descriptionFr: '' };
const emptySong = { titleEn: '', titleFr: '', trackNumber: '1', price: '1.00', duration: '0', audioFile: '', previewFile: '' };

export function MusicAdminClient({ albums }: { albums: any[] }) {
  const { locale } = useI18n();
  const router = useRouter();
  const fr = locale === 'fr';

  // Album form state
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ ...emptyAlbum });
  const [loading, setLoading] = useState(false);
  // Quick audio upload directly from the album form (create album + first song in one go)
  const emptyQuick = { titleEn: '', titleFr: '', price: '1.00', audioFile: '', previewFile: '', duration: '0' };
  const [quick, setQuick] = useState({ ...emptyQuick });

  // Auto-detect duration for the quick-upload audio
  useEffect(() => {
    if (!quick.audioFile) return;
    const audio = new Audio();
    audio.src = quick.audioFile;
    const onMeta = () => {
      if (!isNaN(audio.duration) && isFinite(audio.duration)) {
        setQuick((q) => ({ ...q, duration: String(Math.round(audio.duration)) }));
      }
    };
    audio.addEventListener('loadedmetadata', onMeta);
    return () => audio.removeEventListener('loadedmetadata', onMeta);
  }, [quick.audioFile]);

  // Song management state
  const [expanded, setExpanded] = useState<string | null>(null);
  const [songAlbumId, setSongAlbumId] = useState<string | null>(null);
  const [songEditing, setSongEditing] = useState<any>(null);
  const [songForm, setSongForm] = useState({ ...emptySong });
  const [songLoading, setSongLoading] = useState(false);

  // Auto-detect duration when an audio file is set
  useEffect(() => {
    if (!songForm.audioFile) return;
    const audio = new Audio();
    audio.src = songForm.audioFile;
    const onMeta = () => {
      if (!isNaN(audio.duration) && isFinite(audio.duration)) {
        setSongForm((f) => ({ ...f, duration: String(Math.round(audio.duration)) }));
      }
    };
    audio.addEventListener('loadedmetadata', onMeta);
    return () => audio.removeEventListener('loadedmetadata', onMeta);
  }, [songForm.audioFile]);

  const handleSave = async () => {
    if (!form.titleEn || !form.titleFr || !form.releaseDate) {
      toast.error(fr ? 'Titre et date requis' : 'Title and date required');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/admin/albums', {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editing ? { ...form, id: editing.id } : form),
      });
      if (res.ok) {
        // If creating a new album and an audio file was provided, create the first song too.
        if (!editing && quick.audioFile) {
          try {
            const album = await res.json();
            await fetch('/api/admin/songs', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                titleEn: quick.titleEn || form.titleEn,
                titleFr: quick.titleFr || form.titleFr,
                albumId: album?.id,
                trackNumber: '1',
                duration: quick.duration,
                price: quick.price,
                audioFile: quick.audioFile,
                previewFile: quick.previewFile,
              }),
            });
          } catch { /* song creation is best-effort */ }
        }
        toast.success(fr ? 'Enregistré !' : 'Saved!');
        setShowForm(false);
        setEditing(null);
        setForm({ ...emptyAlbum });
        setQuick({ ...emptyQuick });
        router.refresh();
      } else { toast.error(fr ? 'Échec' : 'Failed to save'); }
    } catch { toast.error('Error'); }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm(fr ? 'Supprimer cet album ?' : 'Delete this album?')) return;
    const res = await fetch(`/api/admin/albums?id=${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success(fr ? 'Supprimé' : 'Deleted'); router.refresh(); }
  };

  const startEdit = (album: any) => {
    setEditing(album);
    setForm({
      titleEn: album?.titleEn ?? '', titleFr: album?.titleFr ?? '', type: album?.type ?? 'album',
      releaseDate: album?.releaseDate ? new Date(album.releaseDate).toISOString().split('T')[0] : '',
      coverImage: album?.coverImage ?? '', descriptionEn: album?.descriptionEn ?? '', descriptionFr: album?.descriptionFr ?? '',
    });
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ----- Songs -----
  const openNewSong = (albumId: string) => {
    setSongAlbumId(albumId);
    setSongEditing(null);
    const album = albums.find((a) => a.id === albumId);
    const nextTrack = String(((album?.songs?.length) ?? 0) + 1);
    setSongForm({ ...emptySong, trackNumber: nextTrack });
  };

  const openEditSong = (albumId: string, song: any) => {
    setSongAlbumId(albumId);
    setSongEditing(song);
    setSongForm({
      titleEn: song?.titleEn ?? '', titleFr: song?.titleFr ?? '',
      trackNumber: String(song?.trackNumber ?? 1), price: String(song?.price ?? 1),
      duration: String(song?.duration ?? 0), audioFile: song?.audioFile ?? '', previewFile: song?.previewFile ?? '',
    });
  };

  const cancelSong = () => { setSongAlbumId(null); setSongEditing(null); setSongForm({ ...emptySong }); };

  const saveSong = async () => {
    if (!songForm.titleEn || !songForm.titleFr) {
      toast.error(fr ? 'Titre requis' : 'Title required');
      return;
    }
    if (!songForm.audioFile) {
      toast.error(fr ? 'Veuillez téléverser un fichier audio' : 'Please upload an audio file');
      return;
    }
    setSongLoading(true);
    try {
      const payload: any = { ...songForm, albumId: songAlbumId };
      if (songEditing) payload.id = songEditing.id;
      const res = await fetch('/api/admin/songs', {
        method: songEditing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        toast.success(fr ? 'Chanson enregistrée !' : 'Song saved!');
        cancelSong();
        router.refresh();
      } else { toast.error(fr ? 'Échec' : 'Failed'); }
    } catch { toast.error('Error'); }
    setSongLoading(false);
  };

  const deleteSong = async (id: string) => {
    if (!confirm(fr ? 'Supprimer cette chanson ?' : 'Delete this song?')) return;
    const res = await fetch(`/api/admin/songs?id=${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success(fr ? 'Supprimé' : 'Deleted'); router.refresh(); }
    else { toast.error(fr ? 'Échec de la suppression' : 'Delete failed'); }
  };

  const fmtDur = (s: number) => `${Math.floor((s ?? 0) / 60)}:${((s ?? 0) % 60).toString().padStart(2, '0')}`;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl font-bold">{fr ? 'Gérer la Musique' : 'Manage Music'}</h2>
        <button onClick={() => { setEditing(null); setForm({ ...emptyAlbum }); setShowForm(true); }} className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 flex items-center gap-2">
          <Plus className="w-4 h-4" />{fr ? 'Ajouter Album' : 'Add Album'}
        </button>
      </div>

      {showForm && (
        <div className="glass-card rounded-xl p-6 space-y-4">
          <h3 className="font-display font-bold">{editing ? (fr ? "Modifier l'album" : 'Edit Album') : (fr ? 'Nouvel album' : 'New Album')}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder="Title (EN)" value={form.titleEn} onChange={(e) => setForm({ ...form, titleEn: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder="Titre (FR)" value={form.titleFr} onChange={(e) => setForm({ ...form, titleFr: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm">
              <option value="album">Album</option><option value="ep">EP</option><option value="single">Single</option>
            </select>
            <input type="date" value={form.releaseDate} onChange={(e) => setForm({ ...form, releaseDate: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <div className="col-span-full"><FileUpload label={fr ? "Pochette de l'album" : 'Album cover'} kind="image" value={form.coverImage} onChange={(url) => setForm({ ...form, coverImage: url })} /></div>
            {!editing && (
              <div className="col-span-full space-y-3 rounded-lg border border-dashed border-primary/40 bg-primary/5 p-4">
                <div>
                  <p className="text-sm font-semibold text-foreground flex items-center gap-2"><Music className="w-4 h-4 text-primary" />{fr ? 'Ajouter une chanson (depuis PC ou téléphone)' : 'Add a song (from PC or phone)'}</p>
                  <p className="text-xs text-muted-foreground">{fr ? "Téléversez le fichier audio ici : la chanson sera ajoutée automatiquement à l'album. Vous pourrez en ajouter d'autres ensuite." : 'Upload the audio file here: the song is added to the album automatically. You can add more afterwards.'}</p>
                </div>
                <FileUpload label={fr ? 'Fichier audio (chanson complète)' : 'Audio file (full song)'} kind="audio" value={quick.audioFile} onChange={(url) => setQuick({ ...quick, audioFile: url })} />
                {quick.audioFile && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input placeholder={fr ? 'Titre de la chanson (EN, optionnel)' : 'Song title (EN, optional)'} value={quick.titleEn} onChange={(e) => setQuick({ ...quick, titleEn: e.target.value })} className="px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                    <input placeholder={fr ? 'Titre de la chanson (FR, optionnel)' : 'Song title (FR, optional)'} value={quick.titleFr} onChange={(e) => setQuick({ ...quick, titleFr: e.target.value })} className="px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                    <input type="number" step="0.01" placeholder={fr ? 'Prix ($)' : 'Price ($)'} value={quick.price} onChange={(e) => setQuick({ ...quick, price: e.target.value })} className="px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                  </div>
                )}
              </div>
            )}
            <textarea placeholder="Description (EN)" value={form.descriptionEn} onChange={(e) => setForm({ ...form, descriptionEn: e.target.value })} rows={2} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <textarea placeholder="Description (FR)" value={form.descriptionFr} onChange={(e) => setForm({ ...form, descriptionFr: e.target.value })} rows={2} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
          </div>
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={loading} className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 disabled:opacity-50">{loading ? '...' : (fr ? 'Enregistrer' : 'Save')}</button>
            <button onClick={() => { setShowForm(false); setEditing(null); }} className="px-5 py-2 bg-secondary text-foreground text-sm rounded-lg hover:bg-secondary/80">{fr ? 'Annuler' : 'Cancel'}</button>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {(albums ?? []).map((album: any) => (
          <div key={album?.id} className="glass-card rounded-xl p-4">
            <div className="flex items-center gap-4">
              <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-secondary">
                {album?.coverImage && <Image src={album.coverImage} alt="" fill className="object-cover" />}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-foreground">{album?.titleEn}</h3>
                <p className="text-xs text-muted-foreground">{album?.type?.toUpperCase()} • {album?.songs?.length ?? 0} {fr ? 'titres' : 'tracks'} • <SafeDate date={album?.releaseDate} options={{ dateStyle: 'medium' }} /></p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setExpanded(expanded === album.id ? null : album.id)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary flex items-center gap-1 text-xs">
                  <Music className="w-4 h-4" />{fr ? 'Chansons' : 'Songs'}{expanded === album.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>
                <button onClick={() => startEdit(album)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary"><Edit className="w-4 h-4" /></button>
                <button onClick={() => handleDelete(album.id)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>

            {expanded === album.id && (
              <div className="mt-4 pt-4 border-t border-border space-y-3">
                {(album?.songs ?? []).map((song: any) => (
                  <div key={song.id} className="flex items-center gap-3 bg-secondary/50 rounded-lg px-3 py-2">
                    <span className="text-xs text-muted-foreground w-5 text-center">{song?.trackNumber}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{song?.titleEn}</p>
                      <p className="text-[11px] text-muted-foreground">{fmtDur(song?.duration)} • ${song?.price?.toFixed?.(2)} {song?.audioFile ? '' : `• ${fr ? 'audio manquant' : 'no audio'}`}</p>
                    </div>
                    <button onClick={() => openEditSong(album.id, song)} className="p-1.5 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary"><Edit className="w-3.5 h-3.5" /></button>
                    <button onClick={() => deleteSong(song.id)} className="p-1.5 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                ))}

                {songAlbumId === album.id ? (
                  <div className="bg-secondary/30 rounded-lg p-4 space-y-3 border border-border">
                    <h4 className="text-sm font-bold">{songEditing ? (fr ? 'Modifier la chanson' : 'Edit song') : (fr ? 'Nouvelle chanson' : 'New song')}</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <input placeholder="Title (EN)" value={songForm.titleEn} onChange={(e) => setSongForm({ ...songForm, titleEn: e.target.value })} className="px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                      <input placeholder="Titre (FR)" value={songForm.titleFr} onChange={(e) => setSongForm({ ...songForm, titleFr: e.target.value })} className="px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                      <input type="number" placeholder={fr ? 'N° piste' : 'Track #'} value={songForm.trackNumber} onChange={(e) => setSongForm({ ...songForm, trackNumber: e.target.value })} className="px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                      <input type="number" step="0.01" placeholder={fr ? 'Prix ($)' : 'Price ($)'} value={songForm.price} onChange={(e) => setSongForm({ ...songForm, price: e.target.value })} className="px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                      <div className="col-span-full"><FileUpload label={fr ? 'Fichier audio (chanson complète)' : 'Audio file (full song)'} kind="audio" value={songForm.audioFile} onChange={(url) => setSongForm({ ...songForm, audioFile: url })} /></div>
                      <div className="col-span-full"><FileUpload label={fr ? 'Extrait 30s (optionnel)' : '30s preview (optional)'} kind="audio" value={songForm.previewFile} onChange={(url) => setSongForm({ ...songForm, previewFile: url })} /></div>
                    </div>
                    <div className="flex gap-3">
                      <button onClick={saveSong} disabled={songLoading} className="px-4 py-1.5 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 disabled:opacity-50">{songLoading ? '...' : (fr ? 'Enregistrer' : 'Save')}</button>
                      <button onClick={cancelSong} className="px-4 py-1.5 bg-secondary text-foreground text-sm rounded-lg hover:bg-secondary/80">{fr ? 'Annuler' : 'Cancel'}</button>
                    </div>
                  </div>
                ) : (
                  <button onClick={() => openNewSong(album.id)} className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 text-primary text-sm font-semibold rounded-lg hover:bg-primary/20">
                    <Plus className="w-4 h-4" />{fr ? 'Ajouter une chanson' : 'Add a song'}
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
