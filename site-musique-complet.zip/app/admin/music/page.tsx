import { prisma } from '@/lib/db';
import { MusicAdminClient } from './music-admin-client';

export const dynamic = 'force-dynamic';

export default async function AdminMusicPage() {
  const albums = await prisma.album.findMany({ orderBy: { createdAt: 'desc' }, include: { songs: { orderBy: { trackNumber: 'asc' } } } });
  return <MusicAdminClient albums={JSON.parse(JSON.stringify(albums))} />;
}
