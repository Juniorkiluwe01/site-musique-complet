import { prisma } from '@/lib/db';
import { GalleryAdminClient } from './gallery-admin-client';
export const dynamic = 'force-dynamic';
export default async function AdminGalleryPage() {
  const items = await prisma.galleryItem.findMany({ where: { type: 'photo' }, orderBy: { createdAt: 'desc' } });
  return <GalleryAdminClient items={JSON.parse(JSON.stringify(items))} />;
}
