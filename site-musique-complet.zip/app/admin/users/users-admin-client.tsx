'use client';
import React from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Users, Shield, User } from 'lucide-react';
import { toast } from 'sonner';
import { SafeDate } from '@/components/safe-format';

export function UsersAdminClient({ users }: { users: any[] }) {
  const { locale } = useI18n();
  const router = useRouter();

  const toggleRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'admin' ? 'fan' : 'admin';
    const res = await fetch('/api/admin/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: userId, role: newRole }) });
    if (res.ok) { toast.success(`Role changed to ${newRole}`); router.refresh(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Users className="w-6 h-6 text-primary" />
        <h2 className="font-display text-xl font-bold">{locale === 'fr' ? 'Utilisateurs' : 'Users'}</h2>
        <span className="px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-full font-bold">{users?.length ?? 0}</span>
      </div>
      <div className="glass-card rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-border"><th className="text-left p-3 text-muted-foreground font-medium">Name</th><th className="text-left p-3 text-muted-foreground font-medium">Email</th><th className="text-left p-3 text-muted-foreground font-medium">Role</th><th className="text-left p-3 text-muted-foreground font-medium">Joined</th><th className="text-left p-3 text-muted-foreground font-medium">Actions</th></tr></thead>
          <tbody>
            {(users ?? []).map((u: any) => (
              <tr key={u?.id} className="border-b border-border/50">
                <td className="p-3 text-foreground flex items-center gap-2">{u?.role === 'admin' ? <Shield className="w-4 h-4 text-primary" /> : <User className="w-4 h-4 text-muted-foreground" />}{u?.name || 'N/A'}</td>
                <td className="p-3 text-foreground">{u?.email}</td>
                <td className="p-3"><span className={`px-2 py-0.5 rounded text-xs font-medium ${u?.role === 'admin' ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'}`}>{u?.role}</span></td>
                <td className="p-3 text-muted-foreground"><SafeDate date={u?.createdAt} options={{ dateStyle: 'medium' }} /></td>
                <td className="p-3"><button onClick={() => toggleRole(u.id, u.role)} className="text-xs text-primary hover:underline">{u?.role === 'admin' ? 'Make Fan' : 'Make Admin'}</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
