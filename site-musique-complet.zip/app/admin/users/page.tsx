import { prisma } from '@/lib/db';
import { UsersAdminClient } from './users-admin-client';
export const dynamic = 'force-dynamic';
export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({ orderBy: { createdAt: 'desc' } });
  return <UsersAdminClient users={JSON.parse(JSON.stringify(users))} />;
}
