'use client';
import React, { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Plus, Edit, Trash2, Disc3, Newspaper, Video as VideoIcon, ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import { FileUpload } from '@/components/admin/file-upload';

const empty = { type: 'music', titleEn: '', titleFr: '', infoEn: '', infoFr: '', image: '', videoUrl: '', linkUrl: '/music', published: true, order: '0' };

const DEFAULT_LINKS: Record<string, string> = { music: '/music', video: '/videos', photo: '/gallery', news: '/news' };

const isYouTube = (url: string) => /youtube\.com|youtu\.be/.test(url || '');
const getYouTubeId = (url: string) => (url || '').match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{11})/)?.[1];

export function LatestReleasesAdminClient({ releases }: { releases: any[] }) {
  const { locale } = useI18n();
  const router = useRouter();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>(empty);
  const [loading, setLoading] = useState(false);
  const fr = locale === 'fr';

  const TYPE_LABELS: Record<string, string> = {
    music: fr ? 'Musique' : 'Music',
    news: fr ? 'Actualité' : 'News',
    video: fr ? 'Vidéo' : 'Video',
    photo: fr ? 'Photo' : 'Photo',
  };

  const changeType = (type: string) => {
    // auto-set the link to a sensible default when it is still a default value
    const isDefaultLink = !form.linkUrl || Object.values(DEFAULT_LINKS).includes(form.linkUrl);
    setForm({ ...form, type, linkUrl: isDefaultLink ? (DEFAULT_LINKS[type] || form.linkUrl) : form.linkUrl });
  };

  const handleSave = async () => {
    if (!form.titleEn.trim() || !form.titleFr.trim()) { toast.error(fr ? 'Le titre est requis' : 'Title is required'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/admin/latest-releases', {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editing ? { ...form, id: editing.id } : form),
      });
      if (res.ok) { toast.success(fr ? 'Enregistré !' : 'Saved!'); setShowForm(false); setEditing(null); setForm(empty); router.refresh(); }
      else toast.error(fr ? 'Échec' : 'Failed');
    } catch { toast.error(fr ? 'Erreur' : 'Error'); }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm(fr ? 'Supprimer ?' : 'Delete?')) return;
    const res = await fetch(`/api/admin/latest-releases?id=${id}`, { method: 'DELETE' });
    if (res.ok) { toast.success(fr ? 'Supprimé' : 'Deleted'); router.refresh(); }
  };

  const typeIcon = (type: string) => {
    if (type === 'news') return <Newspaper className="w-7 h-7 text-muted-foreground" />;
    if (type === 'video') return <VideoIcon className="w-7 h-7 text-muted-foreground" />;
    if (type === 'photo') return <ImageIcon className="w-7 h-7 text-muted-foreground" />;
    return <Disc3 className="w-7 h-7 text-muted-foreground" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-bold">{fr ? 'Dernières Actualités' : 'Latest Updates'}</h2>
          <p className="text-xs text-muted-foreground mt-1">{fr ? "Ajoutez la dernière chanson, vidéo, photo ou actualité. La plus récente s'affiche en premier dans la section « Dernières Actualités » de la page d'accueil." : 'Add the latest song, video, photo or news. The newest one shows first in the “Latest Updates” section on the homepage.'}</p>
        </div>
        <button onClick={() => { setEditing(null); setForm(empty); setShowForm(true); }} className="px-4 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 flex items-center gap-2"><Plus className="w-4 h-4" />{fr ? 'Ajouter' : 'Add'}</button>
      </div>

      {showForm && (
        <div className="glass-card rounded-xl p-6 space-y-4">
          {/* Type selector */}
          <div>
            <label className="block text-xs font-semibold text-muted-foreground mb-2">{fr ? 'Type de contenu' : 'Content type'}</label>
            <div className="flex flex-wrap gap-2">
              {(['news', 'video', 'photo', 'music'] as const).map((tp) => (
                <button key={tp} type="button" onClick={() => changeType(tp)} className={`px-4 py-2 rounded-lg text-sm font-semibold border transition-colors ${form.type === tp ? 'bg-primary text-primary-foreground border-primary' : 'bg-secondary text-foreground border-border hover:border-primary/50'}`}>{TYPE_LABELS[tp]}</button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder={fr ? 'Titre (EN)' : 'Title (EN)'} value={form.titleEn} onChange={(e) => setForm({ ...form, titleEn: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder={fr ? 'Titre (FR)' : 'Title (FR)'} value={form.titleFr} onChange={(e) => setForm({ ...form, titleFr: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <textarea placeholder={form.type === 'news' ? (fr ? "Texte de l'actualité (EN)" : 'News text (EN)') : (fr ? 'Info (EN) ex: SINGLE • 2026' : 'Info (EN) e.g. SINGLE • 2026')} value={form.infoEn} onChange={(e) => setForm({ ...form, infoEn: e.target.value })} rows={form.type === 'news' ? 3 : 1} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <textarea placeholder={form.type === 'news' ? (fr ? "Texte de l'actualité (FR)" : 'News text (FR)') : (fr ? 'Info (FR) ex: SINGLE • 2026' : 'Info (FR) e.g. SINGLE • 2026')} value={form.infoFr} onChange={(e) => setForm({ ...form, infoFr: e.target.value })} rows={form.type === 'news' ? 3 : 1} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder={fr ? 'Lien (ex: /music)' : 'Link (e.g. /music)'} value={form.linkUrl} onChange={(e) => setForm({ ...form, linkUrl: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
            <input placeholder={fr ? 'Ordre (0 = premier)' : 'Order (0 = first)'} type="number" value={form.order} onChange={(e) => setForm({ ...form, order: e.target.value })} className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />

            {/* Video fields */}
            {form.type === 'video' && (
              <>
                <div className="col-span-full">
                  <input placeholder={fr ? 'Lien YouTube (optionnel)' : 'YouTube link (optional)'} value={form.videoUrl} onChange={(e) => setForm({ ...form, videoUrl: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" />
                </div>
                {!isYouTube(form.videoUrl) && (
                  <div className="col-span-full"><FileUpload label={fr ? 'Ou téléverser une vidéo' : 'Or upload a video'} kind="video" value={form.videoUrl} onChange={(url) => setForm({ ...form, videoUrl: url })} /></div>
                )}
                <div className="col-span-full"><FileUpload label={fr ? "Miniature / Affiche (optionnel)" : 'Thumbnail / Poster (optional)'} kind="image" value={form.image} onChange={(url) => setForm({ ...form, image: url })} /></div>
              </>
            )}

            {/* Image field for photo / music / news */}
            {form.type !== 'video' && (
              <div className="col-span-full"><FileUpload label={form.type === 'photo' ? (fr ? 'Photo' : 'Photo') : form.type === 'news' ? (fr ? "Image (optionnel)" : 'Image (optional)') : (fr ? 'Affiche / Pochette' : 'Poster / Cover')} kind="image" value={form.image} onChange={(url) => setForm({ ...form, image: url })} /></div>
            )}

            <label className="flex items-center gap-2 text-sm text-foreground col-span-full"><input type="checkbox" checked={form.published} onChange={(e) => setForm({ ...form, published: e.target.checked })} />{fr ? 'Visible sur le site' : 'Visible on site'}</label>
          </div>
          <div className="flex gap-3">
            <button onClick={handleSave} disabled={loading} className="px-5 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg disabled:opacity-50">{loading ? '...' : (fr ? 'Enregistrer' : 'Save')}</button>
            <button onClick={() => { setShowForm(false); setEditing(null); setForm(empty); }} className="px-5 py-2 bg-secondary text-foreground text-sm rounded-lg">{fr ? 'Annuler' : 'Cancel'}</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(releases ?? []).map((r: any) => {
          const ytId = r?.type === 'video' && isYouTube(r?.videoUrl) ? getYouTubeId(r?.videoUrl) : null;
          const thumb = r?.image || (ytId ? `https://i.ytimg.com/vi/jsSXegu7Ck0/maxresdefault.jpg` : null);
          return (
          <div key={r?.id} className="glass-card rounded-xl p-4 flex items-center gap-4">
            <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-secondary flex items-center justify-center">
              {thumb ? <Image src={thumb} alt="" fill className="object-cover" /> : typeIcon(r?.type)}
            </div>
            <div className="flex-1 min-w-0">
              <span className="inline-block text-[10px] uppercase tracking-wide text-primary font-semibold mb-0.5">{TYPE_LABELS[r?.type] || TYPE_LABELS.music}</span>
              <h3 className="font-bold text-foreground text-sm truncate">{fr ? r?.titleFr : r?.titleEn}</h3>
              <p className="text-xs text-muted-foreground truncate">{fr ? r?.infoFr : r?.infoEn}</p>
              {!r?.published && <span className="text-[10px] text-destructive">{fr ? 'Masqué' : 'Hidden'}</span>}
            </div>
            <div className="flex gap-1">
              <button onClick={() => { setEditing(r); setForm({ type: r.type || 'music', titleEn: r.titleEn, titleFr: r.titleFr, infoEn: r.infoEn || '', infoFr: r.infoFr || '', image: r.image || '', videoUrl: r.videoUrl || '', linkUrl: r.linkUrl || '/music', published: r.published, order: String(r.order ?? 0) }); setShowForm(true); }} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-primary"><Edit className="w-4 h-4" /></button>
              <button onClick={() => handleDelete(r.id)} className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
          );
        })}
      </div>
    </div>
  );
}
