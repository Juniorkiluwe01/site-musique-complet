import { prisma } from '@/lib/db';
import { LatestReleasesAdminClient } from './latest-releases-admin-client';

export const dynamic = 'force-dynamic';

export default async function AdminLatestReleasesPage() {
  const releases = await prisma.latestRelease.findMany({ orderBy: [{ order: 'asc' }, { createdAt: 'desc' }] });
  return <LatestReleasesAdminClient releases={JSON.parse(JSON.stringify(releases))} />;
}
