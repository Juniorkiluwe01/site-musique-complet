'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n';
import { Settings, Save } from 'lucide-react';
import { toast } from 'sonner';

export function SettingsAdminClient({ settings }: { settings: any }) {
  const { locale } = useI18n();
  const router = useRouter();
  const [form, setForm] = useState({
    artistName: settings?.artistName ?? '', sloganEn: settings?.sloganEn ?? '', sloganFr: settings?.sloganFr ?? '',
    bioEn: settings?.bioEn ?? '', bioFr: settings?.bioFr ?? '',
    email: settings?.email ?? '', emailSecondary: settings?.emailSecondary ?? '', phone: settings?.phone ?? '',
    instagramUrl: settings?.instagramUrl ?? '', tiktokUrl: settings?.tiktokUrl ?? '',
    facebookUrl: settings?.facebookUrl ?? '', youtubeUrl: settings?.youtubeUrl ?? '', audiomackUrl: settings?.audiomackUrl ?? '',
  });
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      if (res.ok) { toast.success('Saved!'); router.refresh(); } else toast.error('Failed');
    } catch { toast.error('Error'); }
    setLoading(false);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center gap-3">
        <Settings className="w-6 h-6 text-primary" />
        <h2 className="font-display text-xl font-bold">{locale === 'fr' ? 'Param\u00e8tres' : 'Settings'}</h2>
      </div>
      <div className="glass-card rounded-xl p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="col-span-full"><label className="text-xs text-muted-foreground mb-1 block">Artist Name</label><input value={form.artistName} onChange={(e) => setForm({ ...form, artistName: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">Slogan (EN)</label><input value={form.sloganEn} onChange={(e) => setForm({ ...form, sloganEn: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">Slogan (FR)</label><input value={form.sloganFr} onChange={(e) => setForm({ ...form, sloganFr: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">Email</label><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">{locale === 'fr' ? 'Email secondaire' : 'Secondary email'}</label><input value={form.emailSecondary} onChange={(e) => setForm({ ...form, emailSecondary: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">Phone</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div className="col-span-full"><label className="text-xs text-muted-foreground mb-1 block">Bio (EN)</label><textarea value={form.bioEn} onChange={(e) => setForm({ ...form, bioEn: e.target.value })} rows={5} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div className="col-span-full"><label className="text-xs text-muted-foreground mb-1 block">Bio (FR)</label><textarea value={form.bioFr} onChange={(e) => setForm({ ...form, bioFr: e.target.value })} rows={5} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">Instagram</label><input value={form.instagramUrl} onChange={(e) => setForm({ ...form, instagramUrl: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">TikTok</label><input value={form.tiktokUrl} onChange={(e) => setForm({ ...form, tiktokUrl: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">Facebook</label><input value={form.facebookUrl} onChange={(e) => setForm({ ...form, facebookUrl: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">YouTube</label><input value={form.youtubeUrl} onChange={(e) => setForm({ ...form, youtubeUrl: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
          <div><label className="text-xs text-muted-foreground mb-1 block">Audiomack</label><input value={form.audiomackUrl} onChange={(e) => setForm({ ...form, audiomackUrl: e.target.value })} className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm" /></div>
        </div>
        <button onClick={handleSave} disabled={loading} className="px-6 py-2.5 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 flex items-center gap-2 disabled:opacity-50"><Save className="w-4 h-4" />{loading ? '...' : 'Save'}</button>
      </div>
    </div>
  );
}
