import { prisma } from '@/lib/db';
import { SettingsAdminClient } from './settings-admin-client';
export const dynamic = 'force-dynamic';
export default async function AdminSettingsPage() {
  const settings = await prisma.siteSettings.findUnique({ where: { id: 'main' } });
  return <SettingsAdminClient settings={JSON.parse(JSON.stringify(settings))} />;
}
