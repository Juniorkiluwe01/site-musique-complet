'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { usePlayer, type Track } from '@/lib/player';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { IMAGES } from '@/lib/constants';
import { Play, Pause, Download, Clock, X } from 'lucide-react';
import { toast } from 'sonner';
import { SafeDate } from '@/components/safe-format';

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

const tabs = ['all', 'album', 'ep', 'single'] as const;

export function MusicClient({ albums }: { albums: any[] }) {
  const { t, locale } = useI18n();
  const { addItem, clearCart } = useCart();
  const { playTrack, current, isPlaying, togglePlay } = usePlayer();
  const [activeTab, setActiveTab] = useState<string>('all');
  const [downloads, setDownloads] = useState<{ title: string; url: string }[]>([]);

  // Handle return from the payment page.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('cancelled') === 'true') {
      toast.error(locale === 'fr' ? 'Paiement annulé' : 'Payment cancelled');
      window.history.replaceState({}, '', '/music');
      return;
    }
    const orderId = params.get('order');
    if (params.get('success') === 'true' && orderId) {
      (async () => {
        try {
          const res = await fetch('/api/checkout/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId }),
          });
          const data = await res.json();
          if (data?.paid) {
            clearCart();
            toast.success(locale === 'fr' ? 'Paiement réussi ! Vos téléchargements sont prêts.' : 'Payment successful! Your downloads are ready.');
            if (Array.isArray(data?.downloads) && data.downloads.length > 0) {
              setDownloads(data.downloads);
            }
          } else {
            toast(locale === 'fr' ? 'Paiement en cours de traitement...' : 'Payment is being processed...');
          }
        } catch {
          toast.error(locale === 'fr' ? 'Impossible de vérifier le paiement' : 'Could not verify payment');
        } finally {
          window.history.replaceState({}, '', '/music');
        }
      })();
    }
  }, []);

  // Preferred display order requested by the artist
  const preferredOrder = ['nubian girl', 'yolo', 'sad life'];
  const orderRank = (a: any) => {
    const title = (a?.titleEn ?? '').toLowerCase();
    const i = preferredOrder.findIndex((o) => title.startsWith(o));
    return i === -1 ? 999 : i;
  };
  const base = activeTab === 'all' ? (albums ?? []) : (albums ?? []).filter((a: any) => a?.type === activeTab);
  const filtered = [...base].sort((a: any, b: any) => orderRank(a) - orderRank(b));

  // Build a flat queue of all playable songs (those with an audio file) across visible albums
  const buildQueue = (): Track[] =>
    (filtered ?? [])
      .flatMap((a: any) => (a?.songs ?? []).map((s: any) => ({ song: s, album: a })))
      .filter((x: any) => x?.song?.audioFile)
      .map((x: any) => ({
        id: x.song.id,
        title: locale === 'fr' ? x.song.titleFr : x.song.titleEn,
        artist: 'MC STAGGA GH',
        audioUrl: x.song.audioFile,
        coverImage: x.album?.coverImage || IMAGES.albumStreetsOfGold,
      }));

  const handlePlay = (song: any, album: any) => {
    if (!song?.audioFile) {
      toast.error(locale === 'fr' ? 'Audio indisponible' : 'Audio unavailable');
      return;
    }
    if (current?.id === song.id) {
      togglePlay();
      return;
    }
    const track: Track = {
      id: song.id,
      title: locale === 'fr' ? song.titleFr : song.titleEn,
      artist: 'MC STAGGA GH',
      audioUrl: song.audioFile,
      coverImage: album?.coverImage || IMAGES.albumStreetsOfGold,
    };
    playTrack(track, buildQueue());
  };

  const formatDuration = (seconds: number) => {
    const m = Math.floor((seconds ?? 0) / 60);
    const s = (seconds ?? 0) % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleBuySong = async (song: any) => {
    addItem({ id: song.id, type: 'song', name: locale === 'fr' ? song?.titleFr : song?.titleEn, price: song?.price ?? 1, image: undefined });
    toast.success(locale === 'fr' ? 'Ajouté au panier' : 'Added to cart');
  };

  return (
    <>
      <Navbar />
      <section className="pt-28 pb-8 px-4">
        <div className="max-w-[1200px] mx-auto text-center">
          <motion.div {...fadeUp}>
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-3">{t('music.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('music.subtitle')}</p>
          </motion.div>
        </div>
      </section>

      {/* Tabs */}
      <section className="px-4 mb-8">
        <div className="max-w-[1200px] mx-auto flex justify-center gap-2">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2 text-sm font-medium rounded-lg transition-colors ${
                activeTab === tab ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab === 'all' ? (locale === 'fr' ? 'Tout' : 'All') : tab === 'album' ? t('music.albums') : tab === 'ep' ? t('music.eps') : t('music.singles')}
            </button>
          ))}
        </div>
      </section>

      {/* Albums Grid */}
      <section className="px-4 pb-20">
        <div className="max-w-[1200px] mx-auto space-y-12">
          {(filtered ?? []).map((album: any, idx: number) => (
            <motion.div key={album?.id} {...fadeUp} transition={{ delay: idx * 0.1 }}>
              <div className="glass-card rounded-2xl overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
                  <div className="relative aspect-square md:aspect-auto group/cover">
                    <Image src={album?.coverImage || IMAGES.albumStreetsOfGold} alt={locale === 'fr' ? album?.titleFr : album?.titleEn} fill className="object-cover" />
                    {(album?.songs ?? []).some((s: any) => s?.audioFile) && (
                      <button
                        onClick={() => handlePlay((album?.songs ?? []).find((s: any) => s?.audioFile), album)}
                        aria-label={locale === 'fr' ? 'Lire' : 'Play'}
                        className="absolute inset-0 flex items-center justify-center bg-gradient-to-t from-black/50 via-transparent to-transparent hover:bg-black/40 transition-colors"
                      >
                        {(() => {
                          const firstAudio = (album?.songs ?? []).find((s: any) => s?.audioFile);
                          const active = current?.id === firstAudio?.id && isPlaying;
                          return (
                            <span className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-xl ring-4 ring-black/20 transition-transform hover:scale-110">
                              {active ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 ml-1" />}
                            </span>
                          );
                        })()}
                      </button>
                    )}
                  </div>
                  <div className="md:col-span-2 p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <span className="text-xs text-primary font-semibold uppercase tracking-wider">{album?.type}</span>
                        <h2 className="font-display text-2xl font-bold text-foreground mt-1">{locale === 'fr' ? album?.titleFr : album?.titleEn}</h2>
                        <p className="text-sm text-muted-foreground mt-1">
                          <SafeDate date={album?.releaseDate} options={{ dateStyle: 'long' }} />
                        </p>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-6">{locale === 'fr' ? album?.descriptionFr : album?.descriptionEn}</p>
                    {/* Tracklist */}
                    <div className="space-y-1">
                      {(album?.songs ?? []).map((song: any) => (
                        <div key={song?.id} className="flex items-center gap-3 py-2.5 px-3 rounded-lg hover:bg-white/5 transition-colors group">
                          <button
                            onClick={() => handlePlay(song, album)}
                            disabled={!song?.audioFile}
                            aria-label={current?.id === song?.id && isPlaying ? (locale === 'fr' ? 'Pause' : 'Pause') : (locale === 'fr' ? 'Lire' : 'Play')}
                            className="w-8 h-8 shrink-0 rounded-full flex items-center justify-center bg-primary/15 text-primary hover:bg-primary hover:text-primary-foreground transition-colors disabled:opacity-30 disabled:hover:bg-primary/15 disabled:hover:text-primary"
                          >
                            {current?.id === song?.id && isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                          </button>
                          <span className="w-6 text-sm text-muted-foreground text-right hidden sm:block">{song?.trackNumber}</span>
                          <span className={`flex-1 text-sm ${current?.id === song?.id ? 'text-primary font-semibold' : 'text-foreground'}`}>{locale === 'fr' ? song?.titleFr : song?.titleEn}</span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatDuration(song?.duration ?? 0)}
                          </span>
                          <button
                            onClick={() => handleBuySong(song)}
                            aria-label={locale === 'fr' ? 'Télécharger' : 'Download'}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground text-xs font-semibold rounded-md hover:bg-primary/90 transition-colors shrink-0"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">{locale === 'fr' ? 'Télécharger' : 'Download'}</span>
                            <span>${(song?.price ?? 1).toFixed(2)}</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Post-payment download panel */}
      {downloads.length > 0 && (
        <>
          <div className="fixed inset-0 bg-black/70 z-[95]" onClick={() => setDownloads([])} />
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[92%] max-w-md bg-card border border-border rounded-2xl z-[96] p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-xl font-bold text-gold-gradient">
                {locale === 'fr' ? 'Vos téléchargements' : 'Your downloads'}
              </h3>
              <button onClick={() => setDownloads([])} className="p-1 hover:text-primary transition-colors" aria-label={locale === 'fr' ? 'Fermer' : 'Close'}>
                <X className="w-6 h-6" />
              </button>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              {locale === 'fr' ? 'Merci pour votre achat ! Cliquez pour télécharger.' : 'Thank you for your purchase! Click to download.'}
            </p>
            <div className="space-y-2">
              {downloads.map((d, i) => (
                <a
                  key={i}
                  href={d.url}
                  download
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between gap-3 px-4 py-3 bg-primary/10 hover:bg-primary hover:text-primary-foreground text-foreground rounded-lg transition-colors"
                >
                  <span className="text-sm font-medium truncate">{d.title}</span>
                  <Download className="w-4 h-4 shrink-0" />
                </a>
              ))}
            </div>
          </div>
        </>
      )}

      <Footer />
    </>
  );
}
