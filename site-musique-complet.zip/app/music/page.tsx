import { prisma } from '@/lib/db';
import { MusicClient } from './music-client';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Music | MC STAGGA GH' };

export default async function MusicPage() {
  const albums = await prisma.album.findMany({
    where: { published: true },
    orderBy: { releaseDate: 'desc' },
    include: { songs: { where: { published: true }, orderBy: { trackNumber: 'asc' } } },
  });
  return <MusicClient albums={JSON.parse(JSON.stringify(albums))} />;
}
