'use client';

import React from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { User, Calendar, Users, GraduationCap, Mic, Music } from 'lucide-react';

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

const BIO_IMAGE = 'https://cdn.abacus.ai/images/3a8673a2-85ac-4e50-a14d-9e4e96b89c54.png';

interface Section {
  icon: React.ElementType;
  titleEn: string;
  titleFr: string;
  contentEn: React.ReactNode;
  contentFr: React.ReactNode;
}

const sections: Section[] = [
  {
    icon: User,
    titleEn: 'Full Name',
    titleFr: 'Nom complet',
    contentEn: <p>Francis Xavier Ayinbono Atindanbila</p>,
    contentFr: <p>Francis Xavier Ayinbono Atindanbila</p>,
  },
  {
    icon: Calendar,
    titleEn: 'Date of Birth',
    titleFr: 'Date de naissance',
    contentEn: <p>2nd of December, 1990</p>,
    contentFr: <p>2 décembre 1990</p>,
  },
  {
    icon: Users,
    titleEn: 'Parents & Siblings',
    titleFr: 'Parents et fratrie',
    contentEn: (
      <>
        <p><span className="text-primary font-semibold">Father:</span> Dr. Samuel Akazusi Atindanbila</p>
        <p><span className="text-primary font-semibold">Mother:</span> Mrs. Lawrencia Mmabila Aniah</p>
        <p className="mt-3">The family is made up of 5 biological siblings with Mc Stagga being the first. Followed by Dr. Augustina Nsoma Atindanbila, who happens to be the only girl among the siblings. The remaining 3 are Dr. Gregory Apasibono Atindanbila, Mr. Cletus Ayingura Atindanbila and lastly, Master Raphel Abesiyine Atindanbila.</p>
      </>
    ),
    contentFr: (
      <>
        <p><span className="text-primary font-semibold">Père :</span> Dr. Samuel Akazusi Atindanbila</p>
        <p><span className="text-primary font-semibold">Mère :</span> Mme Lawrencia Mmabila Aniah</p>
        <p className="mt-3">La famille compte 5 frères et sœurs biologiques, Mc Stagga étant l&apos;aîné. Il est suivi de Dr. Augustina Nsoma Atindanbila, la seule fille parmi les frères et sœurs. Les 3 restants sont Dr. Gregory Apasibono Atindanbila, M. Cletus Ayingura Atindanbila et enfin, Master Raphel Abesiyine Atindanbila.</p>
      </>
    ),
  },
  {
    icon: Mic,
    titleEn: 'Career Start',
    titleFr: 'Début de carrière',
    contentEn: (
      <p>I started music by singing in the church choir briefly during my early days. Writing and rapping started in my high school days at Mfantsipim around 2007. In 2007 I recorded my first rap demo alongside ObamaMills.</p>
    ),
    contentFr: (
      <p>J&apos;ai commencé la musique en chantant brièvement dans la chorale de l&apos;église durant mes premières années. L&apos;écriture et le rap ont débuté lors de mes années au lycée à Mfantsipim vers 2007. En 2007, j&apos;ai enregistré ma première démo de rap aux côtés d&apos;ObamaMills.</p>
    ),
  },
  {
    icon: GraduationCap,
    titleEn: 'Educational Background',
    titleFr: 'Parcours scolaire',
    contentEn: (
      <p>Started primary education at Freeman Methodist School in Brekum, continued at Golden Sunbeam School, Adenta. High school was done at Mfantsipim School, Cape Coast before proceeding to Jiangsu University in China.</p>
    ),
    contentFr: (
      <p>Début de l&apos;éducation primaire à Freeman Methodist School à Brekum, puis à Golden Sunbeam School, Adenta. Le lycée s&apos;est fait à Mfantsipim School, Cape Coast, avant de poursuivre à l&apos;Université de Jiangsu en Chine.</p>
    ),
  },
  {
    icon: Music,
    titleEn: 'Songs',
    titleFr: 'Musique',
    contentEn: (
      <p>I have a diverse catalog which awaits my audience and fans.</p>
    ),
    contentFr: (
      <p>Je dispose d&apos;un catalogue diversifié qui attend mon public et mes fans.</p>
    ),
  },
];

export function BioClient({ settings }: { settings: any }) {
  const { t, locale } = useI18n();
  void settings; // kept for API compat

  return (
    <>
      <Navbar />
      {/* Hero */}
      <section className="relative pt-24 pb-16 px-4">
        <div className="absolute inset-0">
          <Image src={BIO_IMAGE} alt="MC STAGGA GH" fill className="object-cover object-top opacity-15" />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
        </div>
        <div className="relative max-w-[1200px] mx-auto pt-12">
          <motion.div {...fadeUp} className="text-center">
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-4">{t('bio.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('bio.subtitle')}</p>
          </motion.div>
        </div>
      </section>

      {/* Photo + Sections */}
      <section className="py-12 px-4">
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Portrait */}
          <motion.div {...fadeUp} className="lg:col-span-2">
            <div className="relative aspect-[3/4] rounded-xl overflow-hidden glow-gold">
              <Image src={BIO_IMAGE} alt="MC STAGGA GH — Francis Xavier Ayinbono Atindanbila" fill className="object-cover" />
            </div>
          </motion.div>

          {/* Info sections */}
          <div className="lg:col-span-3 space-y-8">
            {sections.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={i} {...fadeUp} transition={{ delay: i * 0.08 }} className="glass-card rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                      <Icon className="w-4.5 h-4.5 text-primary" />
                    </span>
                    <h3 className="font-display text-lg font-bold text-foreground">{locale === 'fr' ? s.titleFr : s.titleEn}</h3>
                  </div>
                  <div className="text-foreground/85 leading-relaxed text-[15px] pl-12">
                    {locale === 'fr' ? s.contentFr : s.contentEn}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
