import { prisma } from '@/lib/db';
import { BioClient } from './bio-client';

export const dynamic = 'force-dynamic';

export const metadata = { title: 'About | MC STAGGA GH' };

export default async function BioPage() {
  const settings = await prisma.siteSettings.findUnique({ where: { id: 'main' } });
  return <BioClient settings={JSON.parse(JSON.stringify(settings))} />;
}
