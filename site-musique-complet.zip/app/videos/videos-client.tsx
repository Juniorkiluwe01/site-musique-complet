'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { Play, Video } from 'lucide-react';
import { IMAGES } from '@/lib/constants';

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

export function VideosClient({ items }: { items: any[] }) {
  const { t, locale } = useI18n();
  const [activeTab, setActiveTab] = useState('all');
  const allVideos = items ?? [];
  const tabs = [{ key: 'all', label: locale === 'fr' ? 'Tout' : 'All' }, { key: 'clips', label: t('videos.clips') }, { key: 'live', label: t('videos.live') }, { key: 'behind', label: t('videos.behind') }];
  const filtered = activeTab === 'all' ? allVideos : allVideos.filter((v: any) => v?.category === activeTab);

  return (
    <>
      <Navbar />
      <section className="pt-28 pb-8 px-4">
        <div className="max-w-[1200px] mx-auto text-center">
          <motion.div {...fadeUp}>
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-3">{t('videos.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('videos.subtitle')}</p>
          </motion.div>
        </div>
      </section>

      {allVideos.length > 0 && (
      <section className="px-4 mb-8">
        <div className="max-w-[1200px] mx-auto flex justify-center gap-2">
          {tabs.map((tab) => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`px-5 py-2 text-sm font-medium rounded-lg transition-colors ${activeTab === tab.key ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}>
              {tab.label}
            </button>
          ))}
        </div>
      </section>
      )}

      <section className="px-4 pb-20">
        {(filtered ?? []).length === 0 ? (
          <div className="max-w-[1200px] mx-auto glass-card rounded-xl p-8 text-center">
            <Video className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">{locale === 'fr' ? 'Aucune vid\u00e9o pour le moment.' : 'No videos yet.'}</p>
          </div>
        ) : (
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(filtered ?? []).map((video: any, i: number) => (
            <motion.div key={video?.id ?? i} {...fadeUp} transition={{ delay: i * 0.1 }}>
              <div className="glass-card glass-card-hover rounded-xl overflow-hidden group">
                <div className="relative aspect-video">
                  <Image src={video?.thumbnail || video?.url || IMAGES.hero} alt={locale === 'fr' ? (video?.titleFr ?? '') : (video?.titleEn ?? '')} fill className="object-cover" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-primary/90 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 text-primary-foreground ml-0.5" />
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-display font-bold text-foreground">{locale === 'fr' ? (video?.titleFr ?? '') : (video?.titleEn ?? '')}</h3>
                  <span className="text-xs text-primary uppercase mt-1 inline-block">{video?.category}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        )}
      </section>

      <Footer />
    </>
  );
}
