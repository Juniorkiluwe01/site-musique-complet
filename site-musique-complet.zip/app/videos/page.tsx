import { prisma } from '@/lib/db';
import { VideosClient } from './videos-client';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Videos | MC STAGGA GH' };

export default async function VideosPage() {
  const items = await prisma.galleryItem.findMany({ where: { published: true, type: 'video' }, orderBy: { createdAt: 'desc' } });
  return <VideosClient items={JSON.parse(JSON.stringify(items))} />;
}
