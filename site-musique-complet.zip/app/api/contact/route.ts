export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const { name, email, subject, message } = data;
    if (!name || !email || !message) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Send notification email
    try {
      const appUrl = process.env.NEXTAUTH_URL || '';
      const appName = appUrl ? new URL(appUrl).hostname.split('.')[0] : 'MC STAGGA GH';
      const htmlBody = `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;"><h2 style="color:#d4a44c;border-bottom:2px solid #d4a44c;padding-bottom:10px;">New Contact Form Submission</h2><div style="background:#1a1a1a;padding:20px;border-radius:8px;margin:20px 0;color:#fff;"><p><strong>Name:</strong> ${name}</p><p><strong>Email:</strong> <a href="mailto:${email}" style="color:#d4a44c;">${email}</a></p><p><strong>Subject:</strong> ${subject || 'N/A'}</p><p><strong>Message:</strong></p><div style="background:#222;padding:15px;border-radius:4px;border-left:4px solid #d4a44c;">${message}</div></div></div>`;

      await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}` },
        body: JSON.stringify({
          app_id: process.env.WEB_APP_ID,
          notification_id: process.env.NOTIF_ID_CONTACT_FORM_SUBMISSION,
          subject: `New Contact: ${subject || 'Message from ' + name}`,
          body: htmlBody,
          is_html: true,
          recipient_email: 'juniorkiluwe694@gmail.com',
          reply_to: email,
          sender_email: `noreply@${new URL(appUrl).hostname}`,
          sender_alias: appName,
        }),
      });
    } catch (e) {
      console.error('Email notification error:', e);
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Contact error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
