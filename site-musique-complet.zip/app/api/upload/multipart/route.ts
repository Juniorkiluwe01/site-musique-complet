export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import {
  initiateMultipartUpload,
  getPresignedUrlForPart,
  completeMultipartUpload,
  getFileUrl,
} from '@/lib/s3';

async function checkAdmin() {
  const session = await auth();
  return !!session?.user && (session.user as any)?.role === 'admin';
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  try {
    const body = await request.json();
    const action = body?.action;

    if (action === 'initiate') {
      const { fileName, contentType, isPublic } = body;
      const { uploadId, cloud_storage_path } = await initiateMultipartUpload(
        fileName,
        contentType,
        isPublic ?? true,
      );
      return NextResponse.json({ uploadId, cloud_storage_path });
    }

    if (action === 'part') {
      const { cloud_storage_path, uploadId, partNumber } = body;
      const url = await getPresignedUrlForPart(cloud_storage_path, uploadId, partNumber);
      return NextResponse.json({ url });
    }

    if (action === 'complete') {
      const { cloud_storage_path, uploadId, parts, contentType, isPublic } = body;
      await completeMultipartUpload(cloud_storage_path, uploadId, parts);
      const fileUrl = await getFileUrl(cloud_storage_path, contentType, isPublic ?? true);
      return NextResponse.json({ fileUrl, cloud_storage_path });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message }, { status: 500 });
  }
}
