export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { generatePresignedUploadUrl, getFileUrl } from '@/lib/s3';

async function checkAdmin() {
  const session = await auth();
  return !!session?.user && (session.user as any)?.role === 'admin';
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  try {
    const { fileName, contentType, isPublic } = await request.json();
    const pub = isPublic ?? true;
    const { uploadUrl, cloud_storage_path } = await generatePresignedUploadUrl(fileName, contentType, pub);
    const fileUrl = await getFileUrl(cloud_storage_path, contentType, pub);
    return NextResponse.json({ uploadUrl, cloud_storage_path, fileUrl });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message }, { status: 500 });
  }
}
