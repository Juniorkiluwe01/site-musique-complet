export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { verifyPaystackWebhook, verifyTransaction, isTransactionPaid } from '@/lib/paystack';
import { fulfillOrder } from '@/lib/order-fulfillment';

export async function POST(request: Request) {
  try {
    const rawBody = await request.text();
    const signature = request.headers.get('x-paystack-signature');

    // Verify webhook signature
    const valid = verifyPaystackWebhook(rawBody, signature);
    if (!valid) {
      console.error('Invalid Paystack webhook signature');
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    let event: any = {};
    try {
      event = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
    }

    const eventType: string = event?.event || '';

    // Handle charge.success — the primary payment confirmation event
    if (eventType === 'charge.success') {
      const data = event?.data;
      const reference: string = data?.reference || '';

      if (reference) {
        // Find the order by its stored reference
        const order = await prisma.order.findFirst({
          where: { saspaySessionId: reference, status: 'pending' },
        });

        if (order) {
          // Double-check with Paystack verify API
          try {
            const tx = await verifyTransaction(reference);
            if (isTransactionPaid(tx)) {
              await fulfillOrder(order.id);
            }
          } catch (e) {
            console.error('Paystack webhook verify error:', e);
          }
        }
      }
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error('Paystack webhook error:', error?.message);
    return NextResponse.json({ error: 'Webhook error' }, { status: 400 });
  }
}
