export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import {
  getSaspayCheckout,
  isSaspaySessionPaid,
  getSaspayPayment,
  isSaspayPaymentPaid,
  verifySaspayWebhook,
} from '@/lib/saspay';
import { fulfillOrder } from '@/lib/order-fulfillment';

export async function POST(request: Request) {
  try {
    const rawBody = await request.text();
    const signature = request.headers.get('x-webhook-signature');
    const timestamp = request.headers.get('x-webhook-timestamp');

    const signingSecret = process.env.SASPAY_WEBHOOK_SECRET;

    // If a signing secret is configured, enforce signature verification.
    if (signingSecret) {
      const valid = verifySaspayWebhook(rawBody, signature, timestamp, signingSecret);
      if (!valid) {
        console.error('Invalid SasPay webhook signature');
        return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
      }
    }

    let event: any = {};
    try {
      event = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
    }

    const eventType: string = event?.event || '';

    // The webhook payload does not carry our orderId, so reconcile recent
    // pending orders by re-checking their SasPay checkout sessions.
    if (eventType.startsWith('transaction.')) {
      const since = new Date(Date.now() - 48 * 60 * 60 * 1000);
      const pending = await prisma.order.findMany({
        where: {
          status: 'pending',
          saspaySessionId: { not: null },
          createdAt: { gte: since },
        },
        orderBy: { createdAt: 'desc' },
        take: 50,
      });

      for (const order of pending) {
        try {
          let remotePaid = false;
          if (order.paymentMethod === 'card') {
            const payment = await getSaspayPayment(order.saspaySessionId as string);
            remotePaid = isSaspayPaymentPaid(payment);
          } else {
            const remote = await getSaspayCheckout(order.saspaySessionId as string);
            remotePaid = isSaspaySessionPaid(remote);
          }
          if (remotePaid) {
            await fulfillOrder(order.id);
          }
        } catch (e) {
          console.error('Reconcile error for order', order.id, e);
        }
      }
    }

    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error('SasPay webhook error:', error?.message);
    return NextResponse.json({ error: 'Webhook error' }, { status: 400 });
  }
}
