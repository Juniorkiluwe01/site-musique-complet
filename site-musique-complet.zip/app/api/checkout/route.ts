export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { initializeTransaction, convertUsdToGhs } from '@/lib/paystack';
import { auth } from '@/auth';
import crypto from 'crypto';

export async function POST(request: Request) {
  try {
    const session = await auth();
    const { items, email } = await request.json();

    if (!items || items.length === 0) {
      return NextResponse.json({ error: 'No items in cart' }, { status: 400 });
    }

    const customerEmail = email || (session?.user as any)?.email || undefined;
    const userId = (session?.user as any)?.id || undefined;

    // Calculate total from server-side prices (USD)
    let total = 0;
    const orderItems: any[] = [];

    for (const item of items) {
      let price = 0;

      if (item.type === 'song') {
        const song = await prisma.song.findUnique({ where: { id: item.id } });
        if (!song) continue;
        price = song.price;
        orderItems.push({ songId: song.id, quantity: item.quantity || 1, price });
      } else {
        const product = await prisma.product.findUnique({ where: { id: item.id } });
        if (!product) continue;
        price = product.price;
        orderItems.push({ productId: product.id, quantity: item.quantity || 1, price });
      }

      total += price * (item.quantity || 1);
    }

    if (orderItems.length === 0) {
      return NextResponse.json({ error: 'No valid items in cart' }, { status: 400 });
    }

    const orderType = orderItems.some((i: any) => i.songId) ? 'music' : 'shop';

    // Create pending order (total stored in USD)
    const order = await prisma.order.create({
      data: {
        userId,
        email: customerEmail || 'guest@checkout.com',
        status: 'pending',
        total,
        type: orderType,
        paymentMethod: 'mobile',
        items: { create: orderItems },
      },
    });

    const origin = request.headers.get('origin') || process.env.NEXTAUTH_URL || '';
    const returnPath = orderType === 'music' ? '/music' : '/shop';
    const callbackUrl = `${origin}${returnPath}?success=true&order=${order.id}`;

    // Convert USD total to GHS for Paystack
    const ghsAmount = await convertUsdToGhs(total);

    // Unique reference for this transaction
    const reference = `mcsg_${order.id.slice(0, 8)}_${crypto.randomBytes(4).toString('hex')}`;

    const paystackResult = await initializeTransaction({
      email: customerEmail || 'guest@checkout.com',
      amountGHS: ghsAmount,
      reference,
      callbackUrl,
      channels: ['mobile_money', 'card', 'bank', 'ussd', 'qr'],
      metadata: {
        orderId: order.id,
        type: orderType,
        totalUsd: total,
        custom_fields: [
          { display_name: 'Order ID', variable_name: 'order_id', value: order.id },
          { display_name: 'Type', variable_name: 'type', value: orderType },
        ],
      },
    });

    // Store the Paystack reference in saspaySessionId (reused DB field)
    await prisma.order.update({
      where: { id: order.id },
      data: { saspaySessionId: reference },
    });

    return NextResponse.json({ url: paystackResult.authorization_url });
  } catch (error: any) {
    console.error('Checkout error:', error);
    return NextResponse.json({ error: error?.message || 'Checkout failed' }, { status: 500 });
  }
}
