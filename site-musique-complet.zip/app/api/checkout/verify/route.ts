export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { verifyTransaction, isTransactionPaid } from '@/lib/paystack';
import { fulfillOrder } from '@/lib/order-fulfillment';

export async function POST(request: Request) {
  try {
    const { orderId } = await request.json();
    if (!orderId) {
      return NextResponse.json({ error: 'Missing orderId' }, { status: 400 });
    }

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: { include: { song: true } } },
    });
    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    let paid = order.status === 'paid' || order.status === 'completed' || order.status === 'shipped';

    // If not already marked paid, verify with Paystack using the stored reference.
    if (!paid && order.saspaySessionId) {
      try {
        const tx = await verifyTransaction(order.saspaySessionId);
        if (isTransactionPaid(tx)) {
          await fulfillOrder(order.id);
          paid = true;
        }
      } catch (e) {
        console.error('Paystack verify error:', e);
      }
    }

    // For paid music orders, return download links for purchased songs.
    let downloads: { title: string; url: string }[] = [];
    if (paid) {
      downloads = (order.items ?? [])
        .filter((i: any) => i?.song?.audioFile)
        .map((i: any) => ({ title: i.song.titleEn as string, url: i.song.audioFile as string }));
    }

    return NextResponse.json({ paid, status: paid ? 'paid' : order.status, type: order.type, downloads });
  } catch (error: any) {
    console.error('Verify error:', error);
    return NextResponse.json({ error: error?.message || 'Verify failed' }, { status: 500 });
  }
}
