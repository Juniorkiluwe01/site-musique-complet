export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  try {
    const settings = await prisma.siteSettings.findUnique({ where: { id: 'main' } });
    return NextResponse.json(settings ?? {});
  } catch {
    return NextResponse.json({});
  }
}
