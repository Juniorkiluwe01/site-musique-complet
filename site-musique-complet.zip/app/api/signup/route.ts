export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import bcrypt from 'bcryptjs';

export async function POST(request: Request) {
  try {
    const { email, password, name } = await request.json();
    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password required' }, { status: 400 });
    }
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      return NextResponse.json({ error: 'User already exists' }, { status: 409 });
    }
    // First user is admin
    const userCount = await prisma.user.count();
    const role = userCount === 0 ? 'admin' : 'fan';
    const hashed = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { email, password: hashed, name: name || email.split('@')[0], role },
    });

    // Send a congratulations / welcome email to the new fan.
    try {
      const appUrl = process.env.NEXTAUTH_URL || '';
      const appName = 'MC STAGGA GH';
      const displayName = name || email.split('@')[0];
      const htmlBody = `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0a;color:#ffffff;border-radius:12px;overflow:hidden;">
        <div style="background:linear-gradient(135deg,#1a1a1a,#000);padding:32px 24px;text-align:center;border-bottom:3px solid #d4a853;">
          <h1 style="margin:0;font-size:26px;color:#d4a853;letter-spacing:1px;">MC STAGGA GH</h1>
          <p style="margin:6px 0 0;color:#bbb;font-size:13px;">The Voice of the Streets</p>
        </div>
        <div style="padding:32px 24px;">
          <h2 style="color:#d4a853;margin-top:0;">Félicitations, ${displayName} ! 🎉</h2>
          <p style="line-height:1.6;color:#eee;">Bienvenue dans la communauté officielle de <strong>MC STAGGA GH</strong> ! Ton inscription est confirmée. Tu fais désormais partie de la famille et tu seras parmi les premiers informés des nouvelles sorties, concerts et exclusivités.</p>
          <p style="line-height:1.6;color:#eee;">Merci pour ton soutien — ça compte énormément. 🔥</p>
          <hr style="border:none;border-top:1px solid #333;margin:24px 0;" />
          <h3 style="color:#d4a853;margin:0 0 4px;font-size:16px;">Congratulations, ${displayName}! 🎉</h3>
          <p style="line-height:1.6;color:#eee;">Welcome to the official <strong>MC STAGGA GH</strong> community! Your account is confirmed. You are now part of the family and will be among the first to hear about new releases, shows and exclusives.</p>
          ${appUrl ? `<div style="text-align:center;margin-top:28px;"><a href="${appUrl}" style="display:inline-block;background:#d4a853;color:#000;font-weight:bold;text-decoration:none;padding:12px 28px;border-radius:8px;">Découvrir le site / Visit the site</a></div>` : ''}
        </div>
        <div style="background:#000;padding:16px 24px;text-align:center;color:#666;font-size:12px;">© ${new Date().getFullYear()} MC STAGGA GH</div>
      </div>`;

      if (appUrl) {
        await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}` },
          body: JSON.stringify({
            app_id: process.env.WEB_APP_ID,
            notification_id: process.env.NOTIF_ID_WELCOME_EMAIL,
            subject: 'Bienvenue dans la famille MC STAGGA GH ! 🎉',
            body: htmlBody,
            is_html: true,
            recipient_email: user.email,
            sender_email: `noreply@${new URL(appUrl).hostname}`,
            sender_alias: appName,
          }),
        });
      }
    } catch (e) {
      console.error('Welcome email error:', e);
    }

    return NextResponse.json({ id: user.id, email: user.email, role: user.role });
  } catch (error: any) {
    console.error('Signup error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
