export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { email } = await request.json();
    if (!email) return NextResponse.json({ error: 'Email required' }, { status: 400 });

    const existing = await prisma.newsletter.findUnique({ where: { email } });
    if (existing) return NextResponse.json({ error: 'Already subscribed' }, { status: 409 });

    await prisma.newsletter.create({ data: { email } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Newsletter error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
