export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

async function checkAdmin() {
  const session = await auth();
  return session?.user && (session.user as any)?.role === 'admin';
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const data = await request.json();
  const event = await prisma.event.create({ data: { titleEn: data.titleEn, titleFr: data.titleFr, venue: data.venue, city: data.city, date: new Date(data.date), time: data.time || null, descriptionEn: data.descriptionEn || null, descriptionFr: data.descriptionFr || null, bookingUrl: data.bookingUrl || null, image: data.image || null, isPast: data.isPast || false } });
  revalidatePath('/', 'layout');
  return NextResponse.json(event);
}

export async function PUT(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const data = await request.json();
  const event = await prisma.event.update({ where: { id: data.id }, data: { titleEn: data.titleEn, titleFr: data.titleFr, venue: data.venue, city: data.city, date: new Date(data.date), time: data.time || null, descriptionEn: data.descriptionEn || null, descriptionFr: data.descriptionFr || null, bookingUrl: data.bookingUrl || null, image: data.image || null, isPast: data.isPast } });
  revalidatePath('/', 'layout');
  return NextResponse.json(event);
}

export async function DELETE(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
  await prisma.event.delete({ where: { id } });
  revalidatePath('/', 'layout');
  return NextResponse.json({ success: true });
}
