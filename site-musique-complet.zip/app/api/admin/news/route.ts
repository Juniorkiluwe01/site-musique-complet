export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

async function checkAdmin() {
  const session = await auth();
  return session?.user && (session.user as any)?.role === 'admin';
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const data = await request.json();
  const article = await prisma.newsArticle.create({ data: { titleEn: data.titleEn, titleFr: data.titleFr, slug: data.slug || data.titleEn.toLowerCase().replace(/[^a-z0-9]+/g, '-'), contentEn: data.contentEn, contentFr: data.contentFr, excerptEn: data.excerptEn || null, excerptFr: data.excerptFr || null, image: data.image || null, tags: data.tags || [], status: data.status || 'published' } });
  revalidatePath('/', 'layout');
  return NextResponse.json(article);
}

export async function PUT(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const data = await request.json();
  const article = await prisma.newsArticle.update({ where: { id: data.id }, data: { titleEn: data.titleEn, titleFr: data.titleFr, slug: data.slug, contentEn: data.contentEn, contentFr: data.contentFr, excerptEn: data.excerptEn || null, excerptFr: data.excerptFr || null, image: data.image || null, tags: data.tags || [], status: data.status } });
  revalidatePath('/', 'layout');
  return NextResponse.json(article);
}

export async function DELETE(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
  await prisma.newsArticle.delete({ where: { id } });
  revalidatePath('/', 'layout');
  return NextResponse.json({ success: true });
}
