export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

async function checkAdmin() {
  const session = await auth();
  if (!session?.user || (session.user as any)?.role !== 'admin') return false;
  return true;
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const data = await request.json();
    const item = await prisma.latestRelease.create({ data: {
      type: data.type || 'music',
      titleEn: data.titleEn, titleFr: data.titleFr,
      infoEn: data.infoEn || '', infoFr: data.infoFr || '',
      image: data.image || null, videoUrl: data.videoUrl || null,
      linkUrl: data.linkUrl || '/music',
      published: data.published !== false, order: parseInt(data.order) || 0,
    } });
    revalidatePath('/', 'layout');
    return NextResponse.json(item);
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}

export async function PUT(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const data = await request.json();
    const item = await prisma.latestRelease.update({ where: { id: data.id }, data: {
      type: data.type || 'music',
      titleEn: data.titleEn, titleFr: data.titleFr,
      infoEn: data.infoEn || '', infoFr: data.infoFr || '',
      image: data.image || null, videoUrl: data.videoUrl || null,
      linkUrl: data.linkUrl || '/music',
      published: data.published !== false, order: parseInt(data.order) || 0,
    } });
    revalidatePath('/', 'layout');
    return NextResponse.json(item);
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}

export async function DELETE(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    await prisma.latestRelease.delete({ where: { id } });
    revalidatePath('/', 'layout');
    return NextResponse.json({ success: true });
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}
