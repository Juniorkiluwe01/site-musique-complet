export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

async function checkAdmin() {
  const session = await auth();
  return session?.user && (session.user as any)?.role === 'admin';
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const data = await request.json();
  const item = await prisma.galleryItem.create({ data: { titleEn: data.titleEn || null, titleFr: data.titleFr || null, type: data.type || 'photo', url: data.url, category: data.category || 'general' } });
  revalidatePath('/', 'layout');
  return NextResponse.json(item);
}

export async function DELETE(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
  await prisma.galleryItem.delete({ where: { id } });
  revalidatePath('/', 'layout');
  return NextResponse.json({ success: true });
}
