export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

async function checkAdmin() {
  const session = await auth();
  if (!session?.user || (session.user as any)?.role !== 'admin') return false;
  return true;
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const data = await request.json();
    const song = await prisma.song.create({
      data: {
        titleEn: data.titleEn,
        titleFr: data.titleFr,
        albumId: data.albumId || null,
        trackNumber: parseInt(data.trackNumber) || 1,
        duration: parseInt(data.duration) || 0,
        price: parseFloat(data.price) || 1.0,
        audioFile: data.audioFile || null,
        previewFile: data.previewFile || null,
      },
    });
    revalidatePath('/', 'layout');
    return NextResponse.json(song);
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}

export async function PUT(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const data = await request.json();
    const song = await prisma.song.update({
      where: { id: data.id },
      data: {
        titleEn: data.titleEn,
        titleFr: data.titleFr,
        albumId: data.albumId || null,
        trackNumber: parseInt(data.trackNumber) || 1,
        duration: parseInt(data.duration) || 0,
        price: parseFloat(data.price) || 1.0,
        audioFile: data.audioFile || null,
        previewFile: data.previewFile || null,
      },
    });
    revalidatePath('/', 'layout');
    return NextResponse.json(song);
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}

export async function DELETE(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    await prisma.song.delete({ where: { id } });
    revalidatePath('/', 'layout');
    return NextResponse.json({ success: true });
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}
