export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

async function checkAdmin() {
  const session = await auth();
  return session?.user && (session.user as any)?.role === 'admin';
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const data = await request.json();
  const product = await prisma.product.create({ data: { nameEn: data.nameEn, nameFr: data.nameFr, price: data.price, image: data.image || null, video: data.video || null, category: data.category || 'merch', stock: data.stock || 0, descriptionEn: data.descriptionEn || null, descriptionFr: data.descriptionFr || null } });
  revalidatePath('/', 'layout');
  return NextResponse.json(product);
}

export async function PUT(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const data = await request.json();
  const product = await prisma.product.update({ where: { id: data.id }, data: { nameEn: data.nameEn, nameFr: data.nameFr, price: data.price, image: data.image || null, video: data.video || null, category: data.category, stock: data.stock, descriptionEn: data.descriptionEn || null, descriptionFr: data.descriptionFr || null } });
  revalidatePath('/', 'layout');
  return NextResponse.json(product);
}

export async function DELETE(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
  await prisma.product.delete({ where: { id } });
  revalidatePath('/', 'layout');
  return NextResponse.json({ success: true });
}
