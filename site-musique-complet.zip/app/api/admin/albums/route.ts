export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

async function checkAdmin() {
  const session = await auth();
  if (!session?.user || (session.user as any)?.role !== 'admin') return false;
  return true;
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const data = await request.json();
    const album = await prisma.album.create({ data: { titleEn: data.titleEn, titleFr: data.titleFr, type: data.type || 'album', releaseDate: new Date(data.releaseDate), coverImage: data.coverImage || null, descriptionEn: data.descriptionEn || null, descriptionFr: data.descriptionFr || null } });
    revalidatePath('/', 'layout');
    return NextResponse.json(album);
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}

export async function PUT(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const data = await request.json();
    const album = await prisma.album.update({ where: { id: data.id }, data: { titleEn: data.titleEn, titleFr: data.titleFr, type: data.type, releaseDate: new Date(data.releaseDate), coverImage: data.coverImage || null, descriptionEn: data.descriptionEn || null, descriptionFr: data.descriptionFr || null } });
    revalidatePath('/', 'layout');
    return NextResponse.json(album);
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}

export async function DELETE(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    await prisma.album.delete({ where: { id } });
    revalidatePath('/', 'layout');
    return NextResponse.json({ success: true });
  } catch (e: any) { return NextResponse.json({ error: e?.message }, { status: 500 }); }
}
