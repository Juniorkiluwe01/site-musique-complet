export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { auth } from '@/auth';
import { revalidatePath } from 'next/cache';

export async function PUT(request: Request) {
  const session = await auth();
  if (!session?.user || (session.user as any)?.role !== 'admin') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { id, role } = await request.json();
  const user = await prisma.user.update({ where: { id }, data: { role } });
  revalidatePath('/', 'layout');
  return NextResponse.json(user);
}
