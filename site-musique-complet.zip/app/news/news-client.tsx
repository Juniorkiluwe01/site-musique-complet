'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { ArrowRight, Tag } from 'lucide-react';
import { SafeDate } from '@/components/safe-format';

const fadeUp = { initial: { opacity: 0, y: 30 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6 } };

export function NewsClient({ articles }: { articles: any[] }) {
  const { t, locale } = useI18n();

  return (
    <>
      <Navbar />
      <section className="pt-28 pb-8 px-4">
        <div className="max-w-[1200px] mx-auto text-center">
          <motion.div {...fadeUp}>
            <h1 className="font-display text-4xl sm:text-6xl font-bold text-gold-gradient mb-3">{t('news.title')}</h1>
            <p className="text-lg text-muted-foreground">{t('news.subtitle')}</p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-20">
        <div className="max-w-[1200px] mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(articles ?? []).map((article: any, i: number) => (
            <motion.div key={article?.id} {...fadeUp} transition={{ delay: i * 0.1 }}>
              <Link href={`/news/${article?.slug}`} className="group block glass-card glass-card-hover rounded-xl overflow-hidden h-full">
                <div className="relative aspect-video">
                  <Image src={article?.image || ''} alt={locale === 'fr' ? article?.titleFr : article?.titleEn} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-5">
                  <div className="flex gap-2 mb-3 flex-wrap">
                    {(article?.tags ?? []).map((tag: string) => (
                      <span key={tag} className="inline-flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-0.5 rounded">
                        <Tag className="w-3 h-3" />{tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="font-display text-lg font-bold text-foreground group-hover:text-primary transition-colors">{locale === 'fr' ? article?.titleFr : article?.titleEn}</h3>
                  <p className="text-sm text-muted-foreground mt-2 line-clamp-2">{locale === 'fr' ? article?.excerptFr : article?.excerptEn}</p>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-xs text-muted-foreground"><SafeDate date={article?.createdAt} options={{ dateStyle: 'medium' }} /></span>
                    <span className="text-sm text-primary flex items-center gap-1">{t('news.readMore')} <ArrowRight className="w-4 h-4" /></span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      <Footer />
    </>
  );
}
