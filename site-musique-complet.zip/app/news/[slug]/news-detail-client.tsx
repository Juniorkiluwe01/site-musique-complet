'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useI18n } from '@/lib/i18n';
import { Navbar } from '@/components/navbar';
import { Footer } from '@/components/footer';
import { ArrowLeft, Tag } from 'lucide-react';
import { SafeDate } from '@/components/safe-format';

export function NewsDetailClient({ article }: { article: any }) {
  const { t, locale } = useI18n();

  return (
    <>
      <Navbar />
      <article className="pt-28 pb-20 px-4">
        <div className="max-w-[800px] mx-auto">
          <Link href="/news" className="inline-flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors mb-8">
            <ArrowLeft className="w-4 h-4" />
            {t('news.backToNews')}
          </Link>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="flex gap-2 mb-4 flex-wrap">
              {(article?.tags ?? []).map((tag: string) => (
                <span key={tag} className="inline-flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-0.5 rounded">
                  <Tag className="w-3 h-3" />{tag}
                </span>
              ))}
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-4">{locale === 'fr' ? article?.titleFr : article?.titleEn}</h1>
            <p className="text-sm text-muted-foreground mb-8"><SafeDate date={article?.createdAt} options={{ dateStyle: 'long' }} /></p>

            {article?.image && (
              <div className="relative aspect-video rounded-xl overflow-hidden mb-8">
                <Image src={article.image} alt={locale === 'fr' ? article?.titleFr : article?.titleEn} fill className="object-cover" />
              </div>
            )}

            <div className="prose prose-invert max-w-none">
              {((locale === 'fr' ? article?.contentFr : article?.contentEn) ?? '').split('\n').map((p: string, i: number) => (
                <p key={i} className="text-foreground/90 leading-relaxed mb-4">{p}</p>
              ))}
            </div>
          </motion.div>
        </div>
      </article>
      <Footer />
    </>
  );
}
