import { prisma } from '@/lib/db';
import { NewsDetailClient } from './news-detail-client';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function NewsDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = await prisma.newsArticle.findUnique({ where: { slug } });
  if (!article) notFound();
  return <NewsDetailClient article={JSON.parse(JSON.stringify(article))} />;
}
