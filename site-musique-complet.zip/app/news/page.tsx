import { prisma } from '@/lib/db';
import { NewsClient } from './news-client';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'News | MC STAGGA GH' };

export default async function NewsPage() {
  const articles = await prisma.newsArticle.findMany({ where: { status: 'published' }, orderBy: { createdAt: 'desc' } });
  return <NewsClient articles={JSON.parse(JSON.stringify(articles))} />;
}
