import crypto from 'crypto';

const SASPAY_BASE_URL = 'https://api.saspay.me/api/v1';

function getSecretKey(): string {
  const key = process.env.SASPAY_SECRET_KEY;
  if (!key) {
    throw new Error('SASPAY_SECRET_KEY is not configured');
  }
  return key;
}

export function getSaspayCurrency(): string {
  return (process.env.SASPAY_CURRENCY || 'CDF').toUpperCase();
}

export function getSaspayCountry(): string {
  return (process.env.SASPAY_COUNTRY || 'CD').toUpperCase();
}

// Currencies with no minor unit (amount is a whole number).
const ZERO_DECIMAL = ['XOF', 'XAF', 'CDF', 'GNF', 'RWF', 'UGX', 'TZS', 'MWK', 'KMF', 'DJF', 'BIF', 'JPY'];

/** Format an amount for a currency as the decimal string SasPay expects (e.g. "2500.00"). */
export function formatAmountForCurrency(amount: number, currency: string): string {
  if (ZERO_DECIMAL.includes(currency.toUpperCase())) {
    return `${Math.round(amount)}.00`;
  }
  return amount.toFixed(2);
}

const rateCache = new Map<string, { rate: number; ts: number }>();
const RATE_TTL_MS = 30 * 60 * 1000;

async function fetchRate(from: string, to: string): Promise<number | null> {
  try {
    const res = await fetch(
      `${SASPAY_BASE_URL}/exchange-rates/?from_currency=${from}&to_currency=${to}`,
      { headers: { Authorization: `Bearer ${getSecretKey()}` }, cache: 'no-store' },
    );
    if (!res.ok) return null;
    const json = await res.json().catch(() => null);
    const results = json?.data?.results ?? json?.results ?? [];
    const raw = results?.[0]?.rate;
    const rate = raw != null ? parseFloat(raw) : NaN;
    return Number.isFinite(rate) && rate > 0 ? rate : null;
  } catch {
    return null;
  }
}

/** Convert an amount expressed in USD into the target currency using SasPay live rates. */
export async function convertFromUsd(amountUsd: number, targetCurrency: string): Promise<number> {
  const cur = targetCurrency.toUpperCase();
  if (cur === 'USD') return amountUsd;

  const cacheKey = `USD_${cur}`;
  const cached = rateCache.get(cacheKey);
  let rate: number | null =
    cached && Date.now() - cached.ts < RATE_TTL_MS ? cached.rate : null;

  if (rate == null) {
    const direct = await fetchRate('USD', cur); // USD -> LOCAL
    if (direct != null) {
      rate = direct;
    } else {
      const inverse = await fetchRate(cur, 'USD'); // LOCAL -> USD
      if (inverse != null) rate = 1 / inverse;
    }
    if (rate != null) rateCache.set(cacheKey, { rate, ts: Date.now() });
    else if (cached) rate = cached.rate; // fall back to stale cache if refresh failed
  }

  if (rate == null) {
    throw new Error(`No exchange rate available for USD->${cur}`);
  }
  return amountUsd * rate;
}

export interface CreateCheckoutParams {
  amount: string; // decimal string e.g. "5.00"
  currency: string; // 3-char code
  customerEmail: string;
  customerName: string;
  country?: string; // ISO2, preselects country/networks on the hosted page
  description?: string;
  returnUrl?: string;
  metadata?: Record<string, any>;
}

export interface SaspayCheckoutSession {
  id: string;
  checkout_url: string;
  slug?: string;
  status?: string;
  paid_at?: string | null;
  transaction?: any;
  metadata?: Record<string, any> | null;
}

/** Create a hosted checkout session. Returns the session incl. checkout_url. */
export async function createSaspayCheckout(params: CreateCheckoutParams): Promise<SaspayCheckoutSession> {
  const res = await fetch(`${SASPAY_BASE_URL}/checkout-sessions/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getSecretKey()}`,
    },
    body: JSON.stringify({
      amount: params.amount,
      currency: params.currency,
      country: params.country,
      customer_email: params.customerEmail,
      customer_name: params.customerName,
      description: params.description,
      return_url: params.returnUrl,
      metadata: params.metadata,
    }),
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`SasPay checkout failed (${res.status}): ${JSON.stringify(json)}`);
  }
  return (json?.data ?? json) as SaspayCheckoutSession;
}

export interface CreateCardPaymentParams {
  amount: string; // decimal string, USD
  currency: string; // 'USD'
  country: string; // 'XX'
  customerEmail: string;
  customerFirstName: string;
  customerLastName: string;
  customerPhone: string;
  returnUrl: string;
  description?: string;
  metadata?: Record<string, any>;
}

export interface SaspayPayment {
  id: string;
  checkout_url?: string;
  status?: string;
}

/**
 * Create a direct card payment via the softpay endpoint.
 * For network 'card', SasPay returns a hosted card-entry URL (Stripe) that the
 * customer is redirected to — skipping the intermediate method-selection page.
 */
export async function createSaspayCardPayment(params: CreateCardPaymentParams): Promise<SaspayPayment> {
  const res = await fetch(`${SASPAY_BASE_URL}/payments/softpay/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getSecretKey()}`,
      'Idempotency-Key': `card-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    },
    body: JSON.stringify({
      amount: params.amount,
      currency: params.currency,
      country: params.country,
      network: 'card',
      description: params.description,
      return_url: params.returnUrl,
      metadata: params.metadata,
      customer: {
        email: params.customerEmail,
        first_name: params.customerFirstName,
        last_name: params.customerLastName,
        phone: params.customerPhone,
      },
    }),
  });

  const json = await res.json().catch(() => ({}));
  if (!res.ok || json?.success === false) {
    throw new Error(`SasPay card payment failed (${res.status}): ${JSON.stringify(json?.error ?? json)}`);
  }
  return (json?.data ?? json) as SaspayPayment;
}

/** Fetch a softpay payment by id to check its status. */
export async function getSaspayPayment(id: string): Promise<SaspayPayment> {
  const res = await fetch(`${SASPAY_BASE_URL}/payments/${id}/verify/`, {
    method: 'GET',
    headers: { Authorization: `Bearer ${getSecretKey()}` },
    cache: 'no-store',
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`SasPay get payment failed (${res.status}): ${JSON.stringify(json)}`);
  }
  return (json?.data ?? json) as SaspayPayment;
}

/** A softpay payment counts as paid when its status is success-like. */
export function isSaspayPaymentPaid(payment: SaspayPayment): boolean {
  const status = (payment?.status || '').toUpperCase();
  return ['PAID', 'SUCCESS', 'SUCCEEDED', 'COMPLETED'].includes(status);
}

/** Fetch a checkout session by id to check its payment status. */
export async function getSaspayCheckout(id: string): Promise<SaspayCheckoutSession> {
  const res = await fetch(`${SASPAY_BASE_URL}/checkout-sessions/${id}/`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${getSecretKey()}`,
    },
    cache: 'no-store',
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(`SasPay get session failed (${res.status}): ${JSON.stringify(json)}`);
  }
  return (json?.data ?? json) as SaspayCheckoutSession;
}

/** A checkout session counts as paid when it has a paid_at timestamp or a success-like status. */
export function isSaspaySessionPaid(session: SaspayCheckoutSession): boolean {
  if (session?.paid_at) return true;
  const status = (session?.status || '').toUpperCase();
  return ['PAID', 'SUCCESS', 'SUCCEEDED', 'COMPLETED'].includes(status);
}

/**
 * Verify a SasPay webhook signature.
 * signature = HMAC-SHA256(signingSecret, `${timestamp}.${rawBody}`) hex
 */
export function verifySaspayWebhook(
  rawBody: string,
  signature: string | null,
  timestamp: string | null,
  signingSecret: string | undefined,
): boolean {
  if (!signature || !timestamp || !signingSecret) return false;

  // Reject stale timestamps (>5 min) to prevent replay attacks.
  const ts = parseInt(timestamp, 10);
  if (!Number.isFinite(ts)) return false;
  const nowSec = Math.floor(Date.now() / 1000);
  if (Math.abs(nowSec - ts) > 300) return false;

  const expected = crypto
    .createHmac('sha256', signingSecret)
    .update(`${timestamp}.${rawBody}`)
    .digest('hex');

  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}
