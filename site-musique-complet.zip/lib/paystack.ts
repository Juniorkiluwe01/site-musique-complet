import crypto from 'crypto';

const PAYSTACK_BASE_URL = 'https://api.paystack.co';

function getSecretKey(): string {
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!key) throw new Error('PAYSTACK_SECRET_KEY is not configured');
  return key;
}

// ────── Initialize Transaction ──────
export interface InitializeParams {
  email: string;
  /** Amount in GHS (kobo = pesewas). Paystack expects amount in the smallest unit. */
  amountGHS: number;
  reference: string;
  callbackUrl: string;
  metadata?: Record<string, any>;
  channels?: string[];
}

export interface InitializeResponse {
  authorization_url: string;
  access_code: string;
  reference: string;
}

export async function initializeTransaction(params: InitializeParams): Promise<InitializeResponse> {
  const amountPesewas = Math.round(params.amountGHS * 100);
  const body: any = {
    email: params.email,
    amount: amountPesewas,
    currency: 'GHS',
    reference: params.reference,
    callback_url: params.callbackUrl,
    channels: params.channels || ['mobile_money', 'card', 'bank', 'ussd', 'qr'],
    metadata: params.metadata || {},
  };

  const res = await fetch(`${PAYSTACK_BASE_URL}/transaction/initialize`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getSecretKey()}`,
    },
    body: JSON.stringify(body),
  });

  const json = await res.json();
  if (!json.status) {
    throw new Error(json.message || 'Paystack initialization failed');
  }
  return json.data as InitializeResponse;
}

// ────── Verify Transaction ──────
export interface VerifyResponse {
  id: number;
  status: string; // 'success' | 'failed' | 'abandoned' | 'reversed'
  reference: string;
  amount: number;
  currency: string;
  channel: string;
  gateway_response: string;
  paid_at: string | null;
  metadata: any;
  customer: { email: string };
}

export async function verifyTransaction(reference: string): Promise<VerifyResponse> {
  const res = await fetch(`${PAYSTACK_BASE_URL}/transaction/verify/${encodeURIComponent(reference)}`, {
    method: 'GET',
    headers: { Authorization: `Bearer ${getSecretKey()}` },
  });
  const json = await res.json();
  if (!json.status) {
    throw new Error(json.message || 'Paystack verification failed');
  }
  return json.data as VerifyResponse;
}

export function isTransactionPaid(tx: VerifyResponse): boolean {
  return tx.status === 'success';
}

// ────── Webhook Signature Verification ──────
export function verifyPaystackWebhook(rawBody: string, signature: string | null): boolean {
  if (!signature) return false;
  const hash = crypto
    .createHmac('sha512', getSecretKey())
    .update(rawBody)
    .digest('hex');
  return hash === signature;
}

// ────── USD → GHS conversion ──────
// Paystack Ghana only accepts GHS. We store prices in USD.
// Use a reasonable fixed rate as fallback; for production accuracy
// Paystack handles the display but we need to send pesewas.
const USD_TO_GHS_FALLBACK = 16.0;

export async function convertUsdToGhs(usdAmount: number): Promise<number> {
  // Try to get a live rate from a free API
  try {
    const res = await fetch(
      'https://open.er-api.com/v6/latest/USD',
      { next: { revalidate: 3600 } } as any,
    );
    if (res.ok) {
      const data = await res.json();
      const rate = data?.rates?.GHS;
      if (rate && typeof rate === 'number' && rate > 0) {
        return Math.round(usdAmount * rate * 100) / 100;
      }
    }
  } catch {
    // Fallback below
  }
  return Math.round(usdAmount * USD_TO_GHS_FALLBACK * 100) / 100;
}
