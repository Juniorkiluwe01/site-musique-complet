'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { SOCIAL_LINKS, CONTACT_INFO } from '@/lib/constants';

export interface SiteSettings {
  artistName: string;
  sloganEn: string;
  sloganFr: string;
  bioEn: string;
  bioFr: string;
  email: string;
  emailSecondary: string;
  phone: string;
  whatsapp: string;
  instagramUrl: string;
  tiktokUrl: string;
  facebookUrl: string;
  youtubeUrl: string;
  audiomackUrl: string;
}

// Defaults fall back to the hardcoded constants so the UI never renders empty.
const defaults: SiteSettings = {
  artistName: 'MC STAGGA GH',
  sloganEn: 'The Voice of the Streets',
  sloganFr: 'La Voix des Rues',
  bioEn: '',
  bioFr: '',
  email: CONTACT_INFO.emailPrimary,
  emailSecondary: CONTACT_INFO.emailSecondary,
  phone: CONTACT_INFO.phone,
  whatsapp: CONTACT_INFO.whatsapp,
  instagramUrl: SOCIAL_LINKS.instagram,
  tiktokUrl: SOCIAL_LINKS.tiktok,
  facebookUrl: SOCIAL_LINKS.facebook,
  youtubeUrl: SOCIAL_LINKS.youtube,
  audiomackUrl: SOCIAL_LINKS.audiomack,
};

const SettingsContext = createContext<SiteSettings>(defaults);

export function useSiteSettings() {
  return useContext(SettingsContext);
}

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(defaults);

  useEffect(() => {
    let active = true;
    fetch('/api/site-settings', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => {
        if (!active || !d) return;
        // Only override defaults with non-empty DB values.
        const merged: SiteSettings = { ...defaults };
        (Object.keys(defaults) as (keyof SiteSettings)[]).forEach((k) => {
          if (k === 'whatsapp') return;
          if (typeof d[k] === 'string' && d[k].trim() !== '') merged[k] = d[k];
        });
        // Derive whatsapp from phone digits.
        const digits = (merged.phone || '').replace(/\D/g, '');
        merged.whatsapp = digits || defaults.whatsapp;
        setSettings(merged);
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  return <SettingsContext.Provider value={settings}>{children}</SettingsContext.Provider>;
}
