'use client';

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import en from '@/locales/en.json';
import fr from '@/locales/fr.json';

type Locale = 'en' | 'fr';
type Translations = typeof en;

interface I18nContextType {
  locale: Locale;
  t: (key: string) => string;
  setLocale: (locale: Locale) => void;
}

const translations: Record<Locale, Translations> = { en, fr };

const I18nContext = createContext<I18nContextType>({
  locale: 'en',
  t: (key: string) => key,
  setLocale: () => {},
});

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('en');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('mc-stagga-locale') as Locale | null;
    if (saved === 'fr' || saved === 'en') setLocaleState(saved);
    setMounted(true);
  }, []);

  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l);
    if (typeof window !== 'undefined') localStorage.setItem('mc-stagga-locale', l);
  }, []);

  const t = useCallback((key: string): string => {
    const keys = key.split('.');
    let val: any = translations[locale];
    for (const k of keys) {
      val = val?.[k];
      if (val === undefined) return key;
    }
    return typeof val === 'string' ? val : key;
  }, [locale]);

  if (!mounted) {
    return <I18nContext.Provider value={{ locale: 'en', t: (key: string) => {
      const keys = key.split('.');
      let val: any = translations['en'];
      for (const k of keys) { val = val?.[k]; if (val === undefined) return key; }
      return typeof val === 'string' ? val : key;
    }, setLocale }}>{children}</I18nContext.Provider>;
  }

  return <I18nContext.Provider value={{ locale, t, setLocale }}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  return useContext(I18nContext);
}
