export const IMAGES = {
  hero: 'https://cdn.abacus.ai/images/328b563a-f3be-4054-97e8-7afa6291a55c.png',
  heroOld: 'https://cdn.abacus.ai/images/cd863f6d-3f6a-4b10-94bd-9e2b37b4686a.png',
  portrait: 'https://cdn.abacus.ai/images/569248d2-fdc9-48ec-816f-6183d899dec1.png',
  live: 'https://cdn.abacus.ai/images/b3748f44-3b89-45fb-9563-509f0ebe5d60.png',
  albumStreetsOfGold: 'https://cdn.abacus.ai/images/534fb6da-8aa9-44fa-ace3-60b53902db22.png',
  albumMidnightChronicles: 'https://cdn.abacus.ai/images/06330ea9-7513-41e2-9494-1dee772fb49f.png',
  albumRiseAbove: 'https://cdn.abacus.ai/images/3c4fb2ee-4949-4437-b971-57d356e0cc22.png',
  merchTshirt: 'https://cdn.abacus.ai/images/ae07d408-3ea4-4347-af86-73976f785ec2.png',
  merchCap: 'https://cdn.abacus.ai/images/e245a742-fb35-4784-bfef-38b21ebeefaf.png',
  galleryStudio: 'https://cdn.abacus.ai/images/c97c511b-ef32-44f7-9e52-c321603cf512.png',
  galleryBackstage: 'https://cdn.abacus.ai/images/a66d6327-3146-4fac-8be6-b2dd02d18947.png',
  eventTheater: 'https://images.stockcake.com/public/3/c/6/3c609a34-67dd-4a29-bf68-adf4fbd3f8ae/elegant-theater-performance-stockcake.jpg',
  eventNightclub: 'https://www.amny.com/wp-content/uploads/2025/11/purplerhino.jpg',
  eventFestival: 'https://edmhousenetwork.com/wp-content/uploads/2026/07/Tomorrowland-Belgium-2025-75-scaled.jpg',
  eventUnderground: 'https://www.southdenverguide.com/wp-content/uploads/2026/04/wunderground-denver-hero.jpg',
  merchPoster: 'https://cdn.abacus.ai/images/22eb013d-a601-4797-a254-cf55093d98ef.png',
} as const;

export const SOCIAL_LINKS = {
  instagram: 'https://www.instagram.com/mcstagga_gh?igsi=MW5sN3JmbGdqZTE3Zw==',
  tiktok: 'https://www.tiktok.com/@mcstagga_gh',
  facebook: 'https://www.facebook.com/profile.php?id=61589471814308',
  youtube: 'https://www.youtube.com/@Mcstagga_gh',
  audiomack: 'https://audiomack.com/@mc-stagga-gh',
} as const;

export const CONTACT_INFO = {
  phone: '+233 24 381 8293',
  whatsapp: '233243818293',
  emailPrimary: 'Contact@mcstagga.com',
  emailSecondary: 'xavierayinbono@gmail.com',
} as const;
