import { prisma } from '@/lib/db';

/**
 * Marks an order as paid (idempotent) and sends the confirmation email once.
 * Returns the fulfilled order (with items) or null if not found.
 */
export async function fulfillOrder(orderId: string) {
  const existing = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: { include: { song: true, product: true } } },
  });
  if (!existing) return null;

  // Already fulfilled -> return as-is, do not re-send email.
  if (existing.status === 'paid' || existing.status === 'completed' || existing.status === 'shipped') {
    return existing;
  }

  const order = await prisma.order.update({
    where: { id: orderId },
    data: { status: 'paid' },
    include: { items: { include: { song: true, product: true } } },
  });

  // Send order confirmation email (best-effort).
  try {
    if (order?.email) {
      const appUrl = process.env.NEXTAUTH_URL || '';
      const itemsList = (order?.items ?? [])
        .map(
          (i: any) =>
            `<li>${i?.song?.titleEn || i?.product?.nameEn || 'Item'} x${i.quantity} - $${i.price.toFixed(2)}</li>`,
        )
        .join('');
      const htmlBody = `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;"><h2 style="color:#d4a44c;">Order Confirmed!</h2><p>Thank you for your purchase. Your order #${orderId} has been confirmed.</p><ul>${itemsList}</ul><p><strong>Total: $${order.total.toFixed(2)}</strong></p></div>`;

      await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${process.env.ABACUSAI_API_KEY}`,
        },
        body: JSON.stringify({
          app_id: process.env.WEB_APP_ID,
          notification_id: process.env.NOTIF_ID_ORDER_CONFIRMATION,
          subject: `Order Confirmed - #${orderId.slice(0, 8)}`,
          body: htmlBody,
          is_html: true,
          recipient_email: order.email,
          sender_email: appUrl ? `noreply@${new URL(appUrl).hostname}` : undefined,
          sender_alias: 'MC STAGGA GH Shop',
        }),
      });
    }
  } catch (e) {
    console.error('Order email error:', e);
  }

  return order;
}
