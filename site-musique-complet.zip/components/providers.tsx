'use client';

import { SessionProvider } from 'next-auth/react';
import { I18nProvider } from '@/lib/i18n';
import { SettingsProvider } from '@/lib/settings';
import { CartProvider } from '@/lib/cart';
import { PlayerProvider } from '@/lib/player';
import { MusicPlayer } from '@/components/music-player';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <I18nProvider>
        <SettingsProvider>
        <CartProvider>
          <PlayerProvider>
            {children}
            <MusicPlayer />
          </PlayerProvider>
        </CartProvider>
        </SettingsProvider>
      </I18nProvider>
    </SessionProvider>
  );
}
