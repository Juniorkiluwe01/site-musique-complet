'use client';

import React from 'react';
import Image from 'next/image';
import { AnimatePresence, motion } from 'framer-motion';
import { usePlayer } from '@/lib/player';
import { useI18n } from '@/lib/i18n';
import { Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, X } from 'lucide-react';

function formatTime(sec: number) {
  if (!sec || !isFinite(sec)) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

// Rainbow gradient stops (yellow -> red -> gray -> teal -> green), matching the reference effect
const EQ_STOPS: Array<[number, [number, number, number]]> = [
  [0.0, [245, 208, 32]],
  [0.22, [245, 56, 3]],
  [0.5, [150, 150, 150]],
  [0.75, [43, 176, 196]],
  [1.0, [38, 208, 124]],
];

function eqColor(t: number) {
  for (let i = 0; i < EQ_STOPS.length - 1; i++) {
    const [t0, c0] = EQ_STOPS[i];
    const [t1, c1] = EQ_STOPS[i + 1];
    if (t >= t0 && t <= t1) {
      const f = (t - t0) / (t1 - t0 || 1);
      const r = Math.round(c0[0] + (c1[0] - c0[0]) * f);
      const g = Math.round(c0[1] + (c1[1] - c0[1]) * f);
      const b = Math.round(c0[2] + (c1[2] - c0[2]) * f);
      return `rgb(${r}, ${g}, ${b})`;
    }
  }
  return 'rgb(245, 208, 32)';
}

const EQ_BARS = 48;
// Deterministic pseudo-random per bar (stable across SSR/CSR)
const EQ_META = Array.from({ length: EQ_BARS }, (_, i) => {
  const seed = (i * 9301 + 49297) % 233280;
  const rnd = seed / 233280;
  return {
    color: eqColor(i / (EQ_BARS - 1)),
    duration: 0.6 + rnd * 0.7, // 0.6s - 1.3s
    delay: -(rnd * 1.2), // negative delay = start mid-cycle
  };
});

function Equalizer({ playing }: { playing: boolean }) {
  return (
    <div
      aria-hidden
      className={`flex items-end justify-between gap-[2px] h-7 w-full overflow-hidden ${playing ? '' : 'eq-paused'}`}
    >
      {EQ_META.map((b, i) => (
        <span
          key={i}
          className="eq-bar flex-1 rounded-full"
          style={{
            height: '100%',
            backgroundColor: b.color,
            animationDuration: `${b.duration}s`,
            animationDelay: `${b.delay}s`,
          }}
        />
      ))}
    </div>
  );
}

export function MusicPlayer() {
  const { current, isPlaying, currentTime, duration, volume, muted, togglePlay, next, prev, seek, setVolume, toggleMute, close, queue, currentIndex } = usePlayer();
  const { locale } = useI18n();

  const hasNext = currentIndex < queue.length - 1;
  const hasPrev = currentIndex > 0;
  const progress = duration ? (currentTime / duration) * 100 : 0;

  return (
    <AnimatePresence>
      {current && (
        <motion.div
          initial={{ y: 120, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 120, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="fixed bottom-0 left-0 right-0 z-[60]"
        >
          <div className="mx-auto max-w-[1400px] m-2 sm:m-3">
            <div className="relative rounded-2xl border border-white/10 shadow-2xl px-3 sm:px-5 pt-3 pb-3 bg-[#141414]">
              {/* Close button - top right corner */}
              <button
                onClick={close}
                aria-label={locale === 'fr' ? 'Fermer' : 'Close'}
                className="absolute top-2 right-2 z-10 p-1.5 rounded-full bg-black/40 text-muted-foreground hover:text-foreground hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Animated equalizer effect */}
              <div className="mb-2 pr-8">
                <Equalizer playing={isPlaying} />
              </div>

              {/* Seek bar */}
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[11px] tabular-nums text-muted-foreground w-9 text-right">{formatTime(currentTime)}</span>
                <input
                  type="range"
                  min={0}
                  max={duration || 0}
                  step={0.1}
                  value={currentTime}
                  onChange={(e) => seek(parseFloat(e.target.value))}
                  aria-label={locale === 'fr' ? 'Position de lecture' : 'Seek'}
                  className="player-range flex-1"
                  style={{ ['--progress' as any]: `${progress}%` }}
                />
                <span className="text-[11px] tabular-nums text-muted-foreground w-9">{formatTime(duration)}</span>
              </div>

              <div className="flex items-center gap-3 sm:gap-4">
                {/* Track info */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden bg-secondary shrink-0">
                    {current.coverImage ? (
                      <Image src={current.coverImage} alt={current.title} fill className="object-cover" />
                    ) : null}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{current.title}</p>
                    <p className="text-xs text-muted-foreground truncate">{current.artist || 'MC STAGGA GH'}</p>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex items-center justify-center gap-1.5 sm:gap-2 shrink-0">
                  <button
                    onClick={prev}
                    disabled={!hasPrev && currentTime <= 3}
                    aria-label={locale === 'fr' ? 'Précédent' : 'Previous'}
                    className="p-2 rounded-full text-foreground hover:bg-white/10 transition-colors disabled:opacity-30"
                  >
                    <SkipBack className="w-5 h-5" />
                  </button>
                  <button
                    onClick={togglePlay}
                    aria-label={isPlaying ? (locale === 'fr' ? 'Pause' : 'Pause') : (locale === 'fr' ? 'Lecture' : 'Play')}
                    className="p-3 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors shadow-lg"
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                  </button>
                  <button
                    onClick={next}
                    disabled={!hasNext}
                    aria-label={locale === 'fr' ? 'Suivant' : 'Next'}
                    className="p-2 rounded-full text-foreground hover:bg-white/10 transition-colors disabled:opacity-30"
                  >
                    <SkipForward className="w-5 h-5" />
                  </button>
                </div>

                {/* Volume */}
                <div className="hidden sm:flex items-center justify-end gap-1.5 flex-1 mr-1">
                  <button onClick={toggleMute} aria-label={locale === 'fr' ? 'Muet' : 'Mute'} className="text-muted-foreground hover:text-foreground transition-colors shrink-0">
                    {muted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.01}
                    value={muted ? 0 : volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    aria-label={locale === 'fr' ? 'Volume' : 'Volume'}
                    className="player-range w-16 lg:w-20"
                    style={{ ['--progress' as any]: `${(muted ? 0 : volume) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
