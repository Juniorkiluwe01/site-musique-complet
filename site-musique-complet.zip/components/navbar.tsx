'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession, signOut } from 'next-auth/react';
import { useI18n } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { Menu, X, ShoppingCart, Globe, Music, LogOut, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const navLinks = [
  { href: '/', key: 'nav.home' },
  { href: '/bio', key: 'nav.bio' },
  { href: '/music', key: 'nav.music' },
  { href: '/gallery', key: 'nav.gallery' },
  { href: '/videos', key: 'nav.videos' },
  { href: '/events', key: 'nav.events' },
  { href: '/news', key: 'nav.news' },
  { href: '/shop', key: 'nav.shop' },
  { href: '/contact', key: 'nav.contact' },
];

export function Navbar() {
  const { t, locale, setLocale } = useI18n();
  const { data: session } = useSession();
  const { itemCount } = useCart();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-black/80 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
      }`}
    >
      <nav className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <Music className="w-6 h-6 text-primary" />
          <span className="font-display text-xl font-bold text-gold-gradient tracking-tight">MC STAGGA GH</span>
        </Link>

        {/* Desktop nav (scrollable tabs) */}
        <div className="hidden md:flex items-center gap-1 flex-1 mx-4 overflow-x-auto nav-scroll py-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`shrink-0 whitespace-nowrap px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                pathname === link.href
                  ? 'text-primary bg-primary/10'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
              }`}
            >
              {t(link.key)}
            </Link>
          ))}
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          {/* Language toggle */}
          <button
            onClick={() => setLocale(locale === 'en' ? 'fr' : 'en')}
            className="flex items-center gap-1 px-2 py-1.5 text-xs font-medium rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-muted-foreground hover:text-foreground"
            aria-label="Switch language"
          >
            <Globe className="w-3.5 h-3.5" />
            {locale === 'en' ? 'FR' : 'EN'}
          </button>

          {/* Cart */}
          <Link href="/shop" className="relative p-2 rounded-lg hover:bg-white/5 transition-colors text-muted-foreground hover:text-foreground">
            <ShoppingCart className="w-5 h-5" />
            {itemCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary text-primary-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                {itemCount}
              </span>
            )}
          </Link>

          {/* Auth */}
          {session?.user ? (
            <div className="hidden md:flex items-center gap-1">
              <button
                onClick={() => signOut({ redirectTo: '/' })}
                className="p-2 rounded-lg hover:bg-white/5 transition-colors text-muted-foreground hover:text-foreground"
                aria-label={t('nav.logout')}
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <Link
              href="/auth?mode=signup"
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              <User className="w-4 h-4" />
              {t('nav.signup')}
            </Link>
          )}

          {/* Mobile menu */}
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden p-2 rounded-lg hover:bg-white/5 transition-colors text-muted-foreground"
            aria-label="Menu"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-black/95 backdrop-blur-xl border-b border-white/5 overflow-hidden"
          >
            <div className="max-w-[1200px] mx-auto px-4 py-4 flex flex-col gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className={`px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                    pathname === link.href
                      ? 'text-primary bg-primary/10'
                      : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
                  }`}
                >
                  {t(link.key)}
                </Link>
              ))}
              {session?.user ? (
                <>
                  <button
                    onClick={() => { setOpen(false); signOut({ redirectTo: '/' }); }}
                    className="px-4 py-3 text-sm font-medium rounded-lg text-left text-muted-foreground hover:text-foreground hover:bg-white/5"
                  >
                    {t('nav.logout')}
                  </button>
                </>
              ) : (
                <Link href="/auth?mode=signup" onClick={() => setOpen(false)} className="px-4 py-3 text-sm font-medium rounded-lg text-primary hover:bg-primary/10">
                  {t('nav.signup')}
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
