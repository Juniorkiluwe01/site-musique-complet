'use client';

import Link from 'next/link';
import { useI18n } from '@/lib/i18n';
import { useSiteSettings } from '@/lib/settings';
import { Music, Instagram, Facebook, Youtube, Phone, Mail } from 'lucide-react';

export function Footer() {
  const { t, locale } = useI18n();
  const s = useSiteSettings();
  const year = 2026;

  return (
    <footer className="border-t border-white/5 bg-black/50">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <Music className="w-6 h-6 text-primary" />
              <span className="font-display text-xl font-bold text-gold-gradient">MC STAGGA GH</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              The Voice of the Streets — La Voix des Rues
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">Links</h4>
            <div className="flex flex-col gap-2">
              <Link href="/music" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('nav.music')}</Link>
              <Link href="/events" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('nav.events')}</Link>
              <Link href="/shop" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('nav.shop')}</Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('nav.contact')}</Link>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-display text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">{locale === 'fr' ? 'Infos' : 'Info'}</h4>
            <div className="flex flex-col gap-2.5">
              <a href={`tel:${s.phone.replace(/\s/g, '')}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                <span suppressHydrationWarning>{s.phone}</span>
              </a>
              <a href={`mailto:${s.email}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors break-all">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                <span suppressHydrationWarning>{s.email}</span>
              </a>
              {s.emailSecondary && (
              <a href={`mailto:${s.emailSecondary}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors break-all">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                <span suppressHydrationWarning>{s.emailSecondary}</span>
              </a>
              )}
            </div>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-display text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">{t('contact.followUs')}</h4>
            <div className="flex gap-3">
              <a href={s.instagramUrl} target="_blank" rel="noopener noreferrer" className="p-2.5 rounded-lg bg-white/5 hover:bg-primary/20 hover:text-primary transition-colors text-muted-foreground" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
              <a href={s.facebookUrl} target="_blank" rel="noopener noreferrer" className="p-2.5 rounded-lg bg-white/5 hover:bg-primary/20 hover:text-primary transition-colors text-muted-foreground" aria-label="Facebook">
                <Facebook className="w-5 h-5" />
              </a>
              <a href={s.youtubeUrl} target="_blank" rel="noopener noreferrer" className="p-2.5 rounded-lg bg-white/5 hover:bg-primary/20 hover:text-primary transition-colors text-muted-foreground" aria-label="YouTube">
                <Youtube className="w-5 h-5" />
              </a>
              <a href={s.tiktokUrl} target="_blank" rel="noopener noreferrer" className="p-2.5 rounded-lg bg-white/5 hover:bg-primary/20 hover:text-primary transition-colors text-muted-foreground" aria-label="TikTok">
                <Music className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 text-center">
          <p className="text-xs text-muted-foreground">
            © {year} MC STAGGA GH. {t('footer.rights')}
          </p>
        </div>
      </div>
    </footer>
  );
}
