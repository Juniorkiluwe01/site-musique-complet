'use client';

import React, { useCallback, useRef, useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { UploadCloud, X, CheckCircle2, Loader2, FileAudio, FileVideo, Image as ImageIcon } from 'lucide-react';
import { toast } from 'sonner';

type Kind = 'image' | 'audio' | 'video' | 'any';

const ACCEPT_MAP: Record<Kind, string> = {
  image: 'image/*',
  audio: 'audio/*',
  video: 'video/*',
  any: 'image/*,audio/*,video/*',
};

const MULTIPART_THRESHOLD = 100 * 1024 * 1024; // 100MB
const PART_SIZE = 10 * 1024 * 1024; // 10MB

async function uploadSinglePart(
  file: File,
  onProgress: (pct: number) => void,
): Promise<string> {
  const presignRes = await fetch('/api/upload/presigned', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fileName: file.name, contentType: file.type || 'application/octet-stream', isPublic: true }),
  });
  if (!presignRes.ok) throw new Error('presign failed');
  const { uploadUrl, fileUrl } = await presignRes.json();

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', uploadUrl);
    xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error('upload failed ' + xhr.status)));
    xhr.onerror = () => reject(new Error('network error'));
    xhr.send(file);
  });

  return fileUrl as string;
}

async function uploadMultipart(
  file: File,
  onProgress: (pct: number) => void,
): Promise<string> {
  const contentType = file.type || 'application/octet-stream';
  const initRes = await fetch('/api/upload/multipart', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'initiate', fileName: file.name, contentType, isPublic: true }),
  });
  if (!initRes.ok) throw new Error('initiate failed');
  const { uploadId, cloud_storage_path } = await initRes.json();

  const totalParts = Math.ceil(file.size / PART_SIZE);
  const parts: { ETag: string; PartNumber: number }[] = [];
  const partProgress = new Array(totalParts).fill(0);

  for (let i = 0; i < totalParts; i++) {
    const partNumber = i + 1;
    const start = i * PART_SIZE;
    const end = Math.min(start + PART_SIZE, file.size);
    const blob = file.slice(start, end);

    const partUrlRes = await fetch('/api/upload/multipart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'part', cloud_storage_path, uploadId, partNumber }),
    });
    if (!partUrlRes.ok) throw new Error('part url failed');
    const { url } = await partUrlRes.json();

    const etag = await new Promise<string>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('PUT', url);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
          partProgress[i] = e.loaded;
          const loaded = partProgress.reduce((a, b) => a + b, 0);
          onProgress(Math.min(99, Math.round((loaded / file.size) * 100)));
        }
      };
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          const tag = xhr.getResponseHeader('ETag') || '';
          resolve(tag);
        } else reject(new Error('part upload failed ' + xhr.status));
      };
      xhr.onerror = () => reject(new Error('network error'));
      xhr.send(blob);
    });

    parts.push({ ETag: etag.replace(/"/g, ''), PartNumber: partNumber });
  }

  const completeRes = await fetch('/api/upload/multipart', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'complete',
      cloud_storage_path,
      uploadId,
      parts: parts.map((p) => ({ ETag: `"${p.ETag}"`, PartNumber: p.PartNumber })),
      contentType,
      isPublic: true,
    }),
  });
  if (!completeRes.ok) throw new Error('complete failed');
  const { fileUrl } = await completeRes.json();
  onProgress(100);
  return fileUrl as string;
}

interface FileUploadProps {
  label: string;
  kind: Kind;
  value?: string;
  onChange: (url: string) => void;
  className?: string;
}

export function FileUpload({ label, kind, value, onChange, className }: FileUploadProps) {
  const { locale } = useI18n();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [fileName, setFileName] = useState('');

  const doUpload = useCallback(async (file: File) => {
    setUploading(true);
    setProgress(0);
    setFileName(file.name);
    try {
      const url = file.size > MULTIPART_THRESHOLD
        ? await uploadMultipart(file, setProgress)
        : await uploadSinglePart(file, setProgress);
      onChange(url);
      toast.success(locale === 'fr' ? 'Fichier téléversé !' : 'File uploaded!');
    } catch (e: any) {
      toast.error(locale === 'fr' ? 'Échec du téléversement' : 'Upload failed');
    } finally {
      setUploading(false);
    }
  }, [onChange, locale]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) doUpload(file);
  }, [doUpload]);

  const KindIcon = kind === 'audio' ? FileAudio : kind === 'video' ? FileVideo : ImageIcon;

  return (
    <div className={className}>
      <label className="block text-xs font-medium text-muted-foreground mb-1.5">{label}</label>
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        onClick={() => !uploading && inputRef.current?.click()}
        className={`relative flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-4 py-6 cursor-pointer transition-colors ${dragging ? 'border-primary bg-primary/10' : 'border-border bg-secondary hover:border-primary/50'}`}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT_MAP[kind]}
          className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) doUpload(f); e.target.value = ''; }}
        />
        {uploading ? (
          <>
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
            <div className="w-full max-w-[220px]">
              <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
              </div>
              <p className="text-[11px] text-muted-foreground text-center mt-1 truncate">{fileName} • {progress}%</p>
            </div>
          </>
        ) : value ? (
          <div className="w-full flex flex-col items-center gap-2">
            {kind === 'image' && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={value} alt="preview" className="max-h-28 rounded-md object-contain" />
            )}
            {kind === 'audio' && <audio src={value} controls className="w-full max-w-[260px]" onClick={(e) => e.stopPropagation()} />}
            {kind === 'video' && <video src={value} controls className="max-h-32 rounded-md" onClick={(e) => e.stopPropagation()} />}
            <div className="flex items-center gap-1.5 text-xs text-primary">
              <CheckCircle2 className="w-4 h-4" />
              <span>{locale === 'fr' ? 'Téléversé — cliquez pour remplacer' : 'Uploaded — click to replace'}</span>
            </div>
          </div>
        ) : (
          <>
            <UploadCloud className="w-7 h-7 text-primary" />
            <p className="text-xs text-foreground text-center">
              {locale === 'fr' ? 'Glissez-déposez ou cliquez pour choisir' : 'Drag & drop or click to browse'}
            </p>
            <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <KindIcon className="w-3.5 h-3.5" />
              <span>{kind === 'audio' ? (locale === 'fr' ? 'Fichier audio' : 'Audio file') : kind === 'video' ? (locale === 'fr' ? 'Fichier vidéo' : 'Video file') : kind === 'image' ? (locale === 'fr' ? 'Image' : 'Image') : (locale === 'fr' ? 'Média' : 'Media')}</span>
            </div>
          </>
        )}
      </div>
      {value && !uploading && (
        <button type="button" onClick={() => onChange('')} className="mt-1.5 inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-destructive">
          <X className="w-3 h-3" />{locale === 'fr' ? 'Retirer' : 'Remove'}
        </button>
      )}
    </div>
  );
}
